"""Create a clearly named, local FK test character without external assets."""

import bpy
from mathutils import Vector
from .synthetic import JOINTS
from .retarget import AXES


def create_demo_rig():
    data = bpy.data.armatures.new("MotionSlate Demo Skeleton")
    rig = bpy.data.objects.new("MotionSlate Demo Humanoid", data)
    bpy.context.collection.objects.link(rig)
    bpy.ops.object.select_all(action="DESELECT")
    rig.select_set(True)
    bpy.context.view_layer.objects.active = rig
    bpy.ops.object.mode_set(mode="EDIT")
    positions = []
    for name, parent, offset in JOINTS:
        positions.append(Vector(offset) + (positions[parent] if parent >= 0 else Vector((0, 1, 0))))
    for i, (name, parent, offset) in enumerate(JOINTS):
        bone = data.edit_bones.new(name)
        bone.head = AXES @ positions[i]
        child = next((j for j, (_, p, _) in enumerate(JOINTS) if p == i), None)
        if child is not None:
            bone.tail = AXES @ positions[child]
        elif "foot" in name:
            bone.tail = bone.head + Vector((0, -0.20, 0))
        elif "hand" in name:
            bone.tail = bone.head + Vector((0.13 if "left" in name else -0.13, 0, 0))
        else:
            bone.tail = bone.head + Vector((0, 0, 0.20))
        if parent >= 0:
            bone.parent = data.edit_bones[JOINTS[parent][0]]
    bpy.ops.object.mode_set(mode="OBJECT")
    materials = []
    for name, color in [
        ("MotionSlate Teal", (0.035, 0.42, 0.42, 1)),
        ("MotionSlate Amber", (0.95, 0.34, 0.075, 1)),
        ("MotionSlate Light", (0.72, 0.83, 0.88, 1)),
    ]:
        material = bpy.data.materials.new(name)
        material.diffuse_color = color
        node = material.node_tree.nodes.get("Principled BSDF")
        node.inputs["Base Color"].default_value = color
        node.inputs["Roughness"].default_value = 0.55
        materials.append(material)
    meshes = []
    for bone in rig.data.bones:
        center = (bone.head_local + bone.tail_local) / 2
        radius = (
            0.09
            if "spine" in bone.name or "hips" in bone.name
            else (0.12 if "head" in bone.name else 0.055)
        )
        bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, location=center)
        mesh = bpy.context.object
        mesh.name = "MotionSlate skin " + bone.name
        mesh.rotation_mode = "QUATERNION"
        mesh.rotation_quaternion = (bone.tail_local - bone.head_local).to_track_quat("Z", "Y")
        mesh.scale = (radius, radius, max(bone.length * 0.5, radius))
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        group = mesh.vertex_groups.new(name=bone.name)
        group.add(list(range(len(mesh.data.vertices))), 1.0, "REPLACE")
        modifier = mesh.modifiers.new("MotionSlate Skeleton", "ARMATURE")
        modifier.object = rig
        mesh.parent = rig
        material = materials[1 if "left" in bone.name else 0 if "right" in bone.name else 2]
        mesh.data.materials.append(material)
        for polygon in mesh.data.polygons:
            polygon.use_smooth = True
        meshes.append(mesh)
    bpy.ops.object.select_all(action="DESELECT")
    rig.select_set(True)
    bpy.context.view_layer.objects.active = rig
    rig.show_in_front = True
    rig["abm_mapping"] = "identity"
    return rig


def create_review_stage():
    bpy.ops.mesh.primitive_plane_add(size=200, location=(0, 0, 0))
    ground = bpy.context.object
    ground.name = "MotionSlate Stage"
    mat = bpy.data.materials.new("MotionSlate Stage Material")
    mat.diffuse_color = (0.025, 0.04, 0.055, 1)
    node = mat.node_tree.nodes.get("Principled BSDF")
    node.inputs["Base Color"].default_value = mat.diffuse_color
    node.inputs["Roughness"].default_value = 0.8
    ground.data.materials.append(mat)
    for location, energy, size in [
        ((3, -4, 6), 900, 5),
        ((-4, -1, 4), 650, 4),
        ((0, 4, 5), 1100, 3),
    ]:
        bpy.ops.object.light_add(type="AREA", location=location)
        lamp = bpy.context.object
        lamp.data.energy = energy
        lamp.data.shape = "DISK"
        lamp.data.size = size
        lamp.rotation_euler = (
            (Vector((0, 0, 1)) - lamp.location).to_track_quat("-Z", "Y").to_euler()
        )
    bpy.ops.object.camera_add(location=(3, -5, 2.8))
    camera = bpy.context.object
    camera.rotation_euler = (
        (Vector((0.3, 0, 1)) - camera.location).to_track_quat("-Z", "Y").to_euler()
    )
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = 3.5
    bpy.context.scene.camera = camera
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 16
    scene.render.resolution_x = 960
    scene.render.resolution_y = 720
    scene.render.resolution_percentage = 100
    scene.world.color = (0.15, 0.15, 0.15)
