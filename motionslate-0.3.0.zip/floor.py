"""Convert a measured room floor through the frozen retargeting policy."""

import math
from mathutils import Matrix, Vector
from .retarget import AXES, matrix


def observed_floor(snapshot, pose, metrics):
    if not metrics or not metrics.get("floor") or not pose.usable:
        return None
    if any(metrics.get(k) != getattr(pose, k) for k in ("session_id", "segment_id", "body_id")):
        return None
    if not 0 <= pose.timestamp - metrics["source_timestamp"] <= 2:
        return None
    indices = snapshot["source_indices"]
    source_lengths = []
    target_lengths = []
    world = matrix(snapshot["target_world"])
    for side in ("left", "right"):
        names = [side + s for s in ("_upLeg_joint", "_leg_joint", "_foot_joint")]
        if not all(n in indices for n in names):
            continue
        if not all(pose.valid[indices[n]] for n in names):
            continue
        a, b, c = [matrix(pose.joints[indices[n]]).translation for n in names]
        source_lengths.append(((b - a).length + (c - b).length) * pose.scale)
        a, b, c = [
            (world @ matrix(snapshot["target_reference"][snapshot["mapping"][n]])).translation
            for n in names
        ]
        target_lengths.append((b - a).length + (c - b).length)
    if not source_lengths or min(source_lengths) < 0.1:
        return None
    ratio = sum(target_lengths) / sum(source_lengths)
    root = matrix(pose.anchor) @ matrix(pose.joints[indices[snapshot["root_source"]]])
    height = root.translation.y - metrics["floor"]["height"]
    if not 0.2 < height < 3:
        return None
    conversion = Matrix.Rotation(math.radians(snapshot["heading_degrees"]), 4, "Z") @ AXES
    delta = (
        world.inverted() @ (conversion @ root.translation) - Vector(snapshot["source_root"])
    ) * snapshot["travel_scale"]
    target = (
        world @ matrix(snapshot["target_reference"][snapshot["mapping"][snapshot["root_source"]]])
    ).translation
    target += world.to_3x3() @ delta
    return dict(
        floor_world_z=target.z - height * ratio,
        floor_observation=dict(
            metrics["floor"], source_timestamp=metrics["source_timestamp"], leg_scale=ratio
        ),
    )
