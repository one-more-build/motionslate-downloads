"""MotionSlate capture. Importing the core never requires Blender."""


def register():
    from . import addon

    addon.register()


def unregister():
    from . import addon

    addon.unregister()
