"""Main-thread, separately authenticated preview socket with one-frame credit."""

import errno
import socket
import select
import time
import uuid
from .protocol import Framer, Kind, ProtocolError, control, decode, frame


class PreviewConnection:
    def __init__(self, port, token, controller_id=None):
        self.port = port
        self.token = token
        self.controller_id = controller_id
        self.sock = None
        self.out = bytearray()
        self.parser = Framer()
        self.authorized = False
        self.retry = 0.0
        self.last_receive = 0.0
        self.error = None
        self.pending_pose = None
        self.connecting = False

    def close(self):
        if self.sock:
            self.sock.close()
        self.sock = None
        self.authorized = False
        self.out.clear()
        self.parser = Framer()
        self.pending_pose = None

    def tick(self, receive):
        now = time.monotonic()
        try:
            if self.sock is None:
                if now < self.retry:
                    return
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.setblocking(False)
                code = self.sock.connect_ex(("127.0.0.1", self.port))
                if code not in (0, errno.EINPROGRESS, errno.EWOULDBLOCK, errno.EALREADY):
                    raise ConnectionError("Preview connection unavailable")
                hello_body = dict(
                    role="preview",
                    protocol=2,
                    features=["journal-v1", "preview-v1"],
                    token=self.token,
                    connection_id=str(uuid.uuid4()),
                )
                if self.controller_id is not None:
                    hello_body["controller_id"] = self.controller_id
                self.out.extend(
                    frame(
                        control(
                            Kind.HELLO,
                            hello_body,
                        )
                    )
                )
                self.last_receive = now
                self.connecting = True
            if self.connecting:
                if not select.select([], [self.sock], [self.sock], 0)[1]:
                    return
                error = self.sock.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
                if error:
                    raise ConnectionError(f"Preview connection failed ({error})")
                self.connecting = False
            if self.out:
                try:
                    sent = self.sock.send(self.out)
                    del self.out[:sent]
                except (BlockingIOError, InterruptedError):
                    pass
            try:
                data = self.sock.recv(65536)
            except (BlockingIOError, InterruptedError):
                data = None
            if data == b"":
                raise ConnectionError("Preview disconnected")
            if data:
                self.last_receive = now
                for payload in self.parser.feed(data):
                    kind, body = decode(payload)
                    if kind == Kind.STATUS and body.get("error"):
                        raise ProtocolError(body["error"])
                    if kind == Kind.STATUS and body.get("hello"):
                        self.authorized = True
                        self.error = None
                        continue
                    if kind == Kind.POSE:
                        self.pending_pose = body
                        continue
                    if kind == Kind.STATUS and body.get("kind") == "PREVIEW":
                        # This channel is loopback: both processes share the host monotonic clock.
                        age = body.get("age_seconds")
                        if age is not None:
                            body = dict(
                                body,
                                age_seconds=age
                                + max(
                                    0,
                                    time.monotonic() - body.get("sent_monotonic", time.monotonic()),
                                ),
                            )
                        receive(kind, body)
                        if (
                            self.pending_pose
                            and body.get("age_seconds") is not None
                            and body["age_seconds"] <= 0.5
                        ):
                            receive(Kind.POSE, self.pending_pose)
                        self.pending_pose = None
                        self.out.extend(
                            frame(
                                control(
                                    Kind.QUERY,
                                    dict(
                                        kind="PREVIEW_ACK",
                                        session_id=body.get("session_id"),
                                        sequence=body.get("sequence"),
                                    ),
                                )
                            )
                        )
                    else:
                        receive(kind, body)
                if self.out:
                    try:
                        sent = self.sock.send(self.out)
                        del self.out[:sent]
                    except (BlockingIOError, InterruptedError):
                        pass
            if now - self.last_receive > 3:
                raise ConnectionError("Preview timed out")
        except (OSError, ConnectionError, ProtocolError) as exc:
            self.error = str(exc)
            self.close()
            self.retry = now + 1
