"""ABM2 wire codec. Explicit scalars; never native structure layout."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
import hashlib
import json
import math
import struct
import uuid

MAX_PAYLOAD = 1024 * 1024
MAX_JOINTS = 256
ZERO = str(uuid.UUID(int=0))
IDENTITY = (1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0)
HEADER = struct.Struct("<4sHH")
PREFIX = struct.Struct(">I")


class ProtocolError(ValueError):
    pass


class Kind(IntEnum):
    HELLO = 1
    SCHEMA = 2
    COMMAND = 3
    EVENT = 4
    STATUS = 5
    QUERY = 6
    POSE = 16


def uid(value):
    try:
        return str(uuid.UUID(str(value)))
    except (ValueError, TypeError, AttributeError) as exc:
        raise ProtocolError("Invalid UUID") from exc


def integer(value, low, high, name):
    if type(value) is not int or not low <= value <= high:
        raise ProtocolError(f"{name} must be an integer in [{low}, {high}]")
    return value


def finite(value, name="number"):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ProtocolError(f"Nonfinite or invalid {name}")
    return value


def json_bytes(value):
    try:
        return json.dumps(
            value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
        ).encode("utf8")
    except (ValueError, TypeError, RecursionError) as exc:
        raise ProtocolError("Invalid JSON value") from exc


def control(kind, body):
    if kind == Kind.POSE or not isinstance(body, dict):
        raise ProtocolError("Expected control object")
    data = HEADER.pack(b"ABM2", 2, Kind(kind)) + json_bytes(body)
    check_length(len(data))
    return data


def check_length(length):
    if not 8 <= length <= MAX_PAYLOAD:
        raise ProtocolError("Payload length outside limits")


def frame(payload):
    check_length(len(payload))
    return PREFIX.pack(len(payload)) + payload


class Framer:
    def __init__(self):
        self.buffer = bytearray()
        self.expected = None

    def feed(self, data):
        """Process arbitrarily split/coalesced input without an unbounded accumulator."""
        result = []
        view = memoryview(data)
        while view:
            needed = (4 if self.expected is None else self.expected) - len(self.buffer)
            amount = min(needed, len(view))
            self.buffer.extend(view[:amount])
            view = view[amount:]
            if len(self.buffer) == 4 and self.expected is None:
                self.expected = PREFIX.unpack(self.buffer)[0]
                check_length(self.expected)
                self.buffer.clear()
            elif self.expected is not None and len(self.buffer) == self.expected:
                result.append(bytes(self.buffer))
                self.buffer.clear()
                self.expected = None
        return result

    def eof(self):
        if self.buffer or self.expected is not None:
            raise ProtocolError("Truncated network frame")


@dataclass(frozen=True)
class Schema:
    schema_id: str
    joint_names: tuple[str, ...]
    parents: tuple[int, ...]
    source_api: str = "ARKit.ARSkeleton3D"
    neutral_joints: tuple[tuple[float, ...], ...] | None = None

    def __post_init__(self):
        uid(self.schema_id)
        n = len(self.joint_names)
        integer(n, 1, MAX_JOINTS, "Joint count")
        if len(self.parents) != n or len(set(self.joint_names)) != n:
            raise ProtocolError("Schema names/parents mismatch or duplicate")
        for name in self.joint_names:
            if (
                not isinstance(name, str)
                or not 1 <= len(name) <= 128
                or any(ord(c) < 32 for c in name)
            ):
                raise ProtocolError("Invalid joint name")
        for parent in self.parents:
            integer(parent, -1, n - 1, "Parent index")
        if self.parents.count(-1) != 1:
            raise ProtocolError("Schema needs exactly one root")
        for start in range(n):
            visited = set()
            while start != -1:
                if start in visited:
                    raise ProtocolError("Cyclic skeleton")
                visited.add(start)
                start = self.parents[start]
        if self.neutral_joints is not None:
            if len(self.neutral_joints) != n:
                raise ProtocolError("Neutral skeleton count mismatch")
            for m in self.neutral_joints:
                if len(m) != 16 or any(
                    not math.isfinite(finite(x, "neutral transform")) for x in m
                ):
                    raise ProtocolError("Invalid neutral transform")
                if any(abs(m[i] - v) > 1e-5 for i, v in ((3, 0), (7, 0), (11, 0), (15, 1))):
                    raise ProtocolError("Neutral transform must be affine")
                columns = [m[i : i + 3] for i in (0, 4, 8)]
                if any(
                    abs(sum(a * b for a, b in zip(x, y)) - (1 if i == j else 0)) > 1e-3
                    for i, x in enumerate(columns)
                    for j, y in enumerate(columns)
                ):
                    raise ProtocolError("Neutral rotation must be orthonormal")
                a, b, c = columns
                determinant = (
                    a[0] * (b[1] * c[2] - b[2] * c[1])
                    - b[0] * (a[1] * c[2] - a[2] * c[1])
                    + c[0] * (a[1] * b[2] - a[2] * b[1])
                )
                if determinant < 0:
                    raise ProtocolError("Neutral rotation must preserve handedness")

    @property
    def definition_hash(self):
        return hashlib.sha256(
            "\n".join(f"{n}\t{p}" for n, p in zip(self.joint_names, self.parents)).encode("utf8")
        ).hexdigest()

    def body(self):
        value = dict(
            schema_id=uid(self.schema_id),
            joint_names=list(self.joint_names),
            parents=list(self.parents),
            source_api=self.source_api,
            source_definition_hash=self.definition_hash,
            matrix_convention="column-major-column-vectors",
            units="meters",
        )
        if self.neutral_joints is not None:
            value.update(neutral_version=1, neutral_joints=[list(m) for m in self.neutral_joints])
        return value

    @classmethod
    def from_body(cls, body):
        try:
            if (
                body["matrix_convention"] != "column-major-column-vectors"
                or body["units"] != "meters"
            ):
                raise ProtocolError("Unsupported coordinate convention")
            if ("neutral_joints" in body or "neutral_version" in body) and (
                type(body.get("neutral_version")) is not int or body["neutral_version"] != 1
            ):
                raise ProtocolError("Unsupported neutral skeleton version")
            neutral = (
                tuple(tuple(m) for m in body["neutral_joints"])
                if "neutral_joints" in body
                else None
            )
            if "neutral_version" in body and neutral is None:
                raise ProtocolError("Missing neutral transforms")
            schema = cls(
                uid(body["schema_id"]),
                tuple(body["joint_names"]),
                tuple(body["parents"]),
                body["source_api"],
                neutral,
            )
            if schema.definition_hash != body["source_definition_hash"]:
                raise ProtocolError("Schema definition hash mismatch")
            return schema
        except (KeyError, TypeError) as exc:
            raise ProtocolError("Malformed schema") from exc


@dataclass(frozen=True)
class Pose:
    session_id: str
    segment_id: str
    body_id: str
    take_id: str
    schema_id: str
    sequence: int
    timestamp: float
    flags: int
    scale: float
    anchor: tuple[float, ...]
    camera: tuple[float, ...]
    valid: tuple[bool, ...]
    tracked: tuple[bool, ...]
    joints: tuple[tuple[float, ...], ...]

    @property
    def usable(self):
        return self.flags & 3 == 3 and (self.flags >> 4) & 3 == 2

    def validate(self, schema=None):
        for value in (self.session_id, self.segment_id, self.body_id, self.take_id, self.schema_id):
            uid(value)
        n = len(self.joints)
        integer(n, 1, MAX_JOINTS, "Joint count")
        if schema and (uid(self.schema_id) != schema.schema_id or n != len(schema.joint_names)):
            raise ProtocolError("Pose/schema mismatch")
        integer(self.sequence, 0, 2**64 - 1, "Sequence")
        finite(self.timestamp, "timestamp")
        integer(self.flags, 0, 0xFFFFFFFF, "Flags")
        if (
            self.flags & ~0x37
            or (self.flags >> 4) & 3 == 3
            or (self.flags & 2 and not self.flags & 1)
        ):
            raise ProtocolError("Invalid tracking flags")
        if bool(self.flags & 1) != (uid(self.body_id) != ZERO):
            raise ProtocolError("Body identity/presence mismatch")
        if (
            len(self.valid) != n
            or len(self.tracked) != n
            or any(type(v) is not bool for v in self.valid + self.tracked)
        ):
            raise ProtocolError("Invalid joint masks")
        if not self.flags & 1 and (any(self.valid) or any(self.tracked)):
            raise ProtocolError("Absent body has valid joints")
        finite(self.scale, "scale")
        if self.scale <= 0:
            raise ProtocolError("Scale must be positive")
        for matrix in (self.anchor, self.camera, *self.joints):
            if len(matrix) != 16:
                raise ProtocolError("Expected 4x4 matrix")
            for value in matrix:
                finite(value, "matrix")
        for valid, matrix in zip(self.valid, self.joints):
            if not valid and tuple(matrix) != IDENTITY:
                raise ProtocolError("Invalid joint must contain identity")
        return self

    def encode(self):
        self.validate()
        n = len(self.joints)
        masks = [
            bytes(
                sum(int(bits[j]) << (j % 8) for j in range(i, min(i + 8, n)))
                for i in range(0, n, 8)
            )
            for bits in (self.valid, self.tracked)
        ]
        return (
            HEADER.pack(b"ABM2", 2, Kind.POSE)
            + b"".join(
                uuid.UUID(x).bytes
                for x in (
                    self.session_id,
                    self.segment_id,
                    self.body_id,
                    self.take_id,
                    self.schema_id,
                )
            )
            + struct.pack("<QdIHHf", self.sequence, self.timestamp, self.flags, n, 0, self.scale)
            + struct.pack("<32f", *self.anchor, *self.camera)
            + b"".join(masks)
            + struct.pack(f"<{n * 16}f", *(x for m in self.joints for x in m))
        )

    @classmethod
    def decode(cls, data):
        if len(data) < 244:
            raise ProtocolError("Short pose")
        ids = [str(uuid.UUID(bytes=data[i : i + 16])) for i in range(8, 88, 16)]
        seq, ts, flags, n, reserved, scale = struct.unpack_from("<QdIHHf", data, 88)
        integer(n, 1, MAX_JOINTS, "Joint count")
        b = (n + 7) // 8
        if reserved or len(data) != 244 + 2 * b + 64 * n:
            raise ProtocolError("Pose length/reserved mismatch")
        if n % 8 and (data[244 + b - 1] | data[244 + 2 * b - 1]) >> (n % 8):
            raise ProtocolError("Unused mask bits set")
        valid, tracked = (
            tuple(bool(data[244 + offset + j // 8] & (1 << (j % 8))) for j in range(n))
            for offset in (0, b)
        )
        anchor = struct.unpack_from("<16f", data, 116)
        camera = struct.unpack_from("<16f", data, 180)
        joints = tuple(struct.unpack_from("<16f", data, 244 + 2 * b + i * 64) for i in range(n))
        return cls(*ids, seq, ts, flags, scale, anchor, camera, valid, tracked, joints).validate()


def decode(payload):
    check_length(len(payload))
    magic, major, kind = HEADER.unpack_from(payload)
    if magic != b"ABM2" or major != 2:
        raise ProtocolError("Unsupported protocol")
    try:
        kind = Kind(kind)
    except ValueError as exc:
        raise ProtocolError("Unknown message type") from exc
    if kind == Kind.POSE:
        return kind, Pose.decode(payload)
    try:

        def bad_constant(value):
            raise ProtocolError("Nonfinite JSON constant")

        def unique_pairs(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ProtocolError("Duplicate JSON key")
                result[key] = value
            return result

        body = json.loads(payload[8:], parse_constant=bad_constant, object_pairs_hook=unique_pairs)
        if not isinstance(body, dict):
            raise ProtocolError("Expected JSON object")
        return kind, body
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise ProtocolError("Malformed control JSON") from exc
