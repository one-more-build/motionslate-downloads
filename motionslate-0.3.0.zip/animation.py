"""Source-time resampling and native slotted-Action writing."""

from __future__ import annotations
import json
import math
from pathlib import Path
import time
import bpy
from mathutils import Matrix, Quaternion
from bpy_extras import anim_utils
from .protocol import ProtocolError, uid
from .retarget import matrix
from .quality import configuration
from .motion import MotionSolver


def blend_basis(a, b, fraction):
    """Resample processed poses using Blender's normalized linear quaternion channels."""
    result = {}
    for name, ma in a.items():
        la, qa, sa = ma.decompose()
        lb, qb, sb = b[name].decompose()
        if qa.dot(qb) < 0:
            qb.negate()
        q = Quaternion(
            tuple((1 - fraction) * x + fraction * y for x, y in zip(qa, qb))
        ).normalized()
        result[name] = Matrix.LocRotScale(la.lerp(lb, fraction), q, sa.lerp(sb, fraction))
    return result


class ActionWriter:
    def __init__(
        self,
        rig,
        snapshot,
        take_id,
        name="Mocap Take",
        start_frame=1,
        fps_numerator=30,
        fps_denominator=1,
    ):
        snapshot = dict(snapshot, processing=configuration(snapshot.get("processing")))
        self.rig = rig
        self.solver = MotionSolver(rig, snapshot)
        self.snapshot = snapshot
        self.start_frame = start_frame
        self.fps = fps_numerator / fps_denominator
        if not 1 <= self.fps <= 120:
            raise ProtocolError("Invalid output frame rate")
        self.old_action = rig.animation_data.action if rig.animation_data else None
        self.old_slot = rig.animation_data.action_slot if rig.animation_data else None
        self.old_nla = (
            [(track, track.mute) for track in rig.animation_data.nla_tracks]
            if rig.animation_data
            else []
        )
        self.old_rotation_modes = {b.name: b.rotation_mode for b in rig.pose.bones}
        self.old_basis = {b.name: b.matrix_basis.copy() for b in rig.pose.bones}
        self.action = bpy.data.actions.new(name)
        self.action.use_fake_user = True
        self.action["abm_take_id"] = take_id
        self.action["abm_rig_fingerprint"] = snapshot["rig_fingerprint"]
        self.action["abm_processing"] = json.dumps(snapshot)
        self.action["abm_state"] = "RECORDING"
        self.action["abm_fps_numerator"] = fps_numerator
        self.action["abm_fps_denominator"] = fps_denominator
        self.slot = self.action.slots.new(id_type="OBJECT", name=rig.name)
        ad = rig.animation_data_create()
        ad.action = self.action
        ad.action_slot = self.slot
        for track, _ in self.old_nla:
            track.mute = True
        self.bag = anim_utils.action_ensure_channelbag_for_slot(self.action, self.slot)
        self.curves = {}
        self.pending = {}
        self.previous_quaternions = {}
        self.paths = {
            (b.name, p): b.path_from_id(p)
            for b in rig.pose.bones
            for p in ("location", "rotation_quaternion", "scale")
        }
        self.quality_intervals = []
        self.frames = 0
        self.last_pose = None
        self.last_acceptable = None
        self.t0 = None
        self.t_stop = None
        self.gaps = []
        self.last_basis = None
        self.last_flags = {}
        self.source_gap_limit = 0.1000001
        self.hold_seconds = 0.25
        self.last_sequence = -1
        self.needs_rebuild = False
        for bone in rig.pose.bones:
            bone.rotation_mode = "QUATERNION"
        # Every bone receives its reference channels once, so unmapped pose offsets survive reopening.
        for bone in rig.pose.bones:
            ref = matrix(snapshot["target_basis"][bone.name])
            loc, rot, scale = ref.decompose()
            for prop, values in [("location", loc), ("rotation_quaternion", rot), ("scale", scale)]:
                for index, value in enumerate(values):
                    self.queue(bone, prop, index, start_frame, float(value))
        self.flush()

    def queue(self, bone, prop, index, frame, value):
        path = self.paths[(bone.name, prop)]
        key = (path, index)
        if key not in self.curves:
            self.curves[key] = self.bag.fcurves.new(path, index=index, group_name=bone.name)
            self.pending[key] = []
        self.pending[key].append((float(frame), float(value)))

    def flush(self, deadline=None):
        for key, items in self.pending.items():
            if not items:
                continue
            if deadline is not None and time.perf_counter() >= deadline:
                return False
            curve = self.curves[key]
            # Allocate once per monotonic batch. Inserting individual keys reallocates
            # and copies the complete curve, even with Blender's FAST option.
            points = curve.keyframe_points
            first = 0
            if len(points) and abs(points[len(points) - 1].co.x - items[0][0]) < 1e-5:
                points[len(points) - 1].co = items[0]
                first = 1
            offset = len(points)
            points.add(len(items) - first)
            for index, (frame, value) in enumerate(items[first:], offset):
                point = points[index]
                point.co = (frame, value)
                point.interpolation = "LINEAR"
            # Keys are already sorted and linear. Recalculate only at finalization,
            # avoiding a full-history handle pass for every small live batch.
            items.clear()
        return True

    def start(self, t0, t_stop=None):
        self.t0 = t0
        self.t_stop = t_stop
        self.action["abm_t0"] = t0

    def set_end(self, t_stop):
        if self.t0 is None or t_stop <= self.t0:
            raise ProtocolError("Invalid source end")
        self.t_stop = t_stop

    def write_processed(self, basis, quality_flags):
        flags = sorted(quality_flags.items())
        if flags:
            if (
                self.quality_intervals
                and self.quality_intervals[-1]["joints"] == flags
                and self.quality_intervals[-1]["end"] == self.frames - 1
            ):
                self.quality_intervals[-1]["end"] = self.frames
            else:
                self.quality_intervals.append(
                    dict(start=self.frames, end=self.frames, joints=flags)
                )
        self.write_basis(basis)

    def write_basis(self, basis, frame=None):
        frame = self.start_frame + self.frames if frame is None else frame
        for target in self.snapshot["mapping"].values():
            bone = self.rig.pose.bones[target]
            location, rotation, scale = basis[target].decompose()
            rotation.normalize()
            prior = self.previous_quaternions.get(target)
            if prior and prior.dot(rotation) < 0:
                rotation.negate()
            self.previous_quaternions[target] = rotation.copy()
            for index, value in enumerate(rotation):
                self.queue(bone, "rotation_quaternion", index, frame, value)
            if target == self.solver.root_target:
                for index, value in enumerate(location):
                    self.queue(bone, "location", index, frame, value)
        self.frames += 1

    def feed(self, pose):
        for _ in self.feed_iter(pose):
            pass

    def feed_iter(self, pose):
        if self.t0 is None:
            raise ProtocolError("Start boundary must precede Action samples")
        if pose.sequence <= self.last_sequence:
            self.needs_rebuild = True
            return
        self.last_sequence = pose.sequence
        previous = self.last_pose
        if previous and pose.timestamp <= previous.timestamp:
            raise ProtocolError("Source timestamps must increase")
        if previous and self.t_stop is not None and previous.timestamp >= self.t_stop:
            return
        previous_basis = self.last_basis
        previous_flags = self.last_flags
        acceptable = self.last_acceptable
        end = min(pose.timestamp, self.t_stop) if self.t_stop is not None else pose.timestamp
        # Reject gaps on the source timeline even when no output frame falls in them.
        if previous and end - previous.timestamp > self.hold_seconds:
            self.action["abm_state"] = "TRACKING_GAP"
            raise ProtocolError("Source gap exceeds hold limit; source retained for recovery")
        good_next = self.solver.accepts(pose)
        if good_next:
            basis = self.solver.solve(pose)
            flags = dict(self.solver.quality_flags)
            self.last_acceptable = (pose, basis)
        elif acceptable and end - acceptable[0].timestamp <= self.hold_seconds:
            basis = self.solver.hold(pose.timestamp)
            flags = dict(self.solver.quality_flags)
        elif pose.timestamp >= self.t0:
            self.action["abm_state"] = "TRACKING_GAP"
            raise ProtocolError(
                "Tracking gap exceeds hold limit or has no initial usable sample; source retained for recovery"
            )
        else:
            basis = None
            flags = {}
        self.last_pose = pose
        self.last_basis = basis
        self.last_flags = flags
        # Each original observation is solved once, including between output frames.
        # Yield after the solve so a low output FPS still respects the timer budget.
        yield
        if previous is None:
            return
        while True:
            time = self.t0 + self.frames / self.fps
            if time > pose.timestamp + 1e-9 or (
                self.t_stop is not None and time >= self.t_stop - 1e-9
            ):
                break
            if time < previous.timestamp - 1e-9:
                raise ProtocolError("Missing initial bracketing sample")
            good_previous = self.solver.accepts(previous)
            if abs(time - previous.timestamp) < 1e-9 and previous_basis is not None:
                sample = previous_basis
                sample_flags = previous_flags
                if not good_previous:
                    self.gaps.append((self.frames, "tracking_held"))
            elif abs(time - pose.timestamp) < 1e-9 and basis is not None:
                sample = basis
                sample_flags = flags
                if not good_next:
                    self.gaps.append((self.frames, "tracking_held"))
            elif (
                good_previous
                and good_next
                and pose.timestamp - previous.timestamp <= self.source_gap_limit
            ):
                sample = blend_basis(
                    previous_basis,
                    basis,
                    (time - previous.timestamp) / (pose.timestamp - previous.timestamp),
                )
                sample_flags = dict(previous_flags, **flags)
                if pose.sequence != previous.sequence + 1:
                    self.gaps.append((self.frames, "transmission_interpolated"))
            elif acceptable and time - acceptable[0].timestamp <= self.hold_seconds:
                sample = previous_basis if previous_basis is not None else acceptable[1]
                sample_flags = {source: "held" for source in self.snapshot["mapping"]}
                self.gaps.append((self.frames, "tracking_held"))
            else:
                self.action["abm_state"] = "TRACKING_GAP"
                raise ProtocolError(
                    "Tracking/source gap exceeds hold limit; source retained for recovery"
                )
            self.write_processed(sample, sample_flags)
            yield

    def finalize(self, source_hash):
        for _ in self.finalize_iter(source_hash):
            pass
        return self.action

    def finalize_iter(self, source_hash):
        while not self.flush(time.perf_counter() + 0.003):
            yield
        for curve in self.curves.values():
            curve.update()
            yield
        if self.t_stop is None:
            raise ProtocolError("Missing authoritative end boundary")
        expected = math.ceil((self.t_stop - self.t0) * self.fps - 1e-7)
        if self.needs_rebuild or self.frames != expected:
            self.action["abm_state"] = "RECOVERY_REQUIRED"
            raise ProtocolError(f"Action needs replay: keyed {self.frames}, expected {expected}")
        self.action["abm_state"] = "READY_IN_SCENE"
        self.action["abm_source_hash"] = source_hash
        self.action["abm_frames"] = self.frames
        self.action["abm_t_stop"] = self.t_stop
        self.action["abm_joint_recovery"] = json.dumps(self.quality_intervals)
        self.action["abm_rejected_spikes"] = self.solver.recovery.rejected
        self.action["abm_gap_count"] = len(self.gaps)
        self.action["abm_gaps"] = json.dumps(self.gaps)
        self.action["abm_start_frame"] = self.start_frame
        return self.action

    def restore(self, remove=False):
        ad = self.rig.animation_data_create()
        ad.action = self.old_action
        if self.old_action and self.old_slot:
            ad.action_slot = self.old_slot
        for track, mute in self.old_nla:
            try:
                track.mute = mute
            except ReferenceError:
                pass
        for name, value in self.old_basis.items():
            self.rig.pose.bones[name].rotation_mode = self.old_rotation_modes[name]
            self.rig.pose.bones[name].matrix_basis = value
        if remove:
            bpy.data.actions.remove(self.action)


def bake_source(
    rig, snapshot, source, start_frame=1, fps_numerator=30, fps_denominator=1, name="Mocap Take"
):
    """Offline/recovery path using verified ReadOnlySource with bounded pose memory."""
    from .protocol import decode, Kind

    if not source.verified:
        source.verify()
    manifest = source.manifest
    writer = ActionWriter(
        rig, snapshot, source.take_id, name, start_frame, fps_numerator, fps_denominator
    )
    writer.start(manifest["t0"], manifest["t_stop"])
    try:
        for index, payload in enumerate(source.records()):
            kind, pose = decode(payload)
            if kind == Kind.POSE:
                writer.feed(pose)
                if index % 64 == 0:
                    writer.flush()
        writer.finalize(manifest["source_hash"])
        writer.action["abm_source_path"] = str(source.directory)
        return writer
    except Exception:
        writer.restore(remove=True)
        raise


def resolve_source_path(action, rig=None, capture_directory=None) -> Path | None:
    """Resolve source directory for a take Action.
    abm_source_path on the Action owns the location.
    Old capture-root/rig fields are fallbacks.
    """
    take_id = action.get("abm_take_id") if action else None
    if not take_id:
        return None

    # 1. Action's abm_source_path owns location
    src_path = action.get("abm_source_path") if action else None
    if src_path:
        p = Path(src_path).expanduser().resolve()
        if (p / "manifest.json").exists():
            return p
        if (p / take_id / "manifest.json").exists():
            return p / take_id

    # 2. Rig metadata fallback
    if rig and "abm_take_metadata" in rig:
        try:
            meta = json.loads(rig["abm_take_metadata"])
            if isinstance(meta, dict) and meta.get("take_id") == take_id:
                rig_src = meta.get("source_path")
                if rig_src:
                    p = Path(rig_src).expanduser().resolve()
                    if (p / "manifest.json").exists():
                        return p
                    if (p / take_id / "manifest.json").exists():
                        return p / take_id
        except Exception:
            pass

    # 3. Capture directory fallback
    if capture_directory:
        p = Path(capture_directory).expanduser().resolve()
        if p.name == take_id and (p / "manifest.json").exists():
            return p
        if (p / take_id / "manifest.json").exists():
            return p / take_id

    # If abm_source_path was set even if directory doesn't exist yet, return it as the target
    if src_path:
        p = Path(src_path).expanduser().resolve()
        return p if p.name == take_id else p / take_id

    if capture_directory:
        p = Path(capture_directory).expanduser().resolve()
        return p if p.name == take_id else p / take_id

    return None


class RebuildJob:
    """Cooperative iterator that rebuilds an Action from verified source."""

    def __init__(self, rig, action, capture_directory=None):
        if not rig:
            raise ProtocolError("Select an armature to rebuild animation")
        if not action or not action.get("abm_take_id"):
            raise ProtocolError("Select an Action associated with a take")
        self.rig = rig
        self.original = action
        self.take = uid(action.get("abm_take_id"))
        self.writer = None
        self.source = None
        self.done = False
        self.progress = "Locating source"

        self.directory = resolve_source_path(action, rig, capture_directory)
        if not self.directory or not self.directory.exists():
            raise ProtocolError(
                "Capture source directory not found; locate source before rebuilding"
            )

        self.iterator = self.run()

    def cancel(self):
        self.iterator.close()

    def run(self):
        from .protocol import Kind, decode
        from .journal import ReadOnlySource
        from .retarget import rig_fingerprint

        success = False
        self.progress = "Verifying source"
        self.source = ReadOnlySource(
            self.directory,
            take_id=self.take,
            expected_hash=self.original.get("abm_source_hash"),
        )
        try:
            yield from self.source.verify_iter()
            manifest = self.source.manifest

            # Resolve frozen settings: TAKE_PREPARED.settings takes precedence
            settings = self.source.prepared_settings()
            snapshot = None
            start_frame = None
            fps_numerator = None
            fps_denominator = None
            name = None

            if settings and isinstance(settings, dict):
                snapshot = settings.get("snapshot")
                start_frame = settings.get("start_frame")
                fps_numerator = settings.get("fps_numerator")
                fps_denominator = settings.get("fps_denominator")
                name = settings.get("name")

            if not snapshot:
                proc_path = self.directory / "processing.json"
                if proc_path.exists():
                    try:
                        proc_data = json.loads(proc_path.read_text())
                        if isinstance(proc_data, dict):
                            if "snapshot" in proc_data:
                                snapshot = proc_data["snapshot"]
                                start_frame = start_frame or proc_data.get("start_frame")
                                fps_numerator = fps_numerator or proc_data.get("fps_numerator")
                                fps_denominator = fps_denominator or proc_data.get(
                                    "fps_denominator"
                                )
                                name = name or proc_data.get("name")
                            else:
                                snapshot = proc_data
                    except Exception:
                        pass

            if not snapshot and self.original.get("abm_processing"):
                try:
                    snapshot = json.loads(self.original["abm_processing"])
                except Exception:
                    pass

            if not snapshot:
                raise ProtocolError(
                    "Missing frozen processing settings in source, processing.json, and Action"
                )

            if (
                snapshot.get("rig_fingerprint")
                and rig_fingerprint(self.rig) != snapshot["rig_fingerprint"]
            ):
                raise ProtocolError("Rig does not match take snapshot")

            start_frame = (
                start_frame if start_frame is not None else self.original.get("abm_start_frame", 1)
            )
            fps_numerator = fps_numerator or self.original.get("abm_fps_numerator", 30)
            fps_denominator = fps_denominator or self.original.get("abm_fps_denominator", 1)
            name = name or self.original.name

            self.writer = ActionWriter(
                self.rig,
                snapshot,
                self.take,
                name,
                start_frame,
                fps_numerator,
                fps_denominator,
            )
            self.writer.start(manifest["t0"], manifest["t_stop"])
            self.progress = "Rebuilding Action"

            for index, payload in enumerate(self.source.records()):
                kind, pose = decode(payload)
                if kind == Kind.POSE:
                    yield from self.writer.feed_iter(pose)
                    if index % 64 == 0:
                        self.writer.flush()

            self.progress = "Finalizing Action"
            yield from self.writer.finalize_iter(manifest["source_hash"])

            self.writer.action["abm_source_path"] = str(self.directory)
            self.writer.action["abm_state"] = "READY_IN_SCENE"

            old_action = self.original
            old_action.use_fake_user = False
            if old_action.users == 0:
                try:
                    bpy.data.actions.remove(old_action)
                except Exception:
                    pass

            success = True
            self.done = True
            self.progress = f"Rebuilt {self.writer.frames} frames"
        finally:
            if not success and self.writer:
                self.writer.restore(remove=True)
            if self.source:
                self.source.close()


def relink_source(action, directory, rig=None):
    """Relink an Action to a relocated source directory by verifying UUID and canonical hash."""
    from .journal import ReadOnlySource

    if not action or not action.get("abm_take_id"):
        raise ProtocolError("Action has no take ID")
    take_id = uid(action["abm_take_id"])
    expected_hash = action.get("abm_source_hash")

    path = Path(directory).expanduser().resolve()
    with ReadOnlySource(path, take_id=take_id, expected_hash=expected_hash) as source:
        source.verify()
        target_dir = source.directory

    action["abm_source_path"] = str(target_dir)
    if rig and "abm_take_metadata" in rig:
        try:
            meta = json.loads(rig["abm_take_metadata"])
            if isinstance(meta, dict) and meta.get("take_id") == take_id:
                meta["source_path"] = str(target_dir)
                rig["abm_take_metadata"] = json.dumps(meta)
        except Exception:
            pass
    return target_dir


def archive_take(action, destination, rig=None, capture_directory=None) -> Path:
    """Archive a verified take to a new destination atomically, excluding secrets and mutable indexes."""
    from .journal import ReadOnlySource

    if not action or not action.get("abm_take_id"):
        raise ProtocolError("Action has no take ID")
    take_id = uid(action["abm_take_id"])
    expected_hash = action.get("abm_source_hash")
    src_dir = resolve_source_path(action, rig, capture_directory)
    if not src_dir or not src_dir.exists():
        raise ProtocolError("Source directory not found; locate source before archiving")

    with ReadOnlySource(src_dir, take_id=take_id, expected_hash=expected_hash) as source:
        source.verify()
        archived_path = source.archive_to(destination)
    return archived_path


def bake_store(
    rig, snapshot, store, start_frame=1, fps_numerator=30, fps_denominator=1, name="Mocap Take"
):
    """Offline/recovery path using identical solver and resampler with bounded pose memory."""
    from .protocol import decode
    from .journal import ReadOnlySource

    if isinstance(store, ReadOnlySource):
        return bake_source(rig, snapshot, store, start_frame, fps_numerator, fps_denominator, name)

    status = store.status()
    if not status["source_durable"]:
        raise ProtocolError("Verify source archive before final replay")
    writer = ActionWriter(
        rig, snapshot, store.take_id, name, start_frame, fps_numerator, fps_denominator
    )
    writer.start(status["start"]["t0"], status["end"]["t_stop"])
    try:
        for index, seq in enumerate(sorted(store.poses)):
            writer.feed(decode(store.journal.read(store.poses[seq]))[1])
            if index % 64 == 0:
                writer.flush()
        writer.finalize(status["source_hash"])
        return writer
    except Exception:
        writer.restore(remove=True)
        raise
