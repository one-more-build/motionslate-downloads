"""Deterministic humanoid source for repeatable capture and fault tests."""

from __future__ import annotations
import argparse
import asyncio
import base64
import dataclasses
import hashlib
import json
import math
from pathlib import Path
import ssl
import struct
import uuid

from .protocol import Pose, Schema, Kind, IDENTITY, ZERO, control, decode, frame
from .journal import TakeStore

# Anatomical offsets in ARKit's Y-up convention, relative to the parent joint.
JOINTS = [
    ("hips_joint", -1, (0, 0, 0)),
    ("spine_3_joint", 0, (0, 0.18, 0)),
    ("spine_7_joint", 1, (0, 0.20, 0)),
    ("neck_1_joint", 2, (0, 0.15, 0)),
    ("head_joint", 3, (0, 0.16, 0)),
    ("left_shoulder_1_joint", 2, (0.12, 0.04, 0)),
    ("left_arm_joint", 5, (0.13, 0, 0)),
    ("left_forearm_joint", 6, (0.28, 0, 0)),
    ("left_hand_joint", 7, (0.25, 0, 0)),
    ("right_shoulder_1_joint", 2, (-0.12, 0.04, 0)),
    ("right_arm_joint", 9, (-0.13, 0, 0)),
    ("right_forearm_joint", 10, (-0.28, 0, 0)),
    ("right_hand_joint", 11, (-0.25, 0, 0)),
    ("left_upLeg_joint", 0, (0.11, -0.05, 0)),
    ("left_leg_joint", 13, (0, -0.43, 0)),
    ("left_foot_joint", 14, (0, -0.43, 0)),
    ("right_upLeg_joint", 0, (-0.11, -0.05, 0)),
    ("right_leg_joint", 16, (0, -0.43, 0)),
    ("right_foot_joint", 17, (0, -0.43, 0)),
]


def multiply(a, b):
    return tuple(
        sum(a[k * 4 + r] * b[c * 4 + k] for k in range(4)) for c in range(4) for r in range(4)
    )


def transform(position=(0, 0, 0), angle=0, axis="z"):
    c, s = math.cos(angle), math.sin(angle)
    if axis == "z":
        values = (c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, *position, 1)
    elif axis == "y":
        values = (c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, *position, 1)
    else:
        values = (1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, *position, 1)
    return tuple(float(x) for x in values)


class SyntheticSource:
    def __init__(self, extra_joints=0, neutral=False):
        if not 0 <= extra_joints <= 256 - len(JOINTS):
            raise ValueError("Fixture joint count outside protocol limits")
        self.session = str(uuid.uuid4())
        self.segment = str(uuid.uuid4())
        self.body = str(uuid.uuid4())
        self.schema = Schema(
            str(uuid.uuid4()),
            tuple(j[0] for j in JOINTS) + tuple(f"fixture_extra_{i}" for i in range(extra_joints)),
            tuple(j[1] for j in JOINTS) + (0,) * extra_joints,
            "ABM.synthetic-humanoid-v1",
        )
        if neutral:
            self.schema = dataclasses.replace(self.schema, neutral_joints=self.pose(0, 100).joints)

    def pose(self, sequence, timestamp, motion_time=0, take_id=ZERO):
        t = motion_time
        joints = []
        for i, (name, parent, offset) in enumerate(JOINTS):
            angle = 0
            axis = "z"
            if t > 0:
                if name == "left_arm_joint":
                    angle = 0.65 * math.sin(t * 2.2)
                elif name == "left_forearm_joint":
                    angle = 0.6 * (1 - math.cos(t * 2.2))
                elif name == "right_arm_joint":
                    angle = -0.4 * math.sin(t * 1.7)
                elif name == "right_forearm_joint":
                    angle = -0.35 * (1 - math.cos(t * 1.7))
                elif name in {"left_upLeg_joint", "right_upLeg_joint"}:
                    angle = 0.25 * math.sin(t * 2)
                    axis = "x"
                elif name in {"left_leg_joint", "right_leg_joint"}:
                    angle = -0.4 * abs(math.sin(t * 2))
                    axis = "x"
            local = transform(offset, angle, axis)
            joints.append(local if parent == -1 else multiply(joints[parent], local))
        joints.extend([joints[0]] * (len(self.schema.joint_names) - len(joints)))
        anchor = transform(
            (0.12 * t, 1 - 0.12 * abs(math.sin(t * 2)), 0.1 * math.sin(t)),
            0.15 * math.sin(t * 0.7),
            "y",
        )
        return Pose(
            self.session,
            self.segment,
            self.body,
            take_id,
            self.schema.schema_id,
            sequence,
            timestamp,
            0x27,
            1.0,
            anchor,
            IDENTITY,
            (True,) * len(joints),
            (True,) * len(joints),
            tuple(joints),
        )

    def write_take(self, root, duration=10, rate=60):
        take_id = str(uuid.uuid4())
        store = TakeStore(root, take_id)
        store.append(control(Kind.SCHEMA, self.schema.body()))
        event_base = dict(take_id=take_id, session_id=self.session, segment_id=self.segment)
        store.append(control(Kind.EVENT, dict(event_base, event="TAKE_PREPARED", event_seq=0)))
        store.append(
            control(
                Kind.EVENT,
                dict(event_base, event="TAKE_STARTED", event_seq=1, t0=100.0, first_sequence=0),
            )
        )
        count = math.ceil(duration * rate) + 2
        for index in range(count):
            store.append(
                self.pose(index, 100 + index / rate, index / rate, take_id).encode(), sync=False
            )
        store.append(
            control(
                Kind.EVENT,
                dict(
                    event_base,
                    event="TAKE_ENDED",
                    event_seq=2,
                    t_stop=100.0 + duration,
                    first_sequence=0,
                    last_sequence=count - 1,
                    reason="duration",
                ),
            )
        )
        store.finalize()
        return store


def parse_pairing_payload(text: str) -> dict[str, str]:
    text = text.strip()
    if text.startswith("ms1:"):
        b64 = text[4:]
        padded = b64 + "=" * ((4 - len(b64) % 4) % 4)
        return json.loads(base64.urlsafe_b64decode(padded.encode("ascii")).decode("utf-8"))
    if text.startswith("{"):
        return json.loads(text)
    raise ValueError("Invalid pairing payload format")


async def live(args):
    source = SyntheticSource(args.extra_joints, args.neutral_reference)

    endpoint_host = args.host
    endpoint_port = args.port
    token = None
    expected_fingerprint = None

    pairing_path = None
    if getattr(args, "pairing_file", None):
        pairing_path = Path(args.pairing_file).expanduser()
    elif getattr(args, "token_file", None):
        sibling = Path(args.token_file).expanduser().parent / "pairing.txt"
        if sibling.exists():
            pairing_path = sibling

    if pairing_path and pairing_path.exists():
        try:
            payload_data = parse_pairing_payload(pairing_path.read_text())
            token = payload_data.get("token")
            expected_fingerprint = payload_data.get("fingerprint", "").lower()
            if payload_data.get("endpoint"):
                parts = payload_data["endpoint"].split(":")
                if len(parts) == 2:
                    endpoint_host = parts[0]
                    endpoint_port = int(parts[1])
        except Exception as exc:
            print(f"Warning: Failed to parse pairing file {pairing_path}: {exc}")

    if token is None and args.token_file:
        token = Path(args.token_file).expanduser().read_text().strip()

    ssl_context = None
    if expected_fingerprint:
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

    reader, writer = await asyncio.open_connection(endpoint_host, endpoint_port, ssl=ssl_context)
    if expected_fingerprint:
        ssl_obj = writer.get_extra_info("ssl_object")
        if not ssl_obj:
            writer.close()
            await writer.wait_closed()
            raise RuntimeError("Expected TLS connection but got plaintext")
        der_cert = ssl_obj.getpeercert(binary_form=True)
        if not der_cert:
            writer.close()
            await writer.wait_closed()
            raise RuntimeError("No certificate received from server")
        actual_fp = hashlib.sha256(der_cert).hexdigest().lower()
        norm_expected = expected_fingerprint.lower().replace("sha256:", "").replace(":", "").strip()
        if actual_fp != norm_expected:
            writer.close()
            await writer.wait_closed()
            raise RuntimeError(
                f"Certificate fingerprint mismatch: expected {expected_fingerprint}, got {actual_fp}"
            )

    async def send(payload):
        writer.write(frame(payload))
        await writer.drain()

    await send(
        control(
            Kind.HELLO,
            dict(
                role="phone",
                token=token,
                protocol=2,
                features=["journal-v1"],
                connection_id=str(uuid.uuid4()),
                session_id=source.session,
            ),
        )
    )
    await send(control(Kind.SCHEMA, source.schema.body()))
    state = dict(
        store=None,
        take_id=ZERO,
        phase="IDLE",
        event_seq=0,
        t0=None,
        scheduled=None,
        first=None,
        last=None,
        duration=10,
        stop=None,
        calibration_end=None,
        ready=False,
        requests=set(),
    )

    async def event(name, **fields):
        body = dict(
            event=name,
            event_seq=state["event_seq"],
            take_id=state["take_id"],
            session_id=source.session,
            segment_id=source.segment,
            **fields,
        )
        state["event_seq"] += 1
        payload = control(Kind.EVENT, body)
        state["store"].append(payload)
        await send(payload)

    async def drain():
        while True:
            length = struct.unpack(">I", await reader.readexactly(4))[0]
            kind, body = decode(await reader.readexactly(length))
            if kind == Kind.STATUS and body.get("error"):
                raise RuntimeError(body["error"])
            if kind == Kind.STATUS and body.get("schema_ready"):
                state["ready"] = True
            if kind == Kind.COMMAND:
                request = body.get("request_id")
                if request in state["requests"]:
                    continue
                state["requests"].add(request)
                command = body.get("command")
                values = body.get("args", {})
                if command == "PREPARE_TAKE":
                    state.update(
                        take_id=body["take_id"],
                        phase="PREPARED",
                        event_seq=0,
                        t0=None,
                        first=None,
                        last=None,
                        stop=None,
                        duration=values["duration_seconds"],
                        countdown=values["countdown_seconds"],
                    )
                    state["store"] = TakeStore(args.output, state["take_id"])
                    state["store"].append(control(Kind.SCHEMA, source.schema.body()))
                    await event("TAKE_PREPARED")
                elif command == "START_COUNTDOWN":
                    state["scheduled"] = asyncio.get_running_loop().time() + state["countdown"]
                    state["phase"] = "COUNTDOWN"
                elif command == "STOP_TAKE":
                    if state["t0"] is not None:
                        state["stop"] = 100 + asyncio.get_running_loop().time() - begin
                    else:
                        await event("TAKE_CANCELLED")
                        state["phase"] = "ENDED"
                        state["take_id"] = ZERO
                elif command == "CANCEL_TAKE":
                    await event("TAKE_CANCELLED")
                    state["phase"] = "ENDED"
                    state["take_id"] = ZERO
                elif command == "CALIBRATE_COUNTDOWN":
                    state["calibration_end"] = (
                        asyncio.get_running_loop().time()
                        + values.get("countdown_seconds", 5)
                        + 1.25
                    )
                elif command == "REQUEST_MISSING_RANGES" and state["store"]:
                    store = state["store"]
                    for record in store.records:
                        await send(store.journal.read(record))
                    await send(
                        control(
                            Kind.QUERY,
                            dict(
                                kind="FINALIZE_SOURCE",
                                request_id=str(uuid.uuid4()),
                                take_id=store.take_id,
                                source_hash=store.canonical_hash(),
                            ),
                        )
                    )

    task = asyncio.create_task(drain())
    begin = asyncio.get_running_loop().time()
    sequence = 0
    try:
        while True:
            t = asyncio.get_running_loop().time() - begin
            if t >= args.duration:
                break
            now = asyncio.get_running_loop().time()
            stationary = t < args.reference_seconds or (
                state["calibration_end"] and now < state["calibration_end"]
            )
            motion = (
                0
                if stationary
                else (100 + t - state["t0"] if state["t0"] else max(0, t - args.reference_seconds))
            )
            if state["phase"] == "COUNTDOWN" and now >= state["scheduled"]:
                state["t0"] = 100 + t
                state["phase"] = "RECORDING"
                state["stop"] = state["t0"] + state["duration"]
                await event("TAKE_STARTED", t0=state["t0"], first_sequence=sequence)
            payload = source.pose(sequence, 100 + t, motion, state["take_id"]).encode()
            if state["take_id"] != ZERO:
                if state["first"] is None:
                    state["first"] = sequence
                state["last"] = sequence
                state["store"].append(payload)
            if state["ready"]:
                await send(payload)
            if state["phase"] == "RECORDING" and 100 + t >= state["stop"]:
                await event(
                    "TAKE_ENDED",
                    t_stop=state["stop"],
                    first_sequence=state["first"],
                    last_sequence=sequence,
                    reason="duration",
                )
                store = state["store"]
                store.finalize()
                await send(
                    control(
                        Kind.QUERY,
                        dict(
                            kind="FINALIZE_SOURCE",
                            request_id=str(uuid.uuid4()),
                            take_id=state["take_id"],
                            source_hash=store.canonical_hash(),
                        ),
                    )
                )
                state["phase"] = "ENDED"
                state["take_id"] = ZERO
            sequence += 1
            await asyncio.sleep(
                max(0, begin + sequence / args.rate - asyncio.get_running_loop().time())
            )
            if task.done():
                await task
    finally:
        writer.close()
        await writer.wait_closed()
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)
        if state["store"]:
            state["store"].close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="output/synthetic-captures")
    parser.add_argument("--duration", type=float, default=10)
    parser.add_argument("--rate", type=int, default=60)
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=9000)
    parser.add_argument("--token-file", default="~/Movies/MotionSlate/pairing-token.txt")
    parser.add_argument("--pairing-file", help="Path to pairing.txt payload")
    parser.add_argument("--reference-seconds", type=float, default=5)
    parser.add_argument("--extra-joints", type=int, default=0)
    parser.add_argument("--neutral-reference", action="store_true")
    args = parser.parse_args()
    if not 0.1 <= args.duration <= 3600 or not 1 <= args.rate <= 120:
        parser.error("Duration/rate outside supported limits")
    if args.live:
        asyncio.run(live(args))
    else:
        store = SyntheticSource().write_take(args.output, args.duration, args.rate)
        print(store.directory.resolve())
        store.close()


if __name__ == "__main__":
    main()
