"""ABM2 local management service protocol and message validation.

Defines wire contracts for the loopback-only 'manager' role:
- Allowlisted operations: status, claim, release, stop-when-idle.
- Explicit validation of request schemas and controller IDs.
- Forbids pose uploads, source finalization, or coordinator direct manipulation.
"""

from __future__ import annotations
import uuid

from .protocol import ProtocolError, uid

MANAGEMENT_PROTOCOL = "managed-recorder-v1"
MANAGEMENT_ROLE = "manager"
MANAGEMENT_OPERATIONS = frozenset({"status", "claim", "release", "stop-when-idle"})


def build_management_hello(
    token: str,
    connection_id: str | None = None,
    features: list[str] | None = None,
) -> dict:
    """Build the HELLO handshake payload for a manager client."""
    if not isinstance(token, str) or not token.strip():
        raise ProtocolError("Management token must be a non-empty string")
    return dict(
        role=MANAGEMENT_ROLE,
        protocol=2,
        management_protocol=MANAGEMENT_PROTOCOL,
        features=list(features or [MANAGEMENT_PROTOCOL, "journal-v1"]),
        token=token.strip(),
        connection_id=uid(connection_id) if connection_id else str(uuid.uuid4()),
    )


def validate_management_hello(body: dict) -> dict:
    """Validate a received manager HELLO payload."""
    if not isinstance(body, dict):
        raise ProtocolError("Expected JSON object in HELLO payload")
    if body.get("role") != MANAGEMENT_ROLE:
        raise ProtocolError(f"Expected role '{MANAGEMENT_ROLE}', got '{body.get('role')}'")
    if body.get("protocol") != 2:
        raise ProtocolError("Required protocol version 2 unavailable")
    features = body.get("features", [])
    if (
        body.get("management_protocol") != MANAGEMENT_PROTOCOL
        and MANAGEMENT_PROTOCOL not in features
    ):
        raise ProtocolError(f"Management protocol '{MANAGEMENT_PROTOCOL}' is required")
    token = body.get("token")
    if not isinstance(token, str) or not token.strip():
        raise ProtocolError("Missing or invalid management token")
    uid(body.get("connection_id"))
    return body


def build_management_request(
    operation: str,
    request_id: str | None = None,
    controller_id: str | None = None,
    **kwargs,
) -> dict:
    """Build a management request payload."""
    if operation not in MANAGEMENT_OPERATIONS:
        raise ProtocolError(f"Unknown management operation '{operation}'")
    req = dict(
        request_id=uid(request_id) if request_id else str(uuid.uuid4()),
        operation=operation,
    )
    if controller_id is not None:
        req["controller_id"] = uid(controller_id)
    req.update(kwargs)
    return req


def validate_management_request(body: dict) -> dict:
    """Validate a received management request payload."""
    if not isinstance(body, dict):
        raise ProtocolError("Management request must be a JSON object")
    request_id = uid(body.get("request_id"))
    operation = body.get("operation") or body.get("command") or body.get("kind")
    if not isinstance(operation, str) or operation not in MANAGEMENT_OPERATIONS:
        raise ProtocolError(f"Unknown management operation '{operation}'")

    validated = dict(body, request_id=request_id, operation=operation)
    if "controller_id" in body and body["controller_id"] is not None:
        validated["controller_id"] = uid(body["controller_id"])
    return validated


def build_management_response(
    operation: str,
    request_id: str,
    accepted: bool = True,
    **kwargs,
) -> dict:
    """Build a management response payload (Kind.STATUS)."""
    if operation not in MANAGEMENT_OPERATIONS:
        raise ProtocolError(f"Unknown management operation '{operation}'")
    res = dict(
        request_id=uid(request_id),
        operation=operation,
        accepted=bool(accepted),
        management_protocol=MANAGEMENT_PROTOCOL,
    )
    res.update(kwargs)
    return res


def validate_management_response(body: dict) -> dict:
    """Validate a received management response payload."""
    if not isinstance(body, dict):
        raise ProtocolError("Management response must be a JSON object")
    uid(body.get("request_id"))
    operation = body.get("operation")
    if not isinstance(operation, str) or operation not in MANAGEMENT_OPERATIONS:
        raise ProtocolError(f"Unknown management operation '{operation}'")
    if "accepted" in body and not isinstance(body["accepted"], bool):
        raise ProtocolError("Response 'accepted' field must be a boolean")
    return body
