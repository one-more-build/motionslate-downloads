"""Deterministic FK solver. Run with Blender's bundled mathutils."""

from __future__ import annotations
import hashlib
import math
import copy
from mathutils import Matrix, Quaternion, Vector
from .protocol import ProtocolError, json_bytes

AXES = Matrix(((1, 0, 0, 0), (0, 0, -1, 0), (0, 1, 0, 0), (0, 0, 0, 1)))


def matrix(values):
    return Matrix((values[0::4], values[1::4], values[2::4], values[3::4]))


def flatten(value):
    return [float(value[r][c]) for c in range(4) for r in range(4)]


def rig_fingerprint(rig):
    value = dict(
        world=flatten(rig.matrix_world),
        bones=[
            dict(
                name=b.name,
                parent=b.parent.name if b.parent else None,
                rest=flatten(b.matrix_local),
                inherit_scale=b.inherit_scale,
                local_location=b.use_local_location,
                inherit_rotation=b.use_inherit_rotation,
                connected=b.use_connect,
            )
            for b in rig.data.bones
        ],
    )
    return hashlib.sha256(json_bytes(value)).hexdigest()


ARKit_JOINTS = (
    "hips_joint",
    "spine_3_joint",
    "spine_7_joint",
    "neck_1_joint",
    "head_joint",
    "left_shoulder_1_joint",
    "left_arm_joint",
    "left_forearm_joint",
    "left_hand_joint",
    "right_shoulder_1_joint",
    "right_arm_joint",
    "right_forearm_joint",
    "right_hand_joint",
    "left_upLeg_joint",
    "left_leg_joint",
    "left_foot_joint",
    "right_upLeg_joint",
    "right_leg_joint",
    "right_foot_joint",
)

DEMO_MAPPING = {name: name for name in ARKit_JOINTS}

MIXAMO_MAPPING = {
    "hips_joint": "mixamorig:Hips",
    "spine_3_joint": "mixamorig:Spine",
    "spine_7_joint": "mixamorig:Spine2",
    "neck_1_joint": "mixamorig:Neck",
    "head_joint": "mixamorig:Head",
    "left_shoulder_1_joint": "mixamorig:LeftShoulder",
    "left_arm_joint": "mixamorig:LeftArm",
    "left_forearm_joint": "mixamorig:LeftForeArm",
    "left_hand_joint": "mixamorig:LeftHand",
    "right_shoulder_1_joint": "mixamorig:RightShoulder",
    "right_arm_joint": "mixamorig:RightArm",
    "right_forearm_joint": "mixamorig:RightForeArm",
    "right_hand_joint": "mixamorig:RightHand",
    "left_upLeg_joint": "mixamorig:LeftUpLeg",
    "left_leg_joint": "mixamorig:LeftLeg",
    "left_foot_joint": "mixamorig:LeftFoot",
    "right_upLeg_joint": "mixamorig:RightUpLeg",
    "right_leg_joint": "mixamorig:RightLeg",
    "right_foot_joint": "mixamorig:RightFoot",
}

RIGIFY_FK_MAPPING = {
    "hips_joint": "torso",
    "spine_3_joint": "chest",
    "spine_7_joint": "chest.001",
    "neck_1_joint": "neck",
    "head_joint": "head",
    "left_shoulder_1_joint": "shoulder.L",
    "left_arm_joint": "upper_arm.fk.L",
    "left_forearm_joint": "forearm.fk.L",
    "left_hand_joint": "hand.fk.L",
    "right_shoulder_1_joint": "shoulder.R",
    "right_arm_joint": "upper_arm.fk.R",
    "right_forearm_joint": "forearm.fk.R",
    "right_hand_joint": "hand.fk.R",
    "left_upLeg_joint": "thigh.fk.L",
    "left_leg_joint": "shin.fk.L",
    "left_foot_joint": "foot.fk.L",
    "right_upLeg_joint": "thigh.fk.R",
    "right_leg_joint": "shin.fk.R",
    "right_foot_joint": "foot.fk.R",
}

BUILTIN_PRESETS = {
    "DEMO": DEMO_MAPPING,
    "MIXAMO": MIXAMO_MAPPING,
    "RIGIFY": RIGIFY_FK_MAPPING,
}


def get_preset_mapping(preset_name: str, rig=None) -> dict[str, str]:
    """Return a mapping dictionary for the given preset name, optionally filtered by rig bones."""
    preset = BUILTIN_PRESETS.get(preset_name.upper(), DEMO_MAPPING)
    if rig is not None and hasattr(rig, "pose") and rig.pose:
        available = set(rig.pose.bones.keys())
        return {k: v for k, v in preset.items() if v in available}
    return dict(preset)


def preflight_rig(rig, mapping: dict[str, str] | None = None) -> list[str]:
    """Return a list of human-readable issues if rig or mapping fails acceptance rules."""
    issues = []
    if (
        rig is None
        or rig.type != "ARMATURE"
        or getattr(rig, "library", None)
        or getattr(rig.data, "library", None)
    ):
        return ["Select a local editable armature"]
    if mapping is not None:
        if not mapping:
            issues.append("Mapping cannot be empty")
        elif len(set(mapping.values())) != len(mapping):
            issues.append("Mapping must have unique target bones")
    scale = rig.matrix_world.to_scale()
    if rig.matrix_world.determinant() <= 0 or min(scale) <= 0 or max(scale) - min(scale) > 1e-5:
        issues.append("Armature must have positive uniform scale")
    if rig.constraints or (rig.animation_data and rig.animation_data.drivers):
        issues.append("Armature constraints/drivers need a control-rig adapter")
    if hasattr(rig, "pose") and rig.pose:
        for bone in rig.pose.bones:
            if bone.constraints:
                issues.append(f"{bone.name} has constraints; use an FK rig or a rig adapter")
            if max(abs(x - 1) for x in bone.scale) > 1e-5:
                issues.append(f"{bone.name} uses pose scaling; apply a supported reference pose")
            if bone.bone.inherit_scale != "FULL" or not bone.bone.use_inherit_rotation:
                issues.append(f"{bone.name} has unsupported inheritance settings")
    if mapping:
        for target in mapping.values():
            if not hasattr(rig, "pose") or not rig.pose or target not in rig.pose.bones:
                issues.append(f"Missing mapped bone: {target}")
    return issues


def validate_rig(rig, mapping):
    issues = preflight_rig(rig, mapping)
    if issues:
        raise ProtocolError(issues[0])


def average_quaternions(values):
    reference = values[0]
    total = Vector((0.0, 0.0, 0.0, 0.0))
    for value in values:
        sign = -1 if reference.dot(value) < 0 else 1
        total += Vector(tuple(sign * x for x in value))
    return Quaternion(total).normalized()


def calibrate(
    rig,
    schema,
    mapping,
    samples,
    root_source="hips_joint",
    mode="WORLD",
    travel_scale=1.0,
    heading_degrees=0.0,
):
    validate_rig(rig, mapping)
    if root_source not in mapping:
        raise ProtocolError("Map the source pelvis/root")
    if mode not in {"WORLD", "IN_PLACE"} or not math.isfinite(travel_scale) or travel_scale <= 0:
        raise ProtocolError("Invalid root-motion policy")
    if len(samples) < 10 or samples[-1].timestamp - samples[0].timestamp < 0.5:
        raise ProtocolError("Calibration needs at least half a second of stable samples")
    indices = {
        name: schema.joint_names.index(name) for name in mapping if name in schema.joint_names
    }
    if len(indices) != len(mapping):
        raise ProtocolError("Mapping refers to missing source joints")
    identity = (samples[0].session_id, samples[0].segment_id, samples[0].body_id)
    for p in samples:
        if (
            (p.session_id, p.segment_id, p.body_id) != identity
            or p.schema_id != schema.schema_id
            or not p.usable
            or not all(p.valid[i] for i in indices.values())
        ):
            raise ProtocolError("Tracking changed during calibration")
    conversion = Matrix.Rotation(math.radians(heading_degrees), 4, "Z") @ AXES
    world_inverse = rig.matrix_world.inverted()
    rotation_inverse = rig.matrix_world.to_quaternion().inverted().to_matrix()
    world_rotations = {name: [] for name in mapping}
    positions = []
    for p in samples:
        anchor = matrix(p.anchor)
        for name, index in indices.items():
            native = anchor @ matrix(p.joints[index])
            rotation = (
                rotation_inverse @ conversion.to_3x3() @ native.to_3x3() @ AXES.to_3x3().inverted()
            )
            world_rotations[name].append(rotation.to_quaternion().normalized())
        positions.append(
            world_inverse
            @ (conversion @ (anchor @ matrix(p.joints[indices[root_source]])).translation)
        )
    center = sum(positions, Vector((0, 0, 0))) / len(positions)
    if max((p - center).length for p in positions) > 0.03:
        raise ProtocolError("Hold still: pelvis moved during calibration")
    source = {}
    for name, values in world_rotations.items():
        avg = average_quaternions(values)
        if max(avg.rotation_difference(q).angle for q in values) > math.radians(8):
            raise ProtocolError(f"Hold the reference pose: {name} moved")
        source[name] = list(avg)
    return dict(
        version=1,
        solver="global-fk-v1",
        rig_fingerprint=rig_fingerprint(rig),
        schema_id=schema.schema_id,
        session_id=identity[0],
        segment_id=identity[1],
        body_id=identity[2],
        mapping=dict(mapping),
        root_source=root_source,
        mode=mode,
        travel_scale=travel_scale,
        heading_degrees=heading_degrees,
        source_reference=source,
        source_root=list(center),
        tracking_sources=[
            name for name, i in indices.items() if any(p.tracked[i] for p in samples)
        ],
        target_reference={p.name: flatten(p.matrix) for p in rig.pose.bones},
        target_basis={p.name: flatten(p.matrix_basis) for p in rig.pose.bones},
        target_world=flatten(rig.matrix_world),
        source_indices=indices,
    )


def neutral_reference(
    rig,
    schema,
    mapping,
    pose,
    root_source="hips_joint",
    mode="WORLD",
    travel_scale=1.0,
    heading_degrees=0.0,
):
    validate_rig(rig, mapping)
    if schema.neutral_joints is None:
        raise ProtocolError("Source has no neutral skeleton")
    if root_source not in mapping or not pose.usable:
        raise ProtocolError("Usable pelvis tracking is required")
    indices = {
        name: schema.joint_names.index(name) for name in mapping if name in schema.joint_names
    }
    if len(indices) != len(mapping):
        raise ProtocolError("Mapping refers to missing source joints")
    conversion = Matrix.Rotation(math.radians(heading_degrees), 4, "Z") @ AXES
    inverse = rig.matrix_world.inverted()
    rotation_inverse = rig.matrix_world.to_quaternion().inverted().to_matrix()
    source = {
        name: list(
            (
                rotation_inverse
                @ conversion.to_3x3()
                @ matrix(schema.neutral_joints[i]).to_3x3()
                @ AXES.to_3x3().inverted()
            )
            .to_quaternion()
            .normalized()
        )
        for name, i in indices.items()
    }
    root = inverse @ (
        conversion @ (matrix(pose.anchor) @ matrix(pose.joints[indices[root_source]])).translation
    )
    return dict(
        version=1,
        solver="global-fk-v1",
        reference_kind="NEUTRAL",
        rig_fingerprint=rig_fingerprint(rig),
        schema_id=schema.schema_id,
        session_id=pose.session_id,
        segment_id=pose.segment_id,
        body_id=pose.body_id,
        mapping=dict(mapping),
        root_source=root_source,
        mode=mode,
        travel_scale=travel_scale,
        heading_degrees=heading_degrees,
        source_reference=source,
        source_root=list(root),
        tracking_sources=[name for name, i in indices.items() if pose.tracked[i]],
        target_reference={p.name: flatten(p.matrix) for p in rig.pose.bones},
        target_basis={p.name: flatten(p.matrix_basis) for p in rig.pose.bones},
        target_world=flatten(rig.matrix_world),
        source_indices=indices,
    )


def recenter_reference(rig, snapshot, pose):
    """Reset floor position/yaw while retaining reference offsets and vertical motion."""
    solver = FKSolver(rig, snapshot)
    if not solver.accepts(pose):
        raise ProtocolError("Usable body tracking is required to recenter")
    root = snapshot["root_source"]
    index = snapshot["source_indices"][root]
    native = matrix(pose.anchor) @ matrix(pose.joints[index])
    world = matrix(snapshot["target_world"])
    world_rotation = world.to_quaternion()
    current = (
        (
            solver.rotation_inverse
            @ solver.conversion.to_3x3()
            @ native.to_3x3()
            @ AXES.to_3x3().inverted()
        )
        .to_quaternion()
        .normalized()
    )
    reference = Quaternion(snapshot["source_reference"][root])
    forward = Vector((0, -1, 0))
    a = world_rotation @ current @ forward
    b = world_rotation @ reference @ forward
    if math.hypot(a.x, a.y) < 0.1 or math.hypot(b.x, b.y) < 0.1:
        raise ProtocolError("Stand upright so facing direction can be determined")
    yaw = math.atan2(a.y, a.x) - math.atan2(b.y, b.x)
    result = copy.deepcopy(snapshot)
    result["heading_degrees"] = (snapshot["heading_degrees"] - math.degrees(yaw) + 180) % 360 - 180
    conversion = Matrix.Rotation(math.radians(result["heading_degrees"]), 4, "Z") @ AXES
    origin = conversion @ native.translation
    origin.z = (world @ Vector(snapshot["source_root"])).z
    result["source_root"] = list(world.inverted() @ origin)
    result["recenter_sequence"] = pose.sequence
    result["recenter_timestamp"] = pose.timestamp
    return result


class FKSolver:
    def __init__(self, rig, snapshot):
        self.rig = rig
        self.snapshot = snapshot
        validate_rig(rig, snapshot["mapping"])
        if snapshot["rig_fingerprint"] != rig_fingerprint(rig):
            raise ProtocolError("Rig changed since calibration")
        self.conversion = Matrix.Rotation(math.radians(snapshot["heading_degrees"]), 4, "Z") @ AXES
        self.world_inverse = matrix(snapshot["target_world"]).inverted()
        self.rotation_inverse = (
            matrix(snapshot["target_world"]).to_quaternion().inverted().to_matrix()
        )
        self.target_reference = {n: matrix(m) for n, m in snapshot["target_reference"].items()}
        self.target_rotations = {n: m.to_quaternion() for n, m in self.target_reference.items()}
        self.source_rotations = {
            n: Quaternion(q).inverted() for n, q in snapshot["source_reference"].items()
        }
        self.source_axes = self.rotation_inverse @ self.conversion.to_3x3()
        self.inverse_axes = AXES.to_3x3().inverted()
        self.basis_reference = {n: matrix(m) for n, m in snapshot["target_basis"].items()}
        self.reverse = {target: source for source, target in snapshot["mapping"].items()}
        self.root_target = snapshot["mapping"][snapshot["root_source"]]
        self.order = []

        def walk(bone):
            self.order.append(bone)
            for child in bone.children:
                walk(child)

        for bone in rig.pose.bones:
            if bone.parent is None:
                walk(bone)

    def accepts(self, pose):
        s = self.snapshot
        return (
            pose.usable
            and pose.schema_id == s["schema_id"]
            and pose.session_id == s["session_id"]
            and pose.segment_id == s["segment_id"]
            and pose.body_id == s["body_id"]
            and all(pose.valid[index] for index in s["source_indices"].values())
        )

    def solve(self, pose):
        if not self.accepts(pose):
            raise ProtocolError("Pose is incompatible with calibration or tracking is unusable")
        s = self.snapshot
        anchor = matrix(pose.anchor)
        root_native = anchor @ matrix(pose.joints[s["source_indices"][s["root_source"]]])
        root = self.world_inverse @ (self.conversion @ root_native.translation)
        delta = (root - Vector(s["source_root"])) * s["travel_scale"]
        if s["mode"] == "IN_PLACE":
            # Remove horizontal displacement in Blender world space, including rotated armatures.
            world_delta = matrix(s["target_world"]).to_3x3() @ delta
            world_delta.x = world_delta.y = 0
            delta = self.world_inverse.to_3x3() @ world_delta
        desired = {}
        basis = {}
        for bone in self.order:
            parent = bone.parent
            kwargs = (
                dict(
                    parent_matrix=desired[parent.name], parent_matrix_local=parent.bone.matrix_local
                )
                if parent
                else {}
            )
            inherited = bone.bone.convert_local_to_pose(
                self.basis_reference[bone.name], bone.bone.matrix_local, **kwargs
            )
            if bone.name in self.reverse:
                name = self.reverse[bone.name]
                index = s["source_indices"][name]
                native = anchor @ matrix(pose.joints[index])
                source_rotation = (
                    (self.source_axes @ native.to_3x3() @ self.inverse_axes)
                    .to_quaternion()
                    .normalized()
                )
                target_rotation = (
                    source_rotation @ self.source_rotations[name] @ self.target_rotations[bone.name]
                )
                location = inherited.translation
                if bone.name == self.root_target:
                    location = self.target_reference[bone.name].translation + delta
                pose_matrix = Matrix.LocRotScale(location, target_rotation, Vector((1, 1, 1)))
                basis[bone.name] = bone.bone.convert_local_to_pose(
                    pose_matrix, bone.bone.matrix_local, invert=True, **kwargs
                )
                desired[bone.name] = pose_matrix
            else:
                basis[bone.name] = self.basis_reference[bone.name].copy()
                desired[bone.name] = inherited
        return basis

    def apply(self, basis):
        for name, value in basis.items():
            self.rig.pose.bones[name].matrix_basis = value
