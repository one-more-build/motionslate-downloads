"""Blender main-thread UI and bounded loopback client."""

from collections import deque
import errno
import json
from pathlib import Path
import socket
import select
import time
import uuid
import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    StringProperty,
    IntProperty,
    FloatProperty,
    BoolProperty,
    EnumProperty,
    PointerProperty,
    CollectionProperty,
)
from bpy.types import Operator, Panel, PropertyGroup
from .protocol import Framer, Kind, Schema, ProtocolError, control, decode, frame, ZERO
from .retarget import (
    calibrate,
    neutral_reference,
    recenter_reference,
    rig_fingerprint,
    preflight_rig,
    get_preset_mapping,
    ARKit_JOINTS,
    AXES,
    matrix,
)
from .motion import MotionSolver
from .quality import configuration
from .animation import ActionWriter, RebuildJob, relink_source, archive_take
from .preview import PreviewConnection
from .floor import observed_floor
from .refinement import RefinementJob
from .recorder_service import get_service_supervisor


class Runtime:
    def __init__(self):
        self.sock = None
        self.connecting = False
        self.authorized = False
        self.parser = Framer()
        self.out = bytearray()
        self.messages = deque()
        self.query = None
        self.last_poll = 0.0
        self.status = "Disconnected"
        self.schema = None
        self.latest = None
        self.samples = deque(maxlen=120)
        self.snapshot = None
        self.solver = None
        self.writer = None
        self.take_id = None
        self.cursor = 0
        self.active = None
        self.source_status = {}
        self.calibration_deadline = None
        self.record_when_prepared = False
        self.live_preview = False
        self.source_objects = []
        self.next_status = 0.0
        self.start_event = None
        self.capture_error = None
        self.replaying = False
        self.provisional_writer = None
        self.prepare_request = None
        self.source_age = float("inf")
        self.source_status_time = 0.0
        self.last_timeline_frame = None
        self.preview_connection = None
        self.preview_available = False
        self.applied_pose = None
        self.preview_updates = 0
        self.preview_times = deque(maxlen=120)
        self.recenter_results = {}
        self.work = None
        self.refinement = None
        self.rebuild = None
        self.metrics = None
        self.last_floor_time = None
        self.floor_candidates = deque(maxlen=5)
        self.timings = deque(maxlen=600)
        self.last_source_draw = 0.0
        self.last_redraw = 0.0

    def settings(self):
        return bpy.context.scene.abm_settings

    def connect(self):
        self.disconnect()
        s = self.settings()
        wm = getattr(bpy.context, "window_manager", None)
        manual_token = getattr(wm, "abm_manual_token", "") if wm else ""

        supervisor = get_service_supervisor()
        try:
            port, controller_id, token = supervisor.connect_service(
                captures_dir=s.capture_directory,
                blender_port=s.port,
                manual_token=manual_token,
            )
        except Exception as exc:
            self.status = f"Recorder service error: {exc}"
            raise

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setblocking(False)
        code = self.sock.connect_ex(("127.0.0.1", port))
        if code not in (0, errno.EINPROGRESS, errno.EWOULDBLOCK, errno.EALREADY):
            self.sock.close()
            self.sock = None
            raise ProtocolError("Cannot reach recorder")
        self.connecting = True
        self.status = "Connecting"
        self.live_preview = True
        self.preview_connection = PreviewConnection(port, token, controller_id=controller_id)
        self.send(
            Kind.HELLO,
            dict(
                role="blender",
                protocol=2,
                features=["journal-v1"],
                token=token,
                controller_id=controller_id,
                connection_id=str(uuid.uuid4()),
            ),
        )

    def disconnect(self):
        if self.preview_connection:
            self.preview_connection.close()
        self.preview_connection = None
        self.preview_available = False
        self.applied_pose = None
        self.cancel_refinement()
        self.cancel_rebuild()
        if self.work:
            self.work.close()
            self.work = None
        if self.sock:
            self.sock.close()
        self.sock = None
        self.connecting = False
        self.authorized = False
        self.query = None
        self.out.clear()
        self.messages.clear()
        self.parser = Framer()
        self.live_preview = False
        self.status = "Disconnected"

    def send(self, kind, body):
        data = frame(control(kind, body))
        if len(self.out) + len(data) > 2 * 1024 * 1024:
            raise ProtocolError("Loopback send queue exceeded limit")
        self.out.extend(data)

    def command(self, name, take_id=None, args=None):
        request = str(uuid.uuid4())
        self.send(
            Kind.COMMAND, dict(command=name, request_id=request, take_id=take_id, args=args or {})
        )
        return request

    def request(self, kind, **kwargs):
        if self.query:
            return
        request = str(uuid.uuid4())
        self.query = (kind, request, time.monotonic())
        self.send(Kind.QUERY, dict(kind=kind, request_id=request, **kwargs))

    def tick(self):
        started = time.perf_counter()
        try:
            self.tick_budget(started + 0.008)
        finally:
            elapsed = (time.perf_counter() - started) * 1000
            self.timings.append(elapsed)

    def tick_budget(self, deadline):
        changed = False
        if self.refinement:
            try:
                while time.perf_counter() < deadline:
                    next(self.refinement.iterator)
            except StopIteration:
                job = self.refinement
                self.settings().take_action = job.writer.action
                self.status = job.progress
                self.refinement = None
            except Exception:
                self.cancel_refinement()
                raise
            if self.refinement:
                self.status = self.refinement.progress
            self.redraw()
            return
        if self.rebuild:
            try:
                while time.perf_counter() < deadline:
                    next(self.rebuild.iterator)
            except StopIteration:
                job = self.rebuild
                self.settings().take_action = job.writer.action
                self.status = job.progress
                self.rebuild = None
            except Exception:
                self.cancel_rebuild()
                raise
            if self.rebuild:
                self.status = self.rebuild.progress
            self.redraw()
            return
        if not self.sock:
            return
        if self.connecting:
            if not select.select([], [self.sock], [self.sock], 0)[1]:
                return
            error = self.sock.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
            if error:
                raise ConnectionError(f"Recorder connection failed ({error})")
            self.connecting = False
        if self.preview_available and self.preview_connection:
            self.preview_connection.tick(lambda kind, body: self.message(kind, body, live=True))
        scene = bpy.context.scene
        if (bpy.context.screen and bpy.context.screen.is_animation_playing) or (
            self.last_timeline_frame is not None and scene.frame_current != self.last_timeline_frame
        ):
            self.live_preview = False
        self.last_timeline_frame = scene.frame_current
        # Latest pose has priority over archival baking. One solver call is the
        # smallest indivisible unit; overruns are measured, never called a hard cap.
        key = (
            (self.latest.session_id, self.latest.segment_id, self.latest.sequence)
            if self.latest
            else None
        )
        if self.live_preview and self.latest and self.source_fresh() and key != self.applied_pose:
            self.update_floor()
            if self.solver and self.solver.accepts(self.latest):
                self.solver.apply(self.solver.solve(self.latest))
            elif not self.snapshot and not self.calibration_deadline:
                self.preview_character(self.latest)
            now = time.monotonic()
            if self.settings().source_preview and now - self.last_source_draw >= 1 / 15:
                self.show_source(self.latest)
                self.last_source_draw = now
            self.applied_pose = key
            changed = True
            if self.latest.usable:
                self.preview_updates += 1
                self.preview_times.append(now)
        if self.out:
            try:
                sent = self.sock.send(self.out)
                del self.out[:sent]
            except (BlockingIOError, InterruptedError):
                pass
        if len(self.messages) < 128 and time.perf_counter() < deadline:
            try:
                data = self.sock.recv(65536)
                if not data:
                    raise ConnectionError("Recorder disconnected")
                self.messages.extend(self.parser.feed(data))
            except (BlockingIOError, InterruptedError):
                pass
        while time.perf_counter() < deadline:
            if self.work:
                try:
                    next(self.work)
                except StopIteration:
                    self.work = None
                changed = True
            elif self.messages:
                kind, body = decode(self.messages.popleft())
                self.message(kind, body)
                changed = True
            else:
                break
        if self.writer:
            self.writer.flush(deadline)
        now = time.monotonic()
        if self.query and now - self.query[2] > 10 and not (self.messages or self.work):
            raise ProtocolError("Recorder query timed out")
        if (
            self.calibration_deadline
            and now >= self.calibration_deadline
            and time.perf_counter() < deadline
        ):
            try:
                self.finish_calibration()
            except ProtocolError as exc:
                self.status = str(exc)
                self.live_preview = True
                self.send(Kind.STATUS, dict(state="CALIBRATION_FAILED", error=str(exc)))
        if (
            self.authorized
            and not self.query
            and not self.messages
            and not self.work
            and now - self.last_poll >= 1 / 30
        ):
            self.last_poll = now
            if now >= self.next_status:
                self.request("TAKE_STATUS", take_id=self.take_id) if self.take_id else self.request(
                    "SYSTEM_STATUS"
                )
                self.next_status = now + 0.5
            elif self.writer and self.start_event and not self.capture_error:
                self.request(
                    "SAMPLES_SOURCE_ORDER" if self.replaying else "SAMPLES_AFTER_CURSOR",
                    take_id=self.take_id,
                    cursor=self.cursor,
                    limit=16,
                )
            elif not self.preview_available:
                self.request("LATEST_POSE")
        if changed or now - self.last_redraw > 0.5:
            self.redraw()

    def redraw(self):
        for area in bpy.context.screen.areas if bpy.context.screen else []:
            if area.type == "VIEW_3D":
                area.tag_redraw()
        self.last_redraw = time.monotonic()

    def feed_work(self, pose):
        try:
            yield from self.writer.feed_iter(pose)
        except ProtocolError as exc:
            self.capture_error = str(exc)
            self.status = self.capture_error

    def update_floor(self):
        if self.writer or not self.snapshot or not self.metrics:
            return
        t = self.metrics.get("source_timestamp")
        if t == self.last_floor_time:
            return
        self.last_floor_time = t
        observation = observed_floor(self.snapshot, self.latest, self.metrics)
        if not observation:
            return
        self.floor_candidates.append(observation["floor_world_z"])
        if (
            len(self.floor_candidates) < 3
            or max(self.floor_candidates) - min(self.floor_candidates) > 0.03
        ):
            return
        import statistics

        value = statistics.median(self.floor_candidates)
        if abs(value - self.snapshot.get("floor_world_z", float("inf"))) < 0.005:
            return
        self.snapshot.update(observation, floor_world_z=value)
        self.solver = MotionSolver(self.settings().rig, self.snapshot)

    def freeze_processing(self):
        if not self.snapshot:
            return
        self.snapshot["processing"] = self.processing_settings()
        if self.solver:
            self.snapshot["tracking_sources"] = sorted(self.solver.tracking_sources)
        path = self.settings().profile_path
        if path:
            profile = json.loads(Path(bpy.path.abspath(path)).read_text())
            if "foot_geometry" in profile:
                self.snapshot["foot_geometry"] = profile["foot_geometry"]
        solver = MotionSolver(self.settings().rig, self.snapshot)
        self.snapshot["foot_geometry"] = {
            side: {k: list(v) for k, v in points.items()}
            for side, points in solver.geometry.items()
        }
        self.solver = solver

    def start_refinement(self):
        if self.writer or self.work or self.refinement or self.rebuild or self.calibration_deadline:
            raise ProtocolError("Finish the current operation first")
        props = self.settings()
        self.refinement = RefinementJob(props.rig, props.take_action, props.capture_directory)
        self.live_preview = False
        self.status = "Refining selected animation"

    def cancel_refinement(self):
        if self.refinement:
            self.refinement.cancel()
            self.refinement = None
            self.status = "Refinement cancelled"

    def start_rebuild(self):
        if self.writer or self.work or self.refinement or self.rebuild or self.calibration_deadline:
            raise ProtocolError("Finish the current operation first")
        props = self.settings()
        if not props.rig or not props.take_action:
            raise ProtocolError("Choose a character and recorded take to rebuild")
        self.rebuild = RebuildJob(props.rig, props.take_action, props.capture_directory)
        self.live_preview = False
        self.status = "Rebuilding animation from source"

    def cancel_rebuild(self):
        if self.rebuild:
            self.rebuild.cancel()
            self.rebuild = None
            self.status = "Rebuild cancelled"

    def message(self, kind, body, live=False):
        if kind == Kind.SCHEMA:
            schema = Schema.from_body(body)
            # Historical schemas belong to the writer's frozen snapshot. They must
            # not replace a newer schema arriving on the independent live socket.
            if live or not (
                self.query and self.query[0] in {"SAMPLES_AFTER_CURSOR", "SAMPLES_SOURCE_ORDER"}
            ):
                self.schema = schema
            return
        if kind == Kind.POSE:
            if (
                not live
                and self.query
                and self.query[0] in {"SAMPLES_AFTER_CURSOR", "SAMPLES_SOURCE_ORDER"}
            ):
                if self.writer and self.start_event and not self.capture_error:
                    self.work = self.feed_work(body)
                return
            if not self.schema or body.schema_id != self.schema.schema_id:
                raise ProtocolError("Source schema changed unexpectedly")
            if (
                self.latest is None
                or body.session_id != self.latest.session_id
                or body.sequence > self.latest.sequence
            ):
                self.latest = body
                self.samples.append(body)
                if self.snapshot and (
                    body.segment_id != self.snapshot["segment_id"]
                    or body.session_id != self.snapshot["session_id"]
                    or (body.body_id != ZERO and body.body_id != self.snapshot["body_id"])
                ):
                    self.clear_reference()
                    self.status = "Tracking identity changed; aligning character"
            return
        if kind == Kind.COMMAND:
            try:
                if body.get("command") == "CALIBRATE_COUNTDOWN":
                    self.begin_calibration(
                        local_only=True, countdown=body.get("args", {}).get("countdown_seconds")
                    )
                elif body.get("command") == "RECENTER":
                    self.recenter(body.get("request_id"))
                elif body.get("command") == "PREPARE_TAKE":
                    self.prepare(body.get("take_id"))
            except ProtocolError as exc:
                self.status = str(exc)
                self.send(Kind.STATUS, dict(state="ERROR", error=str(exc)))
            return
        if kind == Kind.EVENT:
            event = body.get("event")
            if event == "HISTORY_END" and self.query and body.get("request_id") == self.query[1]:
                self.cursor = body["cursor"]
                self.query = None
                if self.replaying and body.get("done"):
                    self.complete_replay()
            elif event == "TAKE_STARTED" and body.get("take_id") == self.take_id:
                self.start_event = body
                if self.writer:
                    self.writer.start(body["t0"], body["t0"] + self.settings().duration)
                self.status = "Recording"
            elif event == "TAKE_ENDED" and body.get("take_id") == self.take_id:
                if self.writer:
                    self.writer.set_end(body["t_stop"])
                self.status = "Replaying verified source" if self.replaying else "Finalizing source"
                self.live_preview = False
            elif event == "TAKE_CANCELLED" and body.get("take_id") == self.take_id:
                if self.writer:
                    self.writer.restore(remove=True)
                self.writer = None
                self.take_id = None
                self.start_event = None
                self.status = "Cancelled"
            elif event == "SEGMENT_ENDED" and body.get("take_id") == self.take_id:
                if self.writer:
                    self.writer.flush()
                    self.writer.action["abm_state"] = "INTERRUPTED"
                    self.writer.restore()
                self.writer = None
                self.take_id = None
                self.start_event = None
                self.live_preview = False
                self.status = "Source interrupted: " + body.get("reason", "tracking changed")
            elif event == "CALIBRATION_FAILED":
                self.status = body.get("reason", "Calibration failed")
            return
        if kind == Kind.STATUS:
            if "capture_metrics" in body:
                self.metrics = body["capture_metrics"]
            if body.get("hello"):
                self.authorized = True
                self.status = "Connected — trusted LAN plaintext"
                self.preview_available = body.get("preview_stream", False)
            if self.query and body.get("request_id") == self.query[1]:
                self.query = None
            if body.get("kind") in {"LATEST_POSE", "PREVIEW"}:
                self.source_age = (
                    body.get("age_seconds") if body.get("age_seconds") is not None else float("inf")
                )
                self.source_status_time = time.monotonic()
            if body.get("error"):
                if (
                    body.get("request_id") == self.prepare_request
                    and self.writer
                    and not self.start_event
                ):
                    self.writer.restore(remove=True)
                    self.writer = None
                    self.take_id = None
                    self.record_when_prepared = False
                self.status = body["error"]
                return
            if body.get("active") is not None:
                self.active = body["active"]
            if body.get("source_durable") is not None:
                self.source_status = body
                if body.get("source_durable") and self.writer:
                    self.finish_take()
            # Prepare confirmation comes from a durable phone event; query coordinator while arming.
            if self.record_when_prepared:
                if self.active and self.active.get("phase") == "PREPARED":
                    self.command("START_COUNTDOWN", self.take_id)
                    self.record_when_prepared = False
                    self.status = "Countdown"
                elif not self.query:
                    self.request("SYSTEM_STATUS")

    def mapping(self):
        rig = self.settings().rig
        preset = getattr(self.settings(), "mapping_preset", "DEMO")
        if preset == "CUSTOM":
            path = self.settings().profile_path
            if path:
                value = json.loads(Path(bpy.path.abspath(path)).read_text())
                mapping = value.get("mapping", value)
                if not isinstance(mapping, dict):
                    raise ProtocolError("Profile requires a mapping object")
                return mapping
            return {}
        if getattr(self.settings(), "bone_mappings", None):
            user_map = {
                item.source_joint: item.target_bone
                for item in self.settings().bone_mappings
                if item.target_bone
            }
            if user_map:
                return user_map
        if preset == "DEMO" and rig and self.schema:
            return {name: name for name in self.schema.joint_names if name in rig.pose.bones}
        return get_preset_mapping(preset, rig)

    def source_fresh(self):
        return self.source_age + time.monotonic() - self.source_status_time <= 0.5

    def begin_calibration(self, local_only=False, countdown=None):
        if self.writer or self.refinement or self.rebuild:
            raise ProtocolError("Finish or cancel the active operation before aligning")
        if not self.latest:
            raise ProtocolError("Connect and obtain a source pose first")
        if not self.source_fresh():
            raise ProtocolError("Phone source is stale; resume capture before calibrating")
        self.clear_reference()
        self.applied_pose = None
        bpy.context.view_layer.update()
        self.live_preview = False
        self.samples.clear()
        self.calibration_deadline = (
            time.monotonic() + (self.settings().countdown if countdown is None else countdown) + 1
        )
        if not local_only:
            self.command(
                "CALIBRATE_COUNTDOWN", args={"countdown_seconds": self.settings().countdown}
            )
        self.status = "Calibration countdown — hold the matching reference pose"

    def finish_calibration(self):
        self.calibration_deadline = None
        if not self.source_fresh():
            raise ProtocolError("Phone source stopped during calibration")
        if not self.samples:
            raise ProtocolError("No calibration samples")
        last = self.samples[-1].timestamp
        selected = [s for s in self.samples if s.timestamp >= last - 0.85]
        props = self.settings()
        self.snapshot = calibrate(
            props.rig,
            self.schema,
            self.mapping(),
            selected,
            props.root_source,
            props.root_mode,
            props.travel_scale,
            props.heading,
        )
        self.freeze_processing()
        self.live_preview = True
        props.rig["abm_calibration"] = json.dumps(self.snapshot)
        self.status = "Calibrated"
        self.send(Kind.STATUS, dict(state="CALIBRATED"))

    def prepare(self, take_id=None):
        if self.writer or self.refinement:
            raise ProtocolError("Finish or cancel the active operation")
        if not self.snapshot:
            raise ProtocolError("Calibrate the character first")
        if not self.source_fresh():
            raise ProtocolError("Phone source is stale; resume capture before recording")
        props = self.settings()
        if self.snapshot["rig_fingerprint"] != rig_fingerprint(props.rig):
            raise ProtocolError("Rig changed; recalibrate")
        self.freeze_processing()
        self.take_id = take_id or str(uuid.uuid4())
        self.cursor = 0
        self.capture_error = None
        self.start_event = None
        scene = bpy.context.scene
        from fractions import Fraction

        rate = Fraction(scene.render.fps) / Fraction(str(scene.render.fps_base))
        self.writer = ActionWriter(
            props.rig,
            self.snapshot,
            self.take_id,
            props.take_name,
            props.start_frame,
            rate.numerator,
            rate.denominator,
        )
        self.prepare_request = self.command(
            "PREPARE_TAKE",
            self.take_id,
            dict(
                name=props.take_name,
                start_frame=props.start_frame,
                fps_numerator=rate.numerator,
                fps_denominator=rate.denominator,
                countdown_seconds=props.countdown,
                duration_seconds=props.duration,
                snapshot=self.snapshot,
            ),
        )
        self.record_when_prepared = True
        self.live_preview = True
        self.status = "Preparing phone and Blender"

    def finish_take(self):
        if not self.writer or self.replaying:
            return
        # Source-order replay is served by the external disk worker in bounded batches.
        # Finish any in-flight query first so its old cursor cannot overwrite the replay cursor.
        if self.query:
            return
        old = self.writer
        self.provisional_writer = old
        self.writer = ActionWriter(
            old.rig,
            old.snapshot,
            self.take_id,
            old.action.name + " verified",
            old.start_frame,
            old.action["abm_fps_numerator"],
            old.action["abm_fps_denominator"],
        )
        self.writer.start(self.source_status["start"]["t0"], self.source_status["end"]["t_stop"])
        self.start_event = self.source_status["start"]
        self.cursor = 0
        self.replaying = True
        self.capture_error = None
        self.live_preview = False
        self.status = "Replaying verified source"

    def complete_replay(self):
        replacement = self.writer
        old = self.provisional_writer
        self.work = self.complete_replay_work(replacement, old)

    def complete_replay_work(self, replacement, old):
        yield from replacement.finalize_iter(self.source_status["source_hash"])
        replacement.action["abm_source_path"] = str(
            Path(self.settings().capture_directory).expanduser() / self.take_id
        )
        old.action.use_fake_user = False
        if old.action.users == 0:
            bpy.data.actions.remove(old.action)
        self.writer = None
        self.provisional_writer = None
        self.replaying = False
        self.live_preview = False
        self.settings().take_action = replacement.action
        self.status = f"Ready in scene — {replacement.frames} frames; save the scene"
        self.send(
            Kind.STATUS,
            dict(
                state="READY_IN_SCENE",
                take_id=self.take_id,
                source_hash=self.source_status["source_hash"],
            ),
        )
        bpy.context.scene.frame_start = old.start_frame
        bpy.context.scene.frame_end = old.start_frame + replacement.frames - 1
        replacement.rig["abm_take_metadata"] = json.dumps(
            dict(
                take_id=self.take_id,
                source_hash=self.source_status["source_hash"],
                snapshot=old.snapshot,
                gaps=replacement.gaps,
                source_path=str(
                    Path(self.settings().capture_directory).expanduser() / self.take_id
                ),
            )
        )

    def processing_settings(self):
        props = self.settings()
        return configuration(
            dict(
                smoothing=props.smoothing,
                foot_lock=props.foot_lock,
                min_cutoff=props.smoothing_cutoff,
                floor_offset=props.floor_offset,
            )
        )

    def recenter(self, request_id=None):
        if request_id in self.recenter_results:
            self.send(Kind.STATUS, self.recenter_results[request_id])
            return
        try:
            if (
                self.writer
                or self.replaying
                or self.refinement
                or self.rebuild
                or self.calibration_deadline
            ):
                raise ProtocolError("Finish recording or manual alignment before recentering")
            if not self.latest or not self.source_fresh() or not self.latest.usable:
                raise ProtocolError("Keep your full body in view to recenter")
            if not self.snapshot or not self.solver:
                raise ProtocolError(
                    "Wait for character alignment, or use Manual alignment in Advanced setup"
                )
            props = self.settings()
            snapshot = recenter_reference(props.rig, self.snapshot, self.latest)
            solver = MotionSolver(props.rig, snapshot)
            pose = solver.solve(self.latest)
            self.snapshot = snapshot
            self.solver = solver
            props.heading = snapshot["heading_degrees"]
            props.rig["abm_calibration"] = json.dumps(snapshot)
            self.solver.apply(pose)
            self.applied_pose = None
            self.live_preview = True
            self.status = "Recentered — position and facing reset"
            result = dict(state="RECENTERED", request_id=request_id)
        except ProtocolError as exc:
            self.status = str(exc)
            result = dict(state="ERROR", request_id=request_id, error=str(exc))
            if request_id is None:
                raise
        if request_id:
            self.recenter_results[request_id] = result
            if len(self.recenter_results) > 256:
                self.recenter_results.pop(next(iter(self.recenter_results)))
        self.send(Kind.STATUS, result)

    def refresh_processing(self):
        if self.writer or self.refinement:
            return
        if self.snapshot and self.solver:
            self.snapshot["processing"] = self.processing_settings()
            self.solver = MotionSolver(self.solver.rig, self.snapshot)
            self.applied_pose = None

    def clear_reference(self):
        if self.solver and self.snapshot and not self.writer:
            try:
                for name, value in self.snapshot["target_basis"].items():
                    self.solver.rig.pose.bones[name].matrix_basis = matrix(value)
            except (ReferenceError, KeyError):
                pass
        self.solver = None
        self.snapshot = None
        self.applied_pose = None
        self.floor_candidates.clear()
        self.last_floor_time = None

    def preview_character(self, pose):
        props = self.settings()
        rig = props.rig
        if not rig or not self.schema or not pose.usable:
            return
        if self.schema.neutral_joints is None:
            self.status = "Source neutral skeleton unavailable — use manual alignment"
            return
        mapping = self.mapping()
        if not mapping or not all(
            pose.valid[self.schema.joint_names.index(name)] for name in mapping
        ):
            return
        bpy.context.view_layer.update()
        self.snapshot = neutral_reference(
            rig,
            self.schema,
            mapping,
            pose,
            props.root_source,
            props.root_mode,
            props.travel_scale,
            props.heading,
        )
        self.snapshot["processing"] = self.processing_settings()
        self.solver = MotionSolver(rig, self.snapshot)
        self.freeze_processing()
        self.solver.apply(self.solver.solve(pose))
        self.status = "Character ready"
        rig["abm_calibration"] = json.dumps(self.snapshot)
        self.send(Kind.STATUS, dict(state="CALIBRATED", reference_kind="NEUTRAL"))

    def show_source(self, pose):
        if not self.schema:
            return
        if len(self.source_objects) != len(self.schema.joint_names):
            self.clear_source()
            collection = bpy.data.collections.new("MotionSlate Source Preview")
            bpy.context.scene.collection.children.link(collection)
            for name in self.schema.joint_names:
                obj = bpy.data.objects.new("MotionSlate Source " + name, None)
                obj.empty_display_type = "SPHERE"
                obj.empty_display_size = 0.025
                collection.objects.link(obj)
                self.source_objects.append(obj)
        anchor = matrix(pose.anchor)
        for obj, transform, valid in zip(self.source_objects, pose.joints, pose.valid):
            obj.hide_viewport = not valid
            if valid:
                obj.location = AXES @ (anchor @ matrix(transform)).translation

    def clear_source(self):
        for obj in self.source_objects:
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except ReferenceError:
                pass
        self.source_objects = []


runtime = Runtime()


class ABMBoneMapping(PropertyGroup):
    source_joint: StringProperty(name="Source Joint")
    target_bone: StringProperty(name="Target Bone")


class ABMSettings(PropertyGroup):
    rig: PointerProperty(
        name="Character", type=bpy.types.Object, poll=lambda self, obj: obj.type == "ARMATURE"
    )
    port: IntProperty(name="Recorder port", default=9001, min=1, max=65535)
    capture_directory: StringProperty(
        name="Capture folder", default="~/Movies/MotionSlate", subtype="DIR_PATH"
    )
    mapping_preset: EnumProperty(
        name="Mapping Preset",
        items=[
            ("DEMO", "Demo / Identity", "1:1 ARKit joint names"),
            ("MIXAMO", "Mixamo", "Mixamo standard humanoid bone names"),
            ("RIGIFY", "Rigify FK", "Rigify FK standard bone names"),
            ("CUSTOM", "Custom JSON", "Load mapping from external JSON file"),
        ],
        default="DEMO",
    )
    show_mapping_table: BoolProperty(
        name="Show Bone Mappings",
        default=False,
    )
    bone_mappings: CollectionProperty(type=ABMBoneMapping)
    profile_path: StringProperty(name="Mapping JSON", subtype="FILE_PATH")
    take_name: StringProperty(name="Take name", default="Mocap Take")
    root_source: StringProperty(name="Source pelvis", default="hips_joint")
    start_frame: IntProperty(name="First frame", default=1, min=-1000000, max=1000000)
    duration: FloatProperty(name="Duration (seconds)", default=10, min=0.1, max=3600)
    countdown: FloatProperty(name="Countdown (seconds)", default=5, min=0, max=60)
    root_mode: EnumProperty(
        name="Root motion",
        items=[
            ("WORLD", "World travel", "Keep travel"),
            ("IN_PLACE", "In place", "Keep vertical movement"),
        ],
    )
    travel_scale: FloatProperty(name="Travel scale", default=1, min=0.001, max=1000)
    heading: FloatProperty(name="Heading correction", default=0, min=-180, max=180)
    source_preview: BoolProperty(
        name="Show source joints",
        default=True,
        update=lambda self, context: runtime.clear_source() if not self.source_preview else None,
    )
    advanced_setup: BoolProperty(name="Advanced setup", default=False)
    smoothing: BoolProperty(
        name="Adaptive smoothing",
        default=True,
        update=lambda self, context: runtime.refresh_processing(),
    )
    smoothing_cutoff: FloatProperty(
        name="Smoothing cutoff (Hz)",
        default=2,
        min=0.1,
        max=30,
        update=lambda self, context: runtime.refresh_processing(),
    )
    foot_lock: BoolProperty(
        name="Stabilize planted feet",
        default=True,
        update=lambda self, context: runtime.refresh_processing(),
    )
    floor_offset: FloatProperty(
        name="Floor offset (m)",
        default=0,
        min=-2,
        max=2,
        update=lambda self, context: runtime.refresh_processing(),
    )
    take_action: PointerProperty(
        name="Recorded take",
        type=bpy.types.Action,
        poll=lambda self, action: bool(action.get("abm_take_id")),
    )


class ABM_OT_action(Operator):
    bl_idname = "abm.action"
    bl_label = "MotionSlate"
    bl_options = {"REGISTER"}
    command: StringProperty()

    def execute(self, context):
        try:
            if self.command == "connect":
                runtime.connect()
            elif self.command == "disconnect":
                runtime.disconnect()
                get_service_supervisor().release()
            elif self.command == "calibrate":
                runtime.begin_calibration()
            elif self.command == "recenter":
                runtime.recenter()
            elif self.command == "record":
                runtime.prepare()
            elif self.command == "stop":
                runtime.command("STOP_TAKE", runtime.take_id)
            elif self.command == "cancel":
                runtime.command("CANCEL_TAKE", runtime.take_id)
            elif self.command == "preview":
                runtime.live_preview = not runtime.live_preview
            elif self.command == "demo":
                from .demo import create_demo_rig

                context.scene.abm_settings.rig = create_demo_rig()
            elif self.command == "refine":
                runtime.start_refinement()
            elif self.command == "cancel_refine":
                runtime.cancel_refinement()
            elif self.command == "rebuild":
                runtime.start_rebuild()
            elif self.command == "cancel_rebuild":
                runtime.cancel_rebuild()
            elif self.command == "locate_source":
                bpy.ops.abm.locate_source("INVOKE_DEFAULT")
            elif self.command == "archive_take":
                bpy.ops.abm.archive_take("INVOKE_DEFAULT")
            elif self.command == "save":
                if not bpy.data.filepath:
                    raise ProtocolError("Use File > Save As to choose the scene file")
                bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
            elif self.command == "select_take":
                props = context.scene.abm_settings
                rig = props.rig
                action = props.take_action
                if not rig or not action:
                    raise ProtocolError("Choose a character and recorded take")
                if runtime.writer or runtime.refinement or runtime.rebuild:
                    raise ProtocolError("Finish the active operation before switching animation")
                if action.get("abm_rig_fingerprint") != rig_fingerprint(rig):
                    raise ProtocolError("Take belongs to a different rig or reference transform")
                slot = next(
                    (slot for slot in action.slots if slot.target_id_type == "OBJECT"), None
                )
                if slot is None:
                    raise ProtocolError("Take has no armature-object slot")
                runtime.live_preview = False
                ad = rig.animation_data_create()
                ad.action = action
                ad.action_slot = slot
                for track in ad.nla_tracks:
                    track.mute = True
                for bone in rig.pose.bones:
                    bone.rotation_mode = "QUATERNION"
                context.scene.frame_start = action.get("abm_start_frame", 1)
                context.scene.frame_end = (
                    context.scene.frame_start + action.get("abm_frames", 1) - 1
                )
                rate = action["abm_fps_numerator"] / action["abm_fps_denominator"]
                context.scene.render.fps = round(rate)
                context.scene.render.fps_base = round(rate) / rate
                context.scene.frame_set(context.scene.frame_start)
                runtime.status = "Selected recorded take; live preview disabled"
            return {"FINISHED"}
        except Exception as exc:
            runtime.status = str(exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class ABM_OT_locate_source(Operator):
    bl_idname = "abm.locate_source"
    bl_label = "Locate Source Directory"
    bl_description = "Relink selected take to a relocated source directory"

    directory: StringProperty(name="Directory", subtype="DIR_PATH")
    filepath: StringProperty(name="File Path", subtype="FILE_PATH")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        target = self.directory or self.filepath
        if not target:
            self.report({"ERROR"}, "No directory selected")
            return {"CANCELLED"}
        target_path = Path(target)
        if target_path.is_file() and target_path.name == "manifest.json":
            target_path = target_path.parent
        try:
            props = context.scene.abm_settings
            if not props.take_action:
                raise ProtocolError("Choose a recorded take to relink")
            relinked = relink_source(props.take_action, target_path, props.rig)
            runtime.status = f"Relinked source to {relinked}"
            self.report({"INFO"}, f"Relinked source to {relinked}")
            return {"FINISHED"}
        except Exception as exc:
            runtime.status = f"Relink failed: {exc}"
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class ABM_OT_archive_take(Operator):
    bl_idname = "abm.archive_take"
    bl_label = "Archive Take"
    bl_description = "Export verified take to an archive destination"

    directory: StringProperty(name="Destination Directory", subtype="DIR_PATH")
    filepath: StringProperty(name="File Path", subtype="FILE_PATH")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        target = self.directory or self.filepath
        if not target:
            self.report({"ERROR"}, "No destination directory selected")
            return {"CANCELLED"}
        target_path = Path(target)
        if target_path.is_file():
            target_path = target_path.parent
        try:
            props = context.scene.abm_settings
            if not props.take_action:
                raise ProtocolError("Choose a recorded take to archive")
            archived = archive_take(
                props.take_action, target_path, props.rig, props.capture_directory
            )
            runtime.status = f"Archived take to {archived}"
            self.report({"INFO"}, f"Archived take to {archived}")
            return {"FINISHED"}
        except Exception as exc:
            runtime.status = f"Archive failed: {exc}"
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


class ABM_OT_reset_mapping(Operator):
    bl_idname = "abm.reset_mapping"
    bl_label = "Reset Bone Mappings"
    bl_description = "Populate bone mappings from the selected preset"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.abm_settings
        s.bone_mappings.clear()
        mapping = {}
        if s.mapping_preset == "CUSTOM" and s.profile_path:
            try:
                val = json.loads(Path(bpy.path.abspath(s.profile_path)).read_text())
                mapping = val.get("mapping", val)
            except Exception as exc:
                self.report({"ERROR"}, f"Failed to load JSON mapping: {exc}")
                return {"CANCELLED"}
        else:
            mapping = get_preset_mapping(s.mapping_preset, s.rig)
        for joint in ARKit_JOINTS:
            item = s.bone_mappings.add()
            item.source_joint = joint
            item.target_bone = mapping.get(joint, "")
        self.report({"INFO"}, f"Loaded {len(s.bone_mappings)} mappings from {s.mapping_preset}")
        return {"FINISHED"}


class ABM_PT_panel(Panel):
    bl_label = "MotionSlate"
    bl_idname = "ABM_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "MotionSlate"

    def draw(self, context):
        layout = self.layout
        s = context.scene.abm_settings
        supervisor = get_service_supervisor()

        layout.label(text=runtime.status[:80])

        # 1. Connection Section
        box_conn = layout.box()
        row_conn = box_conn.row(align=True)
        row_conn.label(text="Connection", icon="NETWORK_DRIVE")
        if supervisor.state == "CONNECTED":
            row_conn.label(text=f"Active (port {supervisor.blender_port})", icon="CHECKMARK")
        elif supervisor.state == "STARTING":
            row_conn.label(text="Starting...", icon="TIME")
        elif supervisor.state == "ERROR":
            row_conn.label(text=f"Error: {supervisor.last_error or 'Unknown'}"[:40], icon="ERROR")
        else:
            row_conn.label(text="Disconnected", icon="PAUSE")

        col_conn = box_conn.column(align=True)
        col_conn.prop(s, "port")
        wm = getattr(context, "window_manager", None)
        if wm and hasattr(wm, "abm_manual_token"):
            col_conn.prop(wm, "abm_manual_token", text="Manual token (optional)")
        col_conn.prop(s, "capture_directory", text="Capture folder")
        if (
            supervisor.effective_capture_root
            and supervisor.effective_capture_root
            != Path(s.capture_directory).expanduser().resolve()
        ):
            col_conn.label(
                text=f"Effective: {supervisor.effective_capture_root}", icon="FILE_FOLDER"
            )

        row_conn_btn = box_conn.row(align=True)
        row_conn_btn.operator("abm.action", text="Connect").command = "connect"
        row_conn_btn.operator("abm.action", text="Disconnect").command = "disconnect"

        # 2. Character Section
        box_char = layout.box()
        box_char.label(text="Character", icon="OUTLINER_OB_ARMATURE")
        box_char.prop(s, "rig")
        box_char.operator("abm.action", text="Create demo humanoid").command = "demo"

        if s.rig:
            current_map = runtime.mapping()
            issues = preflight_rig(s.rig, current_map)
            if not issues:
                box_char.label(
                    text=f"Rig ready for tracking ({len(current_map)} bones mapped)",
                    icon="CHECKMARK",
                )
            else:
                issue_box = box_char.box()
                issue_box.label(text="Rig issues detected:", icon="ERROR")
                for issue in issues[:3]:
                    issue_box.label(text=f"• {issue}", icon="BLANK1")
                if len(issues) > 3:
                    issue_box.label(text=f"...and {len(issues) - 3} more", icon="BLANK1")
        else:
            box_char.label(text="Select a character armature", icon="INFO")

        box_char.prop(s, "mapping_preset")
        if s.mapping_preset == "CUSTOM":
            box_char.prop(s, "profile_path")

        row_map = box_char.row(align=True)
        row_map.prop(
            s,
            "show_mapping_table",
            text="Edit Bone Mappings" if not s.show_mapping_table else "Hide Bone Mappings",
            icon="TRIA_DOWN" if s.show_mapping_table else "TRIA_RIGHT",
        )
        row_map.operator("abm.reset_mapping", text="Reset from Preset")

        if s.show_mapping_table:
            map_box = box_char.box()
            if not s.bone_mappings:
                map_box.label(text="Click 'Reset from Preset' to initialize mappings", icon="INFO")
            else:
                for item in s.bone_mappings:
                    row_item = map_box.row(align=True)
                    row_item.label(text=item.source_joint)
                    if s.rig and hasattr(s.rig, "pose") and s.rig.pose:
                        row_item.prop_search(item, "target_bone", s.rig.pose, "bones", text="")
                    else:
                        row_item.prop(item, "target_bone", text="")

        box_char.prop(s, "root_source")
        box_char.prop(s, "heading")
        box_char.prop(s, "travel_scale")
        box_char.prop(s, "root_mode")
        box_char.prop(s, "source_preview")

        row_rec = box_char.row()
        row_rec.enabled = (
            runtime.writer is None
            and runtime.refinement is None
            and runtime.calibration_deadline is None
        )
        row_rec.operator("abm.action", text="Recenter").command = "recenter"

        # 3. Recording Section
        box_rec = layout.box()
        box_rec.label(text="Recording", icon="RADIOBUT_ON")
        if runtime.authorized:
            box_rec.label(
                text="Phone source live" if runtime.source_fresh() else "Phone source paused",
                icon="CHECKMARK" if runtime.source_fresh() else "PAUSE",
            )
        if runtime.authorized and runtime.source_fresh():
            if runtime.latest and not runtime.latest.usable:
                box_rec.label(
                    text="Tracking lost or limited — keep your full body in view", icon="ERROR"
                )
            elif runtime.calibration_deadline:
                box_rec.label(text="Hold the reference pose for calibration", icon="TIME")
            elif not runtime.live_preview:
                box_rec.label(text="Live preview paused — use Toggle preview", icon="PAUSE")
            elif not runtime.snapshot:
                box_rec.label(text="Waiting for a usable reference skeleton", icon="INFO")
            elif runtime.snapshot.get("reference_kind") == "NEUTRAL":
                box_rec.label(
                    text="Neutral reference ready — calibration optional", icon="CHECKMARK"
                )

        box_rec.prop(s, "take_name")
        box_rec.prop(s, "start_frame")
        box_rec.prop(s, "duration")
        box_rec.prop(s, "countdown")

        row_rec_btns = box_rec.row(align=True)
        row_rec_btns.operator("abm.action", text="Record after countdown").command = "record"
        row_rec_btns.operator("abm.action", text="Stop").command = "stop"

        row_ctrl = box_rec.row(align=True)
        row_ctrl.operator("abm.action", text="Cancel take").command = "cancel"
        row_ctrl.operator("abm.action", text="Toggle preview").command = "preview"

        if runtime.writer:
            box_rec.label(text=f"Frames keyed: {runtime.writer.frames}")
        if runtime.source_status:
            box_rec.label(
                text="Source verified"
                if runtime.source_status.get("source_durable")
                else "Source archiving / recovery pending"
            )
        box_rec.operator("abm.action", text="Save scene").command = "save"

        quality = box_rec.column(align=True)
        quality.enabled = runtime.writer is None and runtime.refinement is None
        quality.prop(s, "smoothing")
        quality.prop(s, "smoothing_cutoff")
        quality.prop(s, "foot_lock")
        quality.prop(s, "floor_offset")
        if runtime.solver and hasattr(runtime.solver, "disabled_legs") and s.foot_lock:
            for reason in runtime.solver.disabled_legs:
                quality.label(text="Foot correction off: " + reason, icon="INFO")

        # 4. Advanced Section
        box_adv = layout.box()
        box_adv.label(text="Advanced", icon="PREFERENCES")

        adv_col = box_adv.column()
        adv_col.enabled = runtime.writer is None and runtime.refinement is None
        adv_col.label(text="Custom reference pose: match your character")
        adv_col.operator(
            "abm.action", text="Manual alignment after countdown"
        ).command = "calibrate"

        box_adv.prop(s, "take_action")
        box_adv.operator("abm.action", text="Select take for playback").command = "select_take"

        row_ref = box_adv.row(align=True)
        row_ref.enabled = runtime.writer is None and runtime.rebuild is None
        row_ref.operator(
            "abm.action", text="Cancel refinement" if runtime.refinement else "Refine animation"
        ).command = "cancel_refine" if runtime.refinement else "refine"

        row_reb = box_adv.row(align=True)
        row_reb.enabled = runtime.writer is None and runtime.refinement is None
        row_reb.operator(
            "abm.action", text="Cancel rebuild" if runtime.rebuild else "Rebuild from source"
        ).command = "cancel_rebuild" if runtime.rebuild else "rebuild"

        row_arch = box_adv.row(align=True)
        row_arch.enabled = (
            runtime.writer is None
            and runtime.refinement is None
            and runtime.rebuild is None
            and s.take_action is not None
        )
        row_arch.operator("abm.locate_source", text="Locate source")
        row_arch.operator("abm.archive_take", text="Archive take")

        if runtime.timings:
            values = sorted(runtime.timings)
            box_adv.label(text=f"Callback p95: {values[int((len(values) - 1) * 0.95)]:.1f} ms")
        if runtime.metrics:
            box_adv.label(
                text=f"Usable capture: {runtime.metrics['usable_hz']:.1f}/s · {runtime.metrics['thermal']}"
            )
        if runtime.snapshot:
            box_adv.label(
                text="Measured floor" if "floor_world_z" in runtime.snapshot else "Reference floor"
            )


def timer():
    try:
        started = time.perf_counter()
        deadline = started + 0.008
        get_service_supervisor().tick(deadline)
        runtime.tick_budget(deadline)
    except (OSError, ConnectionError, ProtocolError, ReferenceError) as exc:
        error = str(exc)
        runtime.disconnect()
        runtime.status = error
    except Exception as exc:
        runtime.status = f"Capture error: {exc}"
        runtime.live_preview = False
        import traceback

        traceback.print_exc()
    return max(0.001, 1 / 60 - (runtime.timings[-1] / 1000 if runtime.timings else 0))


def purge_legacy_tokens():
    """Purge legacy token properties across scenes; credentials must never be in .blend files."""
    if not hasattr(bpy, "data") or not hasattr(bpy.data, "scenes"):
        return
    for scene in bpy.data.scenes:
        s = getattr(scene, "abm_settings", None)
        if s is not None:
            if "token" in s:
                del s["token"]
            if hasattr(s, "keys") and "token" in s.keys():
                try:
                    del s["token"]
                except Exception:
                    pass


@persistent
def before_load(_):
    global runtime
    runtime.disconnect()
    runtime = Runtime()


@persistent
def after_load(_):
    purge_legacy_tokens()


@persistent
def before_save(_):
    purge_legacy_tokens()


@persistent
def before_undo(_):
    runtime.solver = None
    runtime.snapshot = None
    runtime.writer = None
    runtime.status = "Undo changed the scene; recalibrate reference if needed"


@persistent
def after_save(_):
    for rig in bpy.data.objects:
        if rig.type == "ARMATURE" and rig.animation_data and rig.animation_data.action:
            action = rig.animation_data.action
            if action.get("abm_state") == "READY_IN_SCENE":
                runtime.status = "Scene saved"
                if runtime.sock:
                    runtime.send(
                        Kind.STATUS,
                        dict(
                            state="SCENE_SAVED",
                            take_id=action.get("abm_take_id"),
                            source_hash=action.get("abm_source_hash"),
                        ),
                    )


CLASSES = (
    ABMBoneMapping,
    ABMSettings,
    ABM_OT_action,
    ABM_OT_locate_source,
    ABM_OT_archive_take,
    ABM_OT_reset_mapping,
    ABM_PT_panel,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.abm_settings = PointerProperty(type=ABMSettings)
    bpy.types.WindowManager.abm_manual_token = StringProperty(
        name="Manual Pairing Token",
        description="Optional manual pairing token (for remote recorders). By default, the local recorder token is read automatically.",
        subtype="PASSWORD",
        default="",
    )
    purge_legacy_tokens()
    bpy.app.handlers.load_pre.append(before_load)
    bpy.app.handlers.load_post.append(after_load)
    bpy.app.handlers.save_pre.append(before_save)
    bpy.app.handlers.undo_pre.append(before_undo)
    bpy.app.handlers.save_post.append(after_save)
    bpy.app.timers.register(timer, persistent=True)


def unregister():
    runtime.disconnect()
    runtime.clear_source()
    supervisor = get_service_supervisor()
    supervisor.stop_when_idle()
    supervisor.release()
    supervisor.disconnect()
    if bpy.app.timers.is_registered(timer):
        bpy.app.timers.unregister(timer)
    for collection, handler in [
        (bpy.app.handlers.load_pre, before_load),
        (bpy.app.handlers.load_post, after_load),
        (bpy.app.handlers.save_pre, before_save),
        (bpy.app.handlers.undo_pre, before_undo),
        (bpy.app.handlers.save_post, after_save),
    ]:
        if handler in collection:
            collection.remove(handler)
    del bpy.types.Scene.abm_settings
    if hasattr(bpy.types.WindowManager, "abm_manual_token"):
        del bpy.types.WindowManager.abm_manual_token
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
