"""Tracking-aware processing and geometric foot contacts for motion capture."""

import dataclasses
import math
from mathutils import Matrix, Vector
from .protocol import ProtocolError
from .retarget import matrix, flatten
from .quality import SolverGeometry, AdaptiveFilter


def angle(a, b):
    return 2 * math.acos(min(1.0, abs(a.normalized().dot(b.normalized()))))


class JointRecovery:
    """Source-time holds and finite recovery blends from a frozen starting pose."""

    def __init__(self, settings):
        self.settings = settings
        self.channels = {}
        self.rejected = 0

    def mark_missing(self, state, dt):
        state["missing"] += dt
        state["observation"] = None
        state["candidate"] = None
        if state["phase"] not in {"holding", "fallback"}:
            state["phase"] = "holding"

    def lose_tracking(self, dt):
        for state in self.channels.values():
            self.mark_missing(state, dt)

    def recovering(self, key):
        return self.channels[key]["phase"] == "recovering"

    def step(self, key, value, dt, reliable=True, rotation=True, fallback=None):
        s = self.settings
        state = self.channels.get(key)
        if state is None:
            initial = value if reliable or fallback is None else fallback
            self.channels[key] = dict(
                value=initial.copy(),
                missing=0.0 if reliable else dt,
                phase="tracked" if reliable else "holding",
                candidate=None,
                observation=value.copy() if reliable else None,
                elapsed=0.0,
                start=initial.copy(),
            )
            return initial.copy()
        old = state["value"]
        observed = state["observation"]
        # Compare source observations, not the recovering output's intentional lag.
        distance = (
            (angle(observed, value) if rotation else (observed - value).length)
            if observed is not None
            else 0.0
        )
        limit = s["spike_angle" if rotation else "spike_distance"]
        speed = s["max_angular_speed" if rotation else "max_root_speed"]
        spike = reliable and distance > limit and distance / max(dt, 1e-6) > speed
        if spike:
            candidate = state["candidate"]
            # A continuing fast movement is accepted once a subsequent observation
            # corroborates it. One isolated excursion never drives the filter.
            corroborated = (
                candidate is not None
                and (angle(candidate, value) if rotation else (candidate - value).length)
                < limit * 0.5
            )
            if corroborated:
                spike = False
                state["candidate"] = None
            else:
                state["candidate"] = value.copy()
                self.rejected += 1
        else:
            state["candidate"] = None
        if spike:
            return old.copy()
        if not reliable:
            self.mark_missing(state, dt)
            if state["missing"] <= s["joint_hold_seconds"]:
                return old.copy()
            target = fallback if fallback is not None else old
            if state["phase"] != "fallback":
                state.update(phase="fallback", start=old.copy())
            amount = min(1.0, (state["missing"] - s["joint_hold_seconds"]) / s["recovery_seconds"])
        else:
            target = value
            state["observation"] = value.copy()
            state["missing"] = 0.0
            if state["phase"] in {"holding", "fallback"}:
                state.update(phase="recovering", start=old.copy(), elapsed=0.0)
            if state["phase"] == "recovering":
                state["elapsed"] += dt
                amount = min(1.0, state["elapsed"] / s["recovery_seconds"])
                if amount >= 1.0 - 1e-9:
                    amount = 1.0
                    state["phase"] = "tracked"
            else:
                amount = 1.0
        start = state["start"] if amount < 1.0 else target
        if rotation:
            target = target.copy()
            if start.dot(target) < 0:
                target.negate()
            result = start.slerp(target, amount).normalized()
        else:
            result = start.lerp(target, amount)
        state["value"] = result.copy()
        return result


class MotionSolver(SolverGeometry):
    def __init__(self, rig, snapshot):
        super().__init__(rig, snapshot)
        self.recovery = JointRecovery(self.settings)
        self.tracking_sources = set(snapshot.get("tracking_sources", []))
        self.source_cache = {}
        self.quality_flags = {}
        self.last_contact_states = {}
        self.joint_reliability = {}
        self.required_tracked_sources = {
            source for leg in self.legs.values() for source in leg["sources"][:2]
        }
        self.group_filters = {}
        for group, factor in [
            ("arms", self.settings["arm_cutoff_scale"]),
            ("torso", self.settings["torso_cutoff_scale"]),
            ("feet", self.settings["foot_cutoff_scale"]),
        ]:
            self.group_filters[group] = AdaptiveFilter(
                dict(self.settings, min_cutoff=self.settings["min_cutoff"] * factor)
            )
        self.channels = []
        for source, name in snapshot["mapping"].items():
            group = (
                "arms"
                if any(x in source.lower() for x in ("arm", "hand", "shoulder"))
                else "feet"
                if any(x in source.lower() for x in ("leg", "foot", "toe"))
                else "torso"
            )
            self.channels.append(
                (
                    source,
                    name,
                    snapshot["source_indices"][source],
                    matrix(snapshot["target_basis"][name]).to_quaternion(),
                    self.group_filters[group],
                )
            )
        self.geometry = {}
        supplied = snapshot.get("foot_geometry", {})
        for side, leg in self.legs.items():
            name = leg["names"][2]
            bone = rig.pose.bones[name]
            reference = self.world @ matrix(snapshot["target_reference"][name])
            # Default sole thickness follows foot-bone length. Profiles may supply
            # measured local heel/toe points; freeze these with every new take.
            length = bone.bone.length
            down = reference.to_quaternion().inverted() @ Vector(
                (0, 0, -length * 0.275 * self.world.to_scale().x)
            )
            scale = self.world.to_scale().x
            down /= scale
            points = supplied.get(
                side,
                dict(
                    heel=list(Vector((0, -length * 0.15, 0)) + down),
                    toe=list(Vector((0, length * 0.85, 0)) + down),
                ),
            )
            if set(points) != {"heel", "toe"}:
                raise ProtocolError("Foot geometry needs local heel and toe points")
            for point in points.values():
                if len(point) != 3 or any(
                    isinstance(v, bool) or not isinstance(v, (float, int)) or not math.isfinite(v)
                    for v in point
                ):
                    raise ProtocolError("Invalid foot contact geometry")
            self.geometry[side] = {k: Vector(v) for k, v in points.items()}
            floor = (
                min((reference @ v).z for v in self.geometry[side].values())
                + self.settings["floor_offset"]
            )
            if "floor_world_z" in snapshot:
                value = snapshot["floor_world_z"]
                if (
                    isinstance(value, bool)
                    or not isinstance(value, (int, float))
                    or not math.isfinite(value)
                ):
                    raise ProtocolError("Invalid frozen floor")
                floor = value + self.settings["floor_offset"]
            leg["floor"] = floor

    def reset(self):
        super().reset()
        self.recovery = JointRecovery(self.settings)
        self.source_cache.clear()
        self.quality_flags.clear()
        self.last_contact_states.clear()
        self.joint_reliability.clear()
        for filt in self.group_filters.values():
            filt.values.clear()
            filt.previous.clear()
            filt.derivatives.clear()

    def observation_reliability(self, pose, timestamp=None):
        t = pose.timestamp if timestamp is None else timestamp
        indices = self.snapshot["source_indices"]
        self.tracking_sources.update(
            source for source, i in indices.items() if pose.valid[i] and pose.tracked[i]
        )
        return {
            source: pose.usable
            and pose.valid[i]
            and t - pose.timestamp <= 0.1
            and (
                pose.tracked[i]
                or (
                    source not in self.tracking_sources
                    and source not in self.required_tracked_sources
                )
            )
            for source, i in indices.items()
        }

    def hold(self, timestamp):
        """Hold a short whole-body gap and require fresh recovery before contacts."""
        if self.last is None:
            return None
        self.recovery.lose_tracking(max(0.0, timestamp - self.time))
        self.time = timestamp
        self.contacts.clear()
        self.previous_feet.clear()
        self.last_contact_states.clear()
        self.contact_count = 0
        self.quality_flags = {source: "held" for source in self.snapshot["mapping"]}
        self.joint_reliability = {source: False for source in self.snapshot["mapping"]}
        return {name: value.copy() for name, value in self.last.items()}

    def accepts(self, pose):
        s = self.snapshot
        return (
            pose.usable
            and pose.schema_id == s["schema_id"]
            and pose.session_id == s["session_id"]
            and pose.segment_id == s["segment_id"]
            and pose.body_id == s["body_id"]
            and all(i < len(pose.valid) for i in s["source_indices"].values())
            and pose.valid[s["source_indices"][s["root_source"]]]
        )

    def solve(self, pose, timestamp=None):
        t = pose.timestamp if timestamp is None else timestamp
        if not self.accepts(pose):
            raise ProtocolError("Pose is incompatible or root tracking is unusable")
        if self.time is not None and t == self.time and self.last is not None:
            return {n: v.copy() for n, v in self.last.items()}
        if self.time is not None and (t < self.time or t - self.time > self.settings["reset_gap"]):
            self.reset()
        dt = max(1e-6, t - self.time) if self.time is not None else 1 / 60
        self.joint_reliability = self.observation_reliability(pose, t)
        joints = list(pose.joints)
        valid = list(pose.valid)
        for source, i in self.snapshot["source_indices"].items():
            if pose.valid[i]:
                self.source_cache[i] = pose.joints[i]
            else:
                joints[i] = self.source_cache.get(i, tuple(flatten(Matrix.Identity(4))))
                valid[i] = True
        basis = self.raw.solve(
            pose
            if valid == list(pose.valid)
            else dataclasses.replace(pose, joints=tuple(joints), valid=tuple(valid))
        )
        self.quality_flags = {}
        for source, name, i, reference, filt in self.channels:
            location, rotation, scale = basis[name].decompose()
            reliable = self.joint_reliability[source]
            if not reliable:
                self.quality_flags[source] = "held" if self.time is not None else "unobserved"
            if self.settings["reliability"]:
                rejected = self.recovery.rejected
                rotation = self.recovery.step(
                    ("r", name), rotation.normalized(), dt, reliable, True, reference
                )
                if name == self.raw.root_target:
                    location = self.recovery.step(("p", name), location, dt, reliable, False)
                if self.recovery.rejected > rejected:
                    self.quality_flags[source] = "spike_rejected"
                    self.joint_reliability[source] = False
                elif reliable and (
                    self.recovery.recovering(("r", name))
                    or (name == self.raw.root_target and self.recovery.recovering(("p", name)))
                ):
                    self.quality_flags[source] = "recovering"
                    self.joint_reliability[source] = False
            if self.settings["smoothing"]:
                rotation = filt.step(("r", name), rotation.normalized(), dt, True)
                if name == self.raw.root_target:
                    location = filt.step(("p", name), location, dt)
            basis[name] = Matrix.LocRotScale(location, rotation, scale)
        if t - pose.timestamp > 0.1:
            self.contacts.clear()
            self.previous_feet.clear()
        elif self.settings["foot_lock"]:
            basis = self.correct_feet(basis, pose, dt, self.joint_reliability)
        self.time = t
        self.last = {n: v.copy() for n, v in basis.items()}
        return basis

    def correct_feet(self, basis, pose, dt, reliability=None):
        # Refinement supplies the original sample's recovery/spike reliability;
        # its contact-only solver must not infer it from its initial snapshot.
        if reliability is None:
            reliability = self.observation_reliability(pose)
        s = self.settings
        world = self.world_matrices(basis)
        goals = {}
        rotations = {}
        for side, leg in self.legs.items():
            foot = world[leg["names"][2]]
            points = {k: foot @ v for k, v in self.geometry[side].items()}
            heel, toe = points["heel"], points["toe"]
            floor = leg["floor"]
            pivot = (
                "toe" if heel.z - toe.z > 0.025 else "heel" if toe.z - heel.z > 0.025 else "flat"
            )
            local = (
                (self.geometry[side]["heel"] + self.geometry[side]["toe"]) / 2
                if pivot == "flat"
                else self.geometry[side][pivot]
            )
            point = foot @ local
            previous = self.previous_feet.get(side)
            # Compare like contact points even when transitioning flat/heel/toe.
            speed = (point - previous @ local).length / dt if previous is not None else float("inf")
            self.previous_feet[side] = foot.copy()
            # An inherited terminal foot is allowed, but both observed upper and
            # lower leg must remain reliable; one tracked thigh is insufficient.
            tracked = all(reliability.get(source, False) for source in leg["sources"])
            state = self.contacts.setdefault(
                side,
                dict(
                    elapsed=0.0,
                    weight=0.0,
                    locked=False,
                    target=point.copy(),
                    pivot=pivot,
                    local=local.copy(),
                    rotation=foot.to_quaternion(),
                ),
            )
            if state["locked"] and pivot != state["pivot"]:
                state["target"] += state["rotation"] @ (
                    (local - state["local"]) * self.world.to_scale().x
                )
                state["pivot"] = pivot
                state["local"] = local.copy()
            height = point.z - floor
            if state["locked"]:
                if (
                    not tracked
                    or height > s["release_height"]
                    or speed > s["release_speed"]
                    or (point - state["target"]).length > s["max_lock_distance"]
                ):
                    state["locked"] = False
                    state["elapsed"] = 0.0
            elif (
                tracked
                and -s["release_height"] <= height <= s["contact_height"]
                and speed < s["contact_speed"]
            ):
                state["elapsed"] += dt
                if state["elapsed"] >= s["contact_delay"]:
                    state.update(
                        locked=True,
                        target=point.copy(),
                        pivot=pivot,
                        local=local.copy(),
                        rotation=foot.to_quaternion(),
                    )
                    state["target"].z = floor
            else:
                state["elapsed"] = 0.0
            state["weight"] = (
                min(1.0, state["weight"] + dt / s["blend_seconds"])
                if state["locked"]
                else max(0.0, state["weight"] - dt / s["blend_seconds"])
            )
            if state["weight"] > 0:
                q = foot.to_quaternion()
                if pivot == "flat":
                    q = q.slerp(state["rotation"], state["weight"]).normalized()
                desired = state["target"] - q @ (local * self.world.to_scale().x)
                goals[side] = foot.translation.lerp(desired, state["weight"])
                rotations[side] = q
            self.last_contact_states[side] = pivot if state["locked"] else "air"
        self.contact_count = sum(v["locked"] for v in self.contacts.values())
        return self.solve_leg_goals(basis, world, goals, rotations)
