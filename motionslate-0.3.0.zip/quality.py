"""Deterministic optional animation processing; raw source data is never modified."""

import math
from mathutils import Matrix, Vector
from .retarget import FKSolver, matrix
from .protocol import ProtocolError

PROCESSING_VERSION = 3
DEFAULTS = dict(
    version=PROCESSING_VERSION,
    smoothing=True,
    min_cutoff=2.0,
    translation_beta=15.0,
    rotation_beta=4.0,
    derivative_cutoff=2.0,
    reset_gap=0.25,
    foot_lock=True,
    floor_offset=0.0,
    contact_height=0.04,
    release_height=0.09,
    contact_speed=0.18,
    release_speed=0.45,
    contact_delay=0.08,
    blend_seconds=0.08,
    max_lock_distance=0.18,
    max_pelvis_correction=0.08,
    reliability=True,
    recovery_seconds=0.12,
    joint_hold_seconds=0.12,
    max_angular_speed=35.0,
    spike_angle=0.6,
    max_root_speed=8.0,
    spike_distance=0.15,
    arm_cutoff_scale=1.3,
    torso_cutoff_scale=0.8,
    foot_cutoff_scale=1.0,
)


def configuration(value=None):
    if value and (
        type(value.get("version", PROCESSING_VERSION)) is not int
        or value.get("version", PROCESSING_VERSION) not in (1, 2, 3)
    ):
        raise ProtocolError("Unsupported processing version")
    result = dict(DEFAULTS)
    result.update(value or {})
    result["version"] = PROCESSING_VERSION
    if set(result) - set(DEFAULTS):
        raise ProtocolError("Unknown processing setting")
    for name, value in result.items():
        if name == "version":
            continue
        if name in {"smoothing", "foot_lock", "reliability"}:
            if type(value) is not bool:
                raise ProtocolError("Invalid quality toggle")
        elif (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(value)
        ):
            raise ProtocolError("Invalid processing setting")
        elif name != "floor_offset" and value <= 0:
            raise ProtocolError("Processing settings must be positive")
    if result["joint_hold_seconds"] > 0.25 or result["recovery_seconds"] > 1:
        raise ProtocolError("Joint recovery interval exceeds limit")
    return result


def alpha(cutoff, dt):
    return 1 / (1 + 1 / (2 * math.pi * cutoff * dt))


class AdaptiveFilter:
    def __init__(self, settings):
        self.settings = settings
        self.values = {}
        self.previous = {}
        self.derivatives = {}

    def step(self, key, value, dt, rotation=False):
        if key not in self.values:
            self.values[key] = value.copy()
            self.previous[key] = value.copy()
            self.derivatives[key] = Vector((0, 0, 0))
            return value.copy()
        raw = value.copy()
        previous = self.previous[key]
        if rotation:
            if previous.dot(raw) < 0:
                raw.negate()
            delta = previous.rotation_difference(raw)
            if delta.w < 0:
                delta.negate()
            velocity = delta.axis * delta.angle / dt if delta.angle > 1e-8 else Vector((0, 0, 0))
        else:
            velocity = (raw - previous) / dt
        derivative = self.derivatives[key].lerp(
            velocity, alpha(self.settings["derivative_cutoff"], dt)
        )
        beta = self.settings["rotation_beta" if rotation else "translation_beta"]
        amount = alpha(self.settings["min_cutoff"] + beta * derivative.length, dt)
        last = self.values[key]
        if rotation:
            if last.dot(raw) < 0:
                raw.negate()
            result = last.slerp(raw, amount).normalized()
        else:
            result = last.lerp(raw, amount)
        self.previous[key] = raw
        self.derivatives[key] = derivative
        self.values[key] = result.copy()
        return result


class SolverGeometry:
    def __init__(self, rig, snapshot):
        self.raw = FKSolver(rig, snapshot)
        self.rig = rig
        self.snapshot = snapshot
        self.settings = configuration(snapshot.get("processing"))
        self.time = None
        self.last = None
        self.contacts = {}
        self.previous_feet = {}
        self.world = matrix(snapshot["target_world"])
        self.inverse = self.world.inverted()
        self.legs = {}
        self.disabled_legs = []
        for side in ("left", "right"):
            sources = [side + suffix for suffix in ("_upLeg_joint", "_leg_joint", "_foot_joint")]
            names = [snapshot["mapping"].get(s) for s in sources]
            if any(n is None for n in names):
                self.disabled_legs.append(side + ": missing leg mapping")
                continue
            upper, lower, foot = [rig.pose.bones[n] for n in names]
            if lower.parent != upper or foot.parent != lower:
                self.disabled_legs.append(side + ": requires a direct upper/lower/foot chain")
                continue
            self.legs[side] = dict(
                names=names,
                sources=sources,
                indices=[snapshot["source_indices"][s] for s in sources],
            )
        self.contact_count = 0

    def __getattr__(self, name):
        return getattr(self.raw, name)

    def reset(self):
        self.time = None
        self.last = None
        self.contacts.clear()
        self.previous_feet.clear()
        self.contact_count = 0

    def world_matrices(self, basis):
        values = {}
        for bone in self.raw.order:
            parent = bone.parent
            kwargs = (
                dict(
                    parent_matrix=values[parent.name], parent_matrix_local=parent.bone.matrix_local
                )
                if parent
                else {}
            )
            values[bone.name] = bone.bone.convert_local_to_pose(
                basis[bone.name], bone.bone.matrix_local, **kwargs
            )
        return {name: self.world @ value for name, value in values.items()}

    def from_overrides(self, basis, overrides):
        values = {}
        result = {}
        for bone in self.raw.order:
            parent = bone.parent
            kwargs = (
                dict(
                    parent_matrix=values[parent.name], parent_matrix_local=parent.bone.matrix_local
                )
                if parent
                else {}
            )
            value = (
                self.inverse @ overrides[bone.name]
                if bone.name in overrides
                else bone.bone.convert_local_to_pose(
                    basis[bone.name], bone.bone.matrix_local, **kwargs
                )
            )
            result[bone.name] = bone.bone.convert_local_to_pose(
                value, bone.bone.matrix_local, invert=True, **kwargs
            )
            values[bone.name] = value
        return result

    def solve_leg_goals(self, basis, world, goals, rotations=None):
        s = self.settings
        # Lower the pelvis only as much as needed to keep planted legs reachable.
        correction = 0.0
        for side, target in goals.items():
            a, b, c = self.legs[side]["names"]
            hip, knee, ankle = [world[n].translation for n in (a, b, c)]
            reach = (knee - hip).length + (ankle - knee).length
            excess = (target - hip).length - reach * 0.9999
            if excess > 0 and hip.z > target.z:
                correction = max(
                    correction,
                    min(
                        s["max_pelvis_correction"],
                        excess / max(0.2, (hip.z - target.z) / max((target - hip).length, 1e-6)),
                    ),
                )
        if correction:
            root = world[self.raw.root_target].copy()
            root.translation.z -= correction
            basis = self.from_overrides(basis, {self.raw.root_target: root})
            world = self.world_matrices(basis)
        overrides = {}
        for side, target in goals.items():
            a, b, c = self.legs[side]["names"]
            hip, knee, ankle = [world[n].translation for n in (a, b, c)]
            l1 = (knee - hip).length
            l2 = (ankle - knee).length
            if min(l1, l2) < 1e-5:
                continue
            direction = target - hip
            if direction.length < 1e-6:
                continue
            distance = max(abs(l1 - l2) + 1e-5, min(l1 + l2 - 1e-5, direction.length))
            direction.normalize()
            bend = (knee - hip) - direction * (knee - hip).dot(direction)
            state = self.contacts[side]
            if bend.length < 1e-4:
                bend = state.get("bend", Vector((0, -1, 0))).copy()
                bend -= direction * bend.dot(direction)
                if bend.length < 1e-4:
                    bend = direction.cross(Vector((1, 0, 0)))
            bend.normalize()
            state["bend"] = bend.copy()
            along = (l1 * l1 - l2 * l2 + distance * distance) / (2 * distance)
            new_knee = hip + direction * along + bend * math.sqrt(max(0, l1 * l1 - along * along))
            end = hip + direction * distance
            qa = (knee - hip).rotation_difference(new_knee - hip) @ world[a].to_quaternion()
            qb = (ankle - knee).rotation_difference(end - new_knee) @ world[b].to_quaternion()
            for name, location, rotation in (
                (a, hip, qa),
                (b, new_knee, qb),
                (c, end, (rotations or {}).get(side, world[c].to_quaternion())),
            ):
                overrides[name] = Matrix.LocRotScale(location, rotation, world[name].to_scale())
        return self.from_overrides(basis, overrides) if overrides else basis
