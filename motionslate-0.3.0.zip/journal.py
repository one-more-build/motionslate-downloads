"""Checksummed source records and a rebuildable, disk-backed take history.

An ingestion cursor is a record index, never a source sequence. All mutations
must run on the recorder's one ordered disk worker.
"""

from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import uuid
import zlib

from .protocol import Kind, ProtocolError, Schema, decode, frame, json_bytes, uid, check_length

MAGIC = b"ABMJ\x01\x00\x00\x00"
HASH_DOMAIN = b"ABM2-CANONICAL-v1\n"


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("wb") as handle:
        handle.write(json_bytes(value))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
    directory = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def ranges(sequences):
    result = []
    for seq in sorted(set(sequences)):
        if result and result[-1][1] + 1 == seq:
            result[-1][1] = seq
        else:
            result.append([seq, seq])
    return result


def missing_ranges(first, last, present):
    """Range arithmetic without allocating a possibly hostile sequence range."""
    result, next_seq = [], first
    for lo, hi in ranges(s for s in present if first <= s <= last):
        if next_seq < lo:
            result.append([next_seq, lo - 1])
        next_seq = hi + 1
    if next_seq <= last:
        result.append([next_seq, last])
    return result


@dataclass(frozen=True)
class Record:
    offset: int
    length: int
    key: tuple


class Journal:
    def __init__(self, path, repair=False):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            with self.path.open("xb") as f:
                f.write(MAGIC)
                f.flush()
                os.fsync(f.fileno())
        self.file = self.path.open("r+b")
        self.write_failed = False
        if self.file.read(len(MAGIC)) != MAGIC:
            self.file.close()
            raise ProtocolError("Unknown journal format")
        self.valid_end = len(MAGIC)
        self.damage = None
        for _ in self.scan():
            pass
        if self.damage and repair:
            # Preserve the damaged tail for diagnosis before truncating it.
            self.file.seek(self.valid_end)
            tail = self.file.read()
            evidence = self.path.with_name(
                self.path.name + ".damaged-" + hashlib.sha256(tail).hexdigest()[:12]
            )
            if not evidence.exists():
                evidence.write_bytes(tail)
            self.file.truncate(self.valid_end)
            self.sync()
        elif self.damage:
            self.file.close()
            raise ProtocolError(self.damage)

    def scan(self):
        self.file.seek(len(MAGIC))
        while True:
            offset = self.file.tell()
            prefix = self.file.read(4)
            if not prefix:
                return
            if len(prefix) != 4:
                self.damage = "Truncated record length"
                return
            length = struct.unpack(">I", prefix)[0]
            try:
                check_length(length)
            except ProtocolError:
                self.damage = "Invalid journal record length"
                return
            payload, crc = self.file.read(length), self.file.read(4)
            if len(payload) != length or len(crc) != 4:
                self.damage = "Truncated record payload/checksum"
                return
            if zlib.crc32(payload) != struct.unpack("<I", crc)[0]:
                self.damage = "Journal checksum mismatch"
                return
            self.valid_end = self.file.tell()
            yield offset, payload

    def append(self, payload):
        if self.write_failed:
            raise ProtocolError("Journal write failed; reopen and repair before resuming")
        check_length(len(payload))
        self.file.seek(0, os.SEEK_END)
        offset = self.file.tell()
        try:
            record = frame(payload) + struct.pack("<I", zlib.crc32(payload))
            if self.file.write(record) != len(record):
                raise OSError("Short journal write")
        except OSError:
            self.write_failed = True
            raise
        self.valid_end = self.file.tell()
        return offset

    def read(self, record):
        self.file.seek(record.offset + 4)
        data = self.file.read(record.length)
        if len(data) != record.length:
            raise ProtocolError("Journal changed underneath index")
        return data

    def sync(self):
        if self.write_failed:
            raise ProtocolError("Journal write failed; reopen and repair before resuming")
        try:
            self.file.flush()
            os.fsync(self.file.fileno())
        except OSError:
            self.write_failed = True
            raise

    def close(self):
        self.file.close()


class TakeStore:
    def __init__(self, directory, take_id):
        self.take_id = uid(take_id)
        self.directory = Path(directory) / self.take_id
        self.directory.mkdir(parents=True, exist_ok=True)
        self.journal = Journal(self.directory / "source.partial", repair=True)
        self.records = []
        self.by_key = {}
        self.poses = {}
        self.schemas = {}
        self.events = {}
        self.session_id = None
        self.segment_id = None
        self.highest_sequence = -1
        self.recovered_sequences = set()
        # Materialize offsets, not all payloads; scan/read share a file handle.
        offsets = []
        for offset, payload in self.journal.scan():
            offsets.append((offset, len(payload)))
        for offset, length in offsets:
            record = Record(offset, length, ())
            self._index(self.journal.read(record), offset)
        self.durable_cursor = len(self.records)
        self.manifest = None
        path = self.directory / "manifest.json"
        if path.exists():
            self.manifest = json.loads(path.read_text())
            if (
                self.manifest.get("record_count") != len(self.records)
                or self.manifest.get("source_hash") != self.canonical_hash()
            ):
                self.manifest = None
                os.replace(path, self.directory / "manifest.invalid.json")

    def _key(self, kind, body):
        if kind == Kind.SCHEMA:
            schema = Schema.from_body(body)
            return (0, schema.schema_id)
        if kind == Kind.POSE:
            return (2, body.sequence)
        if kind == Kind.EVENT:
            from .protocol import integer

            if uid(body.get("take_id")) != self.take_id:
                raise ProtocolError("Event belongs to another take")
            integer(body.get("event_seq"), 0, 2**53 - 1, "Event sequence")
            if body.get("event") not in {
                "TAKE_PREPARED",
                "TAKE_STARTED",
                "TAKE_ENDED",
                "TRACKING_CHANGED",
                "SEGMENT_ENDED",
                "TAKE_CANCELLED",
            }:
                raise ProtocolError("Unrecognized source event")
            return (1, body["event_seq"])
        raise ProtocolError("Only schema, source events and poses belong in a journal")

    def _validate(self, payload):
        kind, body = decode(payload)
        key = self._key(kind, body)
        if kind == Kind.POSE:
            if body.take_id != self.take_id:
                raise ProtocolError("Pose belongs to another take")
            if body.schema_id not in self.schemas:
                raise ProtocolError("Schema must precede its poses")
            body.validate(self.schemas[body.schema_id])
            if self.session_id and body.session_id != self.session_id:
                raise ProtocolError("Take changed capture session")
            if self.segment_id and body.segment_id != self.segment_id:
                raise ProtocolError("Take changed coordinate segment")
        if kind == Kind.EVENT:
            self._validate_event(body)
        if key in self.by_key and self.journal.read(self.by_key[key]) != payload:
            raise ProtocolError("Conflicting payload for existing source identity")
        return kind, body, key

    def _validate_event(self, body):
        from .protocol import finite, integer

        if body["event"] == "TAKE_STARTED":
            finite(body.get("t0"), "take start")
            integer(body.get("first_sequence"), 0, 2**64 - 1, "First sequence")
            uid(body.get("segment_id"))
            uid(body.get("session_id"))
        if body["event"] == "TAKE_ENDED":
            finite(body.get("t_stop"), "take end")
            integer(body.get("first_sequence"), 0, 2**64 - 1, "First sequence")
            integer(body.get("last_sequence"), body["first_sequence"], 2**64 - 1, "Last sequence")
            if body["last_sequence"] - body["first_sequence"] > 10_000_000:
                raise ProtocolError("Take sample range exceeds limit")
            if not isinstance(body.get("reason"), str):
                raise ProtocolError("Missing end reason")

    def _index(self, payload, offset):
        kind, body, key = self._validate(payload)
        if key in self.by_key:
            return False
        record = Record(offset, len(payload), key)
        self.records.append(record)
        self.by_key[key] = record
        if kind == Kind.SCHEMA:
            self.schemas[body["schema_id"]] = Schema.from_body(body)
        elif kind == Kind.POSE:
            self.poses[body.sequence] = record
            self.session_id, self.segment_id = body.session_id, body.segment_id
            if body.sequence < self.highest_sequence:
                self.recovered_sequences.add(body.sequence)
            self.highest_sequence = max(self.highest_sequence, body.sequence)
        else:
            self.events[body["event_seq"]] = body
        return True

    def append(self, payload, sync=True):
        _, _, key = self._validate(payload)
        if key in self.by_key:
            return False
        if self.manifest:
            raise ProtocolError("Finalized source cannot be modified")
        offset = self.journal.append(payload)
        self._index(payload, offset)
        if sync:
            self.sync()
        return True

    def sync(self):
        self.journal.sync()
        self.durable_cursor = len(self.records)

    def history(self, cursor=0, limit=128):
        from .protocol import integer

        integer(cursor, 0, len(self.records), "Cursor")
        integer(limit, 1, 128, "Batch limit")
        end = min(cursor + limit, self.durable_cursor)
        return [self.journal.read(r) for r in self.records[cursor:end]], end

    def source_history(self, cursor=0, limit=128):
        from .protocol import integer

        if not self.manifest:
            raise ProtocolError("Source-order replay requires a verified archive")
        if not hasattr(self, "_canonical_records"):
            self._canonical_records = tuple(self.by_key[key] for key in sorted(self.by_key))
        integer(cursor, 0, len(self._canonical_records), "Source cursor")
        integer(limit, 1, 128, "Batch limit")
        end = min(cursor + limit, len(self._canonical_records))
        return (
            [self.journal.read(r) for r in self._canonical_records[cursor:end]],
            end,
            end == len(self._canonical_records),
        )

    def status(self):
        starts = [e for e in self.events.values() if e["event"] == "TAKE_STARTED"]
        ends = [e for e in self.events.values() if e["event"] == "TAKE_ENDED"]
        start = starts[0] if len(starts) == 1 else None
        end = ends[0] if len(ends) == 1 else None
        missing = (
            missing_ranges(end["first_sequence"], end["last_sequence"], self.poses) if end else []
        )
        durable_sequences = [r.key[1] for r in self.records[: self.durable_cursor] if r.key[0] == 2]
        return dict(
            take_id=self.take_id,
            received_ranges=ranges(self.poses),
            durable_ranges=ranges(durable_sequences),
            missing_ranges=missing,
            cursor=self.durable_cursor,
            revision=len(self.records),
            recovered_ranges=ranges(self.recovered_sequences),
            start=start,
            end=end,
            source_durable=bool(self.manifest),
            source_hash=self.manifest.get("source_hash") if self.manifest else None,
            state="SOURCE_DURABLE"
            if self.manifest
            else ("RECOVERY_REQUIRED" if end else "RECEIVING"),
        )

    def canonical_hash(self):
        digest = hashlib.sha256(HASH_DOMAIN)
        for key in sorted(self.by_key):
            digest.update(frame(self.journal.read(self.by_key[key])))
        return digest.hexdigest()

    def finalize(self, expected_hash=None):
        self.sync()
        ordered = sorted(self.poses)
        poses_info = {
            seq: decode(self.journal.read(self.poses[seq]))[1].timestamp for seq in ordered
        }
        digest = self.canonical_hash()
        start, end = validate_take_boundaries(
            events=self.events,
            poses_info=poses_info,
            session_id=self.session_id,
            segment_id=self.segment_id,
            canonical_hash=digest,
            expected_hash=expected_hash,
        )
        target = self.directory / "source.motion.tmp"
        with target.open("wb") as f:
            f.write(MAGIC)
            for key in sorted(self.by_key):
                payload = self.journal.read(self.by_key[key])
                f.write(frame(payload) + struct.pack("<I", zlib.crc32(payload)))
            f.flush()
            os.fsync(f.fileno())
        os.replace(target, self.directory / "source.motion")
        manifest = dict(
            format="ABM2-capture-1",
            take_id=self.take_id,
            source_hash=digest,
            sample_ranges=[[end["first_sequence"], end["last_sequence"]]],
            t0=start["t0"],
            t_stop=end["t_stop"],
            record_count=len(self.records),
            source_complete=True,
            stop_reason=end["reason"],
        )
        atomic_json(self.directory / "manifest.json", manifest)
        self.manifest = manifest
        return manifest

    def close(self):
        self.journal.close()


def validate_take_boundaries(
    events: dict,
    poses_info: dict,
    session_id: str | None,
    segment_id: str | None,
    canonical_hash: str | None = None,
    expected_hash: str | None = None,
    manifest: dict | None = None,
):
    """Validate canonical take boundaries, event history, pose sequences, and timestamps."""
    starts = [e for e in events.values() if e.get("event") == "TAKE_STARTED"]
    ends = [e for e in events.values() if e.get("event") == "TAKE_ENDED"]
    if len(starts) != 1 or len(ends) != 1:
        raise ProtocolError("Source boundaries or samples are incomplete")
    start, end = starts[0], ends[0]

    event_sequences = sorted(events)
    if event_sequences != list(range(len(event_sequences))) or not any(
        e.get("event") == "TAKE_PREPARED" for e in events.values()
    ):
        raise ProtocolError("Source event history is incomplete")

    if end["t_stop"] <= start["t0"] or start["first_sequence"] < end["first_sequence"]:
        raise ProtocolError("Invalid performed interval")

    if uid(start["session_id"]) != session_id or uid(start["segment_id"]) != segment_id:
        raise ProtocolError("Start identity differs from source poses")

    ordered = sorted(poses_info)
    if not ordered or ordered[0] != end["first_sequence"] or ordered[-1] != end["last_sequence"]:
        raise ProtocolError("Archive extent differs from authoritative range")

    if len(ordered) != (end["last_sequence"] - end["first_sequence"] + 1):
        raise ProtocolError("Source boundaries or samples are incomplete")

    previous = None
    for seq in ordered:
        val = poses_info[seq]
        if isinstance(val, (tuple, list)):
            timestamp = val[0]
            if len(val) >= 3:
                if uid(val[1]) != session_id or uid(val[2]) != segment_id:
                    raise ProtocolError("Pose session or segment differs from start boundary")
        else:
            timestamp = val
        if previous is not None and timestamp <= previous:
            raise ProtocolError("Source timestamps are not strictly increasing")
        previous = timestamp

    first_val = poses_info[ordered[0]]
    first_timestamp = first_val[0] if isinstance(first_val, (tuple, list)) else first_val
    last_val = poses_info[ordered[-1]]
    last_timestamp = last_val[0] if isinstance(last_val, (tuple, list)) else last_val

    if first_timestamp > start["t0"] or last_timestamp < end["t_stop"]:
        raise ProtocolError("Missing take boundary bracketing samples")

    if expected_hash and canonical_hash != expected_hash:
        raise ProtocolError("Canonical source hash mismatch")

    if manifest is not None:
        if canonical_hash and manifest.get("source_hash") != canonical_hash:
            raise ProtocolError("Manifest source hash mismatch")
        if (
            abs(manifest.get("t0", 0.0) - start["t0"]) > 1e-6
            or abs(manifest.get("t_stop", 0.0) - end["t_stop"]) > 1e-6
        ):
            raise ProtocolError("Manifest boundary interval mismatch")
        if manifest.get("stop_reason") != end["reason"]:
            raise ProtocolError("Manifest stop reason mismatch")
        if manifest.get("sample_ranges") != [[end["first_sequence"], end["last_sequence"]]]:
            raise ProtocolError("Manifest sample ranges mismatch")

    return start, end


class ReadOnlySource:
    """Consolidated, read-only finalized source reader and verifier."""

    def __init__(
        self,
        directory: Path | str,
        take_id: str | None = None,
        expected_hash: str | None = None,
    ):
        path = Path(directory).expanduser().resolve()
        if take_id is not None:
            take_id = uid(take_id)
            if path.name == take_id:
                self.directory = path
            else:
                self.directory = path / take_id
        else:
            self.directory = path
        self.expected_take_id = take_id
        self.expected_hash = expected_hash
        self.manifest_path = self.directory / "manifest.json"
        self.motion_path = self.directory / "source.motion"
        if not self.manifest_path.exists():
            raise ProtocolError(f"Missing manifest: {self.manifest_path}")
        if not self.motion_path.exists():
            raise ProtocolError(f"Missing source motion journal: {self.motion_path}")

        try:
            self.manifest = json.loads(self.manifest_path.read_text())
        except Exception as e:
            raise ProtocolError(f"Invalid manifest JSON: {e}") from e

        self._validate_manifest_structure()
        self.take_id = self.manifest["take_id"]
        self.source_hash = self.manifest["source_hash"]

        self.file = self.motion_path.open("rb")
        self.initial_stat = self.motion_path.stat()
        self.verified = False
        self.events = {}

    def _validate_manifest_structure(self):
        if not isinstance(self.manifest, dict):
            raise ProtocolError("Manifest must be a JSON object")
        if self.manifest.get("format") != "ABM2-capture-1":
            raise ProtocolError("Unsupported source manifest format")
        if not self.manifest.get("source_complete"):
            raise ProtocolError("Source manifest indicates incomplete capture")
        take_id = uid(self.manifest.get("take_id"))
        if self.expected_take_id and take_id != self.expected_take_id:
            raise ProtocolError(
                f"Manifest take_id {take_id} does not match expected {self.expected_take_id}"
            )
        source_hash = self.manifest.get("source_hash")
        if not isinstance(source_hash, str) or len(source_hash) != 64:
            raise ProtocolError("Invalid manifest source_hash")
        if self.expected_hash and source_hash != self.expected_hash:
            raise ProtocolError(
                f"Source hash {source_hash} does not match expected {self.expected_hash}"
            )
        record_count = self.manifest.get("record_count")
        if not isinstance(record_count, int) or record_count <= 0:
            raise ProtocolError("Invalid manifest record_count")
        t0 = self.manifest.get("t0")
        t_stop = self.manifest.get("t_stop")
        if not isinstance(t0, (int, float)) or not isinstance(t_stop, (int, float)) or t_stop <= t0:
            raise ProtocolError("Invalid manifest time interval")

    def verify_iter(self):
        """Verify the source against its manifest and canonical rules, yielding per record."""
        self.file.seek(0)
        magic = self.file.read(len(MAGIC))
        if magic != MAGIC:
            raise ProtocolError("Unknown source motion journal format")

        digest = hashlib.sha256(HASH_DOMAIN)
        schemas = {}
        events = {}
        poses_info = {}
        session_id = None
        segment_id = None
        record_count = 0

        while True:
            prefix = self.file.read(4)
            if not prefix:
                break
            if len(prefix) != 4:
                raise ProtocolError("Truncated source record length")
            length = struct.unpack(">I", prefix)[0]
            try:
                check_length(length)
            except ProtocolError:
                raise ProtocolError("Invalid source record length")
            payload = self.file.read(length)
            crc = self.file.read(4)
            if len(payload) != length or len(crc) != 4:
                raise ProtocolError("Truncated source record payload or checksum")
            if zlib.crc32(payload) != struct.unpack("<I", crc)[0]:
                raise ProtocolError("Source record checksum mismatch")

            digest.update(frame(payload))
            record_count += 1

            kind, body = decode(payload)
            if kind == Kind.SCHEMA:
                schema = Schema.from_body(body)
                if schema.schema_id in schemas:
                    raise ProtocolError("Duplicate schema definition in source")
                schemas[schema.schema_id] = schema
            elif kind == Kind.EVENT:
                if uid(body.get("take_id")) != self.take_id:
                    raise ProtocolError("Event belongs to another take")
                from .protocol import integer

                integer(body.get("event_seq"), 0, 2**53 - 1, "Event sequence")
                if body.get("event") not in {
                    "TAKE_PREPARED",
                    "TAKE_STARTED",
                    "TAKE_ENDED",
                    "TRACKING_CHANGED",
                    "SEGMENT_ENDED",
                    "TAKE_CANCELLED",
                }:
                    raise ProtocolError("Unrecognized source event")
                if body["event_seq"] in events:
                    raise ProtocolError("Duplicate event sequence in source")
                events[body["event_seq"]] = body
            elif kind == Kind.POSE:
                if body.take_id != self.take_id:
                    raise ProtocolError("Pose belongs to another take")
                if body.schema_id not in schemas:
                    raise ProtocolError("Schema must precede its poses")
                body.validate(schemas[body.schema_id])
                if session_id and body.session_id != session_id:
                    raise ProtocolError("Take changed capture session")
                if segment_id and body.segment_id != segment_id:
                    raise ProtocolError("Take changed coordinate segment")
                session_id, segment_id = body.session_id, body.segment_id
                if body.sequence in poses_info:
                    raise ProtocolError("Duplicate pose sequence in source")
                poses_info[body.sequence] = (body.timestamp, body.session_id, body.segment_id)
            else:
                raise ProtocolError("Only schema, event, and pose records belong in source journal")

            yield

        if record_count != self.manifest["record_count"]:
            raise ProtocolError(
                f"Record count mismatch: found {record_count}, manifest specifies {self.manifest['record_count']}"
            )

        canonical_hash = digest.hexdigest()
        validate_take_boundaries(
            events=events,
            poses_info=poses_info,
            session_id=session_id,
            segment_id=segment_id,
            canonical_hash=canonical_hash,
            expected_hash=self.expected_hash,
            manifest=self.manifest,
        )

        self.events = events
        self.initial_stat = self.motion_path.stat()
        self.verified = True

    def prepared_settings(self) -> dict | None:
        """Return frozen settings from TAKE_PREPARED event in the verified source stream."""
        if not self.verified:
            raise ProtocolError("Source must be verified before reading settings")
        for event in self.events.values():
            if event.get("event") == "TAKE_PREPARED":
                return event.get("settings")
        return None

    def archive_to(self, destination: Path | str) -> Path:
        """Atomically export the verified take to destination, copying only manifest.json,
        source.motion, and optional processing.json, while strictly excluding secrets,
        mutable indexes (source.partial), locks, and temporary files."""
        if not self.verified:
            raise ProtocolError("Source must be verified before archiving")

        dest = Path(destination).expanduser().resolve()
        if dest.exists() and dest.is_dir() and dest.name != self.take_id:
            target_dir = dest / self.take_id
        else:
            target_dir = dest

        if target_dir.exists():
            raise ProtocolError(f"Archive destination already exists: {target_dir}")

        parent = target_dir.parent
        parent.mkdir(parents=True, exist_ok=True)
        tmp_dir = parent / f".tmp-archive-{self.take_id}-{uuid.uuid4().hex[:8]}"
        tmp_dir.mkdir(parents=True, exist_ok=False)

        try:
            shutil.copyfile(self.manifest_path, tmp_dir / "manifest.json")
            shutil.copyfile(self.motion_path, tmp_dir / "source.motion")

            proc_path = self.directory / "processing.json"
            if proc_path.exists():
                shutil.copyfile(proc_path, tmp_dir / "processing.json")

            os.replace(tmp_dir, target_dir)
            return target_dir
        except Exception:
            if tmp_dir.exists():
                shutil.rmtree(tmp_dir, ignore_errors=True)
            raise

    def verify(self):
        for _ in self.verify_iter():
            pass

    def _check_file_unmodified(self):
        try:
            current_stat = self.motion_path.stat()
        except OSError as e:
            raise ProtocolError(f"Source motion journal unavailable: {e}") from e
        if (
            current_stat.st_ino != self.initial_stat.st_ino
            or current_stat.st_size != self.initial_stat.st_size
            or current_stat.st_mtime_ns != self.initial_stat.st_mtime_ns
        ):
            raise ProtocolError("Source file changed on disk between verification and consumption")

    def records(self):
        """Yield verified record payloads from the stable file handle."""
        if not self.verified:
            raise ProtocolError("Source must be verified before reading records")
        self._check_file_unmodified()
        self.file.seek(len(MAGIC))
        while True:
            prefix = self.file.read(4)
            if not prefix:
                return
            if len(prefix) != 4:
                raise ProtocolError("Truncated source record length")
            length = struct.unpack(">I", prefix)[0]
            check_length(length)
            payload = self.file.read(length)
            crc = self.file.read(4)
            if (
                len(payload) != length
                or len(crc) != 4
                or zlib.crc32(payload) != struct.unpack("<I", crc)[0]
            ):
                raise ProtocolError("Damaged or modified source record")
            yield payload

    def close(self):
        if hasattr(self, "file") and self.file and not self.file.closed:
            self.file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
