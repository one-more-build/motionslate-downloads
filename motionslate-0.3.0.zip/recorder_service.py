"""Blender-side service supervisor and worker lifecycle manager.

Loads worker_payload package-relatively without modifying Blender's sys.path.
Supervises child worker execution using Blender's bundled Python interpreter.
"""

from __future__ import annotations
import importlib.util
from pathlib import Path
import sys
import types

try:
    import bpy
except ImportError:
    bpy = None

import json
import os
import socket
import stat
import struct
import subprocess
import time

try:
    from .protocol import Kind, ProtocolError, control, decode, frame
    from .service_protocol import (
        MANAGEMENT_PROTOCOL,
        build_management_hello,
        build_management_request,
        validate_management_response,
    )
except ImportError:
    from motionslate.protocol import Kind, ProtocolError, control, decode, frame
    from motionslate.service_protocol import (
        MANAGEMENT_PROTOCOL,
        build_management_hello,
        build_management_request,
        validate_management_response,
    )


def get_default_service_dir() -> Path:
    """Return the default Application Support directory for MotionSlate service state."""
    return Path.home() / "Library" / "Application Support" / "MotionSlate"


def read_management_token(service_dir: Path | None = None) -> str:
    """Read the management token file securely with permission and symlink checks."""
    base = service_dir or get_default_service_dir()
    token_path = Path(base).expanduser().resolve() / "management-token.txt"

    if token_path.is_symlink():
        raise ValueError(f"Management token at {token_path} must not be a symlink")
    if not token_path.is_file():
        raise FileNotFoundError(f"Management token file not found at {token_path}")

    st = token_path.stat()
    if hasattr(os, "getuid") and (st.st_mode & 0o077 != 0):
        raise ValueError(
            f"Insecure permissions on management token file: {oct(stat.S_IMODE(st.st_mode))}. "
            "Expected 0600 (user-only)."
        )
    token = token_path.read_text(encoding="utf-8").strip()
    if not token:
        raise ValueError(f"Management token file at {token_path} is empty")
    return token


def read_readiness_descriptor(service_dir: Path | None = None) -> dict:
    """Read and validate the readiness descriptor published by the recorder service."""
    base = service_dir or get_default_service_dir()
    readiness_path = Path(base).expanduser().resolve() / "readiness.json"

    if not readiness_path.is_file():
        raise FileNotFoundError(f"Readiness descriptor not found at {readiness_path}")

    data = json.loads(readiness_path.read_text(encoding="utf-8"))
    if data.get("schema") != "motionslate-readiness-v1":
        raise ValueError(f"Unsupported readiness schema: {data.get('schema')}")
    if data.get("management_version") != MANAGEMENT_PROTOCOL:
        raise ValueError(f"Unsupported management protocol: {data.get('management_version')}")
    return data


class ManagerClient:
    """Synchronous, bounded-timeout socket client for Blender to manage the recorder."""

    def __init__(self, port: int, token: str, host: str = "127.0.0.1", timeout: float = 3.0):
        self.port = port
        self.token = token
        self.host = host
        self.timeout = timeout
        self.sock: socket.socket | None = None
        self.controller_id: str | None = None

    def connect(self) -> ManagerClient:
        if self.sock:
            return self
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        try:
            sock.connect((self.host, self.port))
            self.sock = sock

            # Send HELLO handshake
            hello = build_management_hello(self.token)
            self._send(Kind.HELLO, hello)
            kind, resp = self._recv()
            if kind != Kind.STATUS or not resp.get("hello"):
                raise ProtocolError(
                    f"Manager handshake failed: {resp.get('error', 'unknown error')}"
                )
            return self
        except Exception:
            sock.close()
            self.sock = None
            raise

    def _send(self, kind: Kind, body: dict) -> None:
        if not self.sock:
            raise ConnectionError("Manager socket is not connected")
        payload = control(kind, body)
        self.sock.sendall(frame(payload))

    def _recv(self) -> tuple[Kind, dict]:
        if not self.sock:
            raise ConnectionError("Manager socket is not connected")
        header = self._recv_exact(4)
        size = struct.unpack(">I", header)[0]
        data = self._recv_exact(size)
        return decode(data)

    def _recv_exact(self, count: int) -> bytes:
        buf = bytearray()
        while len(buf) < count:
            chunk = self.sock.recv(count - len(buf))
            if not chunk:
                raise ConnectionError("Manager socket closed prematurely")
            buf.extend(chunk)
        return bytes(buf)

    def request(self, operation: str, **kwargs) -> dict:
        req = build_management_request(operation, **kwargs)
        self._send(Kind.COMMAND, req)
        kind, resp = self._recv()
        if kind != Kind.STATUS:
            raise ProtocolError(f"Expected STATUS response, got {kind}")
        return validate_management_response(resp)

    def status(self) -> dict:
        """Query status non-owning."""
        return self.request("status")

    def claim(self, controller_id: str | None = None) -> str:
        """Claim exclusive controller ownership and return controller_id."""
        resp = self.request("claim", controller_id=controller_id)
        if not resp.get("accepted"):
            raise RuntimeError(resp.get("error", "Controller claim rejected"))
        self.controller_id = resp["controller_id"]
        return self.controller_id

    def release(self) -> bool:
        """Release controller ownership."""
        resp = self.request("release", controller_id=self.controller_id)
        if resp.get("accepted"):
            self.controller_id = None
            return True
        return False

    def stop_when_idle(self) -> bool:
        """Request the recorder to stop when idle."""
        resp = self.request("stop-when-idle")
        return bool(resp.get("accepted"))

    def close(self) -> None:
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None

    def __enter__(self) -> ManagerClient:
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()


def get_extension_package_dir() -> Path:
    """Resolve the package directory of the current extension regardless of repository namespace."""
    return Path(__file__).resolve().parent


def get_worker_payload_module() -> types.ModuleType:
    """Load worker_payload package-relatively without polluting Blender's global sys.path."""
    pkg_dir = get_extension_package_dir()
    payload_py = pkg_dir / "_worker" / "motionslate_recorder" / "worker_payload.py"

    # Fallback when running from unbundled development workspace
    if not payload_py.is_file():
        root = Path(__file__).resolve().parents[4]
        dev_payload = (
            root / "apps" / "recorder" / "src" / "motionslate_recorder" / "worker_payload.py"
        )
        if dev_payload.is_file():
            payload_py = dev_payload
        else:
            raise FileNotFoundError(
                f"Cannot locate worker_payload.py at {payload_py} or {dev_payload}"
            )

    spec = importlib.util.spec_from_file_location("_motionslate_worker_payload", str(payload_py))
    if not spec or not spec.loader:
        raise ImportError(f"Failed to load spec for {payload_py}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def stage_worker_payload(workers_base_dir: Path | None = None) -> Path:
    """Stage the worker payload from the installed extension into Application Support."""
    payload_mod = get_worker_payload_module()
    return payload_mod.stage_worker(get_extension_package_dir(), workers_base_dir=workers_base_dir)


def build_worker_command(
    staged_worker_dir: Path,
    captures_dir: Path | str,
    host: str = "127.0.0.1",
    phone_port: int = 9000,
    blender_port: int = 9001,
    service_dir: Path | str | None = None,
) -> list[str]:
    """Construct the subprocess argument array using Blender's bundled Python and isolated flags."""
    py_exe = sys.executable
    py_args = list(getattr(bpy.app, "python_args", ())) if bpy and hasattr(bpy, "app") else []
    bootstrap = staged_worker_dir / "_worker" / "bootstrap.py"

    if not bootstrap.is_file():
        raise FileNotFoundError(f"Worker bootstrap not found at {bootstrap}")

    cmd = (
        [py_exe]
        + py_args
        + [
            "-B",
            "-u",
            str(bootstrap),
            "--captures",
            str(captures_dir),
            "--host",
            str(host),
            "--phone-port",
            str(phone_port),
            "--blender-port",
            str(blender_port),
        ]
    )
    if service_dir:
        cmd.extend(["--service-dir", str(service_dir)])
    return cmd


def read_pairing_token(capture_root: Path | str) -> str:
    """Read the pairing token file securely with permission and symlink checks."""
    token_path = Path(capture_root).expanduser().resolve() / "pairing-token.txt"

    if token_path.is_symlink():
        raise ValueError(f"Pairing token at {token_path} must not be a symlink")
    if not token_path.is_file():
        raise FileNotFoundError(f"Pairing token file not found at {token_path}")

    st = token_path.stat()
    if hasattr(os, "getuid") and (st.st_mode & 0o077 != 0):
        raise ValueError(
            f"Insecure permissions on pairing token file: {oct(stat.S_IMODE(st.st_mode))}. "
            "Expected 0600 (user-only)."
        )
    token = token_path.read_text(encoding="utf-8").strip()
    if not token:
        raise ValueError(f"Pairing token file at {token_path} is empty")
    return token


class ServiceSupervisor:
    """Supervises recorder child worker and manages loopback controller ownership for Blender."""

    def __init__(self, service_dir: Path | None = None):
        self.service_dir = (
            Path(service_dir).expanduser().resolve() if service_dir else get_default_service_dir()
        )
        self.process: subprocess.Popen | None = None
        self.manager_client: ManagerClient | None = None
        self.controller_id: str | None = None
        self.readiness: dict | None = None
        self.status_snapshot: dict | None = None
        self.effective_capture_root: Path | None = None
        self.phone_port: int = 9000
        self.blender_port: int = 9001
        self.token: str | None = None
        self.manual_token: str | None = None
        self.state: str = "DISCONNECTED"
        self.last_error: str | None = None
        self.last_poll_time: float = 0.0

    @staticmethod
    def is_process_alive(pid: int) -> bool:
        """Check if a process with the given PID is currently running."""
        if hasattr(os, "kill"):
            try:
                os.kill(pid, 0)
                return True
            except OSError:
                return False
        return True

    def locate(self) -> bool:
        """Check if a compatible recorder service is already running."""
        if (
            self.state in ("LOCATED", "CONNECTED")
            and self.manager_client
            and self.manager_client.sock
        ):
            try:
                st = self.manager_client.status()
                if st.get("accepted"):
                    self.status_snapshot = st
                    return True
            except Exception:
                pass

        try:
            desc = read_readiness_descriptor(self.service_dir)
            pid = desc.get("pid")
            if pid and not self.is_process_alive(pid):
                return False

            port = desc.get("blender_port")
            if not port:
                return False

            token = read_management_token(self.service_dir)
            client = ManagerClient(port, token, timeout=1.0)
            client.connect()
            st = client.status()
            if not st.get("accepted"):
                client.close()
                return False

            self.readiness = desc
            self.status_snapshot = st
            self.manager_client = client
            self.blender_port = port
            self.phone_port = desc.get("phone_port", 9000)
            self.effective_capture_root = Path(desc.get("capture_root", "")).expanduser().resolve()
            self.state = "LOCATED"
            return True
        except Exception:
            return False

    def launch(
        self,
        captures_dir: Path | str,
        host: str = "127.0.0.1",
        phone_port: int = 9000,
        blender_port: int = 9001,
    ) -> None:
        """Stage worker payload and launch child recorder process."""
        staged_dir = stage_worker_payload()
        cmd = build_worker_command(
            staged_dir,
            captures_dir=captures_dir,
            host=host,
            phone_port=phone_port,
            blender_port=blender_port,
            service_dir=self.service_dir,
        )

        self.process = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            start_new_session=True,
            close_fds=True,
        )
        self.state = "STARTING"
        self.effective_capture_root = Path(captures_dir).expanduser().resolve()
        self.phone_port = phone_port
        self.blender_port = blender_port

    def wait_for_readiness(self, timeout: float = 10.0) -> bool:
        """Wait for the launched worker to publish readiness and accept status queries."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.process and self.process.poll() is not None:
                err = (
                    self.process.stderr.read().decode("utf-8", errors="replace")
                    if self.process.stderr
                    else ""
                )
                self.last_error = (
                    f"Recorder process exited ({self.process.returncode}): {err.strip()}"
                )
                self.state = "ERROR"
                return False

            if self.locate():
                return True
            time.sleep(0.05)

        self.last_error = f"Timed out waiting for recorder readiness after {timeout}s"
        self.state = "ERROR"
        return False

    def claim(self) -> str:
        """Claim controller ownership on the connected manager client."""
        if not self.manager_client:
            raise RuntimeError("Manager client not connected")
        cid = self.manager_client.claim(self.controller_id)
        self.controller_id = cid
        self.state = "CONNECTED"

        if self.manual_token:
            self.token = self.manual_token
        elif self.effective_capture_root:
            self.token = read_pairing_token(self.effective_capture_root)
        else:
            raise RuntimeError("Unknown capture root for pairing token")

        return self.controller_id

    def connect_service(
        self,
        captures_dir: Path | str,
        host: str = "127.0.0.1",
        phone_port: int = 9000,
        blender_port: int = 9001,
        manual_token: str | None = None,
        timeout: float = 10.0,
    ) -> tuple[int, str, str]:
        """High-level connection: locate or launch, claim, and return (port, controller_id, token)."""
        self.manual_token = manual_token.strip() if manual_token else None

        if not self.locate():
            self.launch(
                captures_dir=captures_dir,
                host=host,
                phone_port=phone_port,
                blender_port=blender_port,
            )
            if not self.wait_for_readiness(timeout=timeout):
                raise RuntimeError(self.last_error or "Failed to start recorder service")

        self.claim()
        return self.blender_port, self.controller_id, self.token

    def release(self) -> bool:
        """Release controller ownership."""
        if self.manager_client and self.controller_id:
            try:
                self.manager_client.release()
            except Exception:
                pass
            self.controller_id = None
            if self.state == "CONNECTED":
                self.state = "LOCATED"
            return True
        return False

    def stop_when_idle(self) -> bool:
        """Request worker to stop when idle."""
        if self.manager_client:
            try:
                return self.manager_client.stop_when_idle()
            except Exception:
                pass
        return False

    def disconnect(self) -> None:
        """Disconnect manager client and reset connection state."""
        self.release()
        if self.manager_client:
            self.manager_client.close()
            self.manager_client = None
        self.state = "DISCONNECTED"

    def tick(self, deadline: float | None = None) -> None:
        """Non-blocking periodic supervision folded into Blender timer."""
        if self.process and self.process.poll() is not None:
            if self.state == "CONNECTED":
                err = (
                    self.process.stderr.read().decode("utf-8", errors="replace")
                    if self.process.stderr
                    else ""
                )
                self.last_error = f"Recorder process terminated unexpectedly ({self.process.returncode}): {err.strip()}"
                self.state = "ERROR"
            self.process = None

        now = time.monotonic()
        if self.manager_client and self.state == "CONNECTED" and now - self.last_poll_time >= 2.0:
            self.last_poll_time = now
            try:
                self.status_snapshot = self.manager_client.status()
            except Exception as exc:
                self.last_error = str(exc)


_GLOBAL_SUPERVISOR: ServiceSupervisor | None = None


def get_service_supervisor(service_dir: Path | None = None) -> ServiceSupervisor:
    """Get the singleton ServiceSupervisor instance."""
    global _GLOBAL_SUPERVISOR
    if _GLOBAL_SUPERVISOR is None or (
        service_dir and _GLOBAL_SUPERVISOR.service_dir != Path(service_dir).expanduser().resolve()
    ):
        _GLOBAL_SUPERVISOR = ServiceSupervisor(service_dir=service_dir)
    return _GLOBAL_SUPERVISOR
