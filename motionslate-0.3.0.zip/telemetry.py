"""Small typed diagnostics carried outside immutable pose records."""

from .protocol import ProtocolError, finite, integer, uid


def validate_metrics(body):
    if (
        body.get("kind") != "CAPTURE_METRICS"
        or type(body.get("version")) is not int
        or body["version"] != 1
    ):
        raise ProtocolError("Unsupported capture metrics")
    result = {key: uid(body.get(key)) for key in ("session_id", "segment_id", "body_id")}
    result.update(kind="CAPTURE_METRICS", version=1)
    for key, high in [
        ("source_timestamp", 1e12),
        ("sample_hz", 1000),
        ("usable_hz", 1000),
        ("capture_ms", 10000),
        ("network_bytes", 2**24),
        ("network_age", 3600),
    ]:
        value = finite(body.get(key), key)
        if not 0 <= value <= high:
            raise ProtocolError("Capture metric outside range")
        result[key] = value
    if result["usable_hz"] > result["sample_hz"]:
        raise ProtocolError("Usable rate exceeds sample rate")
    result["tracked_joints"] = integer(body.get("tracked_joints"), 0, 256, "Tracked joints")
    for key in ("thermal", "video_format", "guidance"):
        value = body.get(key, "")
        if not isinstance(value, str) or len(value) > 160:
            raise ProtocolError("Invalid diagnostic label")
        result[key] = value
    floor = body.get("floor")
    if floor is not None:
        if not isinstance(floor, dict):
            raise ProtocolError("Invalid floor observation")
        height = finite(floor.get("height"), "floor height")
        if abs(height) > 1e5:
            raise ProtocolError("Invalid floor height")
        result["floor"] = dict(
            height=height,
            samples=integer(floor.get("samples"), 3, 100000, "Floor samples"),
            source="horizontal-plane",
        )
    else:
        result["floor"] = None
    return result
