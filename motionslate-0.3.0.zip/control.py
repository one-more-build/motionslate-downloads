"""Durable take coordinator. The phone owns performed boundaries."""

from __future__ import annotations
import json
from pathlib import Path
from .journal import atomic_json
from .protocol import ProtocolError, finite, integer, json_bytes, uid

COMMANDS = {
    "PREPARE_TAKE",
    "START_COUNTDOWN",
    "STOP_TAKE",
    "CANCEL_TAKE",
    "CALIBRATE_COUNTDOWN",
    "RECENTER",
    "QUERY_STATUS",
    "REQUEST_MISSING_RANGES",
}
TERMINAL = {"SOURCE_DURABLE", "CANCELLED", "INTERRUPTED"}


class Coordinator:
    def __init__(self, root):
        self.root = Path(root)
        self.path = self.root / "coordinator.json"
        self.root.mkdir(parents=True, exist_ok=True)
        self.state = (
            json.loads(self.path.read_text())
            if self.path.exists()
            else dict(active=None, requests={}, revision=0)
        )

    def save(self):
        self.state["revision"] += 1
        atomic_json(self.path, self.state)

    def command(self, body, role):
        request_id = uid(body.get("request_id"))
        name = body.get("command")
        if name not in COMMANDS or role not in {"phone", "blender"}:
            raise ProtocolError("Unknown command or role")
        fingerprint = json_bytes(body).decode()
        previous = self.state["requests"].get(request_id)
        if previous:
            if previous["fingerprint"] != fingerprint or previous["role"] != role:
                raise ProtocolError("Request ID reused with different command")
            return previous["result"], previous["dispatch"]
        args = body.get("args", {})
        if not isinstance(args, dict):
            raise ProtocolError("Command arguments must be an object")
        active = self.state["active"]
        dispatch = False
        result = dict(request_id=request_id, accepted=True, command=name)
        if name == "PREPARE_TAKE":
            take_id = uid(body.get("take_id"))
            if role != "blender":
                # Phone initiates the UI workflow, but Blender must snapshot its rig first.
                result["needs_blender_prepare"] = True
                dispatch = "blender"
            else:
                if active and active["phase"] not in TERMINAL:
                    raise ProtocolError("Another take is active; resolve it before preparing")
                integer(args.get("fps_numerator"), 1, 240000, "FPS numerator")
                integer(args.get("fps_denominator"), 1, 10000, "FPS denominator")
                integer(args.get("start_frame"), -1000000, 1000000, "Start frame")
                rate = args["fps_numerator"] / args["fps_denominator"]
                if not 1 <= rate <= 120:
                    raise ProtocolError("Output rate must be 1–120 fps")
                for field, low, high in [
                    ("countdown_seconds", 0, 60),
                    ("duration_seconds", 0.1, 3600),
                ]:
                    value = finite(args.get(field), field)
                    if not low <= value <= high:
                        raise ProtocolError(f"{field} outside limits")
                if not isinstance(args.get("name"), str) or not 1 <= len(args["name"]) <= 128:
                    raise ProtocolError("Invalid take name")
                if not isinstance(args.get("snapshot"), dict) or not args["snapshot"]:
                    raise ProtocolError("Blender rig/calibration snapshot is required")
                active = dict(
                    take_id=take_id,
                    phase="PREPARING",
                    blender_ready=True,
                    phone_ready=False,
                    args=args,
                )
                self.state["active"] = active
                folder = self.root / take_id
                folder.mkdir(exist_ok=True)
                atomic_json(folder / "processing.json", args)
                dispatch = "phone"
        elif name in {"START_COUNTDOWN", "STOP_TAKE", "CANCEL_TAKE"}:
            take_id = uid(body.get("take_id"))
            if not active or active["take_id"] != take_id:
                raise ProtocolError("Take is not active")
            if name == "START_COUNTDOWN":
                if (
                    active["phase"] != "PREPARED"
                    or not active["phone_ready"]
                    or not active["blender_ready"]
                ):
                    raise ProtocolError("Both destinations must prepare before countdown")
                active["phase"] = "COUNTDOWN_REQUESTED"
            elif name == "STOP_TAKE":
                if active["phase"] not in {"COUNTDOWN_REQUESTED", "RECORDING", "STOP_REQUESTED"}:
                    raise ProtocolError("Take is not recording")
                active["phase"] = "STOP_REQUESTED"
            else:
                if active["phase"] in TERMINAL:
                    raise ProtocolError("Cannot cancel finalized source")
                active["phase"] = "CANCEL_REQUESTED"
            dispatch = "phone"
        elif name == "RECENTER":
            if active and active["phase"] not in TERMINAL:
                raise ProtocolError("Cannot recenter during a take")
            dispatch = "blender"
        elif name == "CALIBRATE_COUNTDOWN":
            if active and active["phase"] not in TERMINAL:
                raise ProtocolError("Cannot calibrate during a take")
            seconds = finite(args.get("countdown_seconds", 5), "Countdown")
            if not 0 <= seconds <= 60:
                raise ProtocolError("Countdown outside limits")
            dispatch = "phone" if role == "blender" else "blender"
        elif name == "REQUEST_MISSING_RANGES":
            uid(body.get("take_id"))
            dispatch = "phone"
        result["active"] = active.copy() if active else None
        self.state["requests"][request_id] = dict(
            fingerprint=fingerprint, role=role, result=result, dispatch=dispatch
        )
        self.save()
        return result, dispatch

    def source_event(self, event):
        active = self.state["active"]
        if not active or active["take_id"] != event.get("take_id"):
            return
        name = event.get("event")
        phase = active["phase"]
        # Replayed old events cannot regress the durable coordinator.
        if name == "TAKE_PREPARED" and phase == "PREPARING":
            active.update(phone_ready=True, phase="PREPARED")
        elif name == "TAKE_STARTED" and phase in {
            "PREPARED",
            "COUNTDOWN_REQUESTED",
            "STOP_REQUESTED",
        }:
            if phase != "STOP_REQUESTED":
                active["phase"] = "RECORDING"
            active["t0"] = event["t0"]
        elif name == "TAKE_ENDED" and phase not in TERMINAL:
            active.update(phase="RECOVERY_REQUIRED", t_stop=event["t_stop"])
        elif name == "TAKE_CANCELLED" and phase not in TERMINAL:
            active["phase"] = "CANCELLED"
        elif name == "SEGMENT_ENDED" and phase not in TERMINAL:
            active["phase"] = "INTERRUPTED"
        else:
            return
        self.save()

    def finalized(self, take_id):
        active = self.state["active"]
        if active and active["take_id"] == take_id:
            active["phase"] = "SOURCE_DURABLE"
            self.save()

    def rejected(self, request_id, reason):
        item = self.state["requests"].get(request_id)
        active = self.state["active"]
        if not item or not active or active["phase"] != "PREPARING":
            return
        command = json.loads(item["fingerprint"])
        if (
            item["dispatch"] == "phone"
            and command.get("command") == "PREPARE_TAKE"
            and command.get("take_id") == active["take_id"]
        ):
            active.update(phase="INTERRUPTED", error=str(reason))
            self.save()

    def interrupt_locally(self, reason: str = "Abandoned or interrupted locally") -> bool:
        active = self.state["active"]
        if active and active["phase"] not in TERMINAL:
            active.update(phase="INTERRUPTED", error=str(reason), local_interruption=True)
            self.save()
            return True
        return False

    def pending_for_phone(self):
        active = self.state["active"]
        if not active or active["phase"] in TERMINAL:
            return []
        result = []
        for item in self.state["requests"].values():
            body = json.loads(item["fingerprint"])
            if item["dispatch"] == "phone" and body.get("take_id") == active["take_id"]:
                result.append(body)
        return result
