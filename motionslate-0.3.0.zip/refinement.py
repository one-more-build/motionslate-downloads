"""Resumable deterministic refinement of verified source with direct Action replacement.

At most one short temporal window and one 120-frame key-reduction block are held
in memory. Every scan, solve, reduction comparison and curve update yields.
"""

from collections import deque
import copy
import json
import math
from mathutils import Matrix, Quaternion, Vector
from .protocol import Kind, ProtocolError, decode, uid
from .journal import ReadOnlySource
from .motion import MotionSolver, angle
from .quality import configuration
from .animation import ActionWriter, blend_basis, resolve_source_path


def smooth_window(window, center, width=0.06):
    t, basis, _ = window[center]
    result = {}
    for name, ma in basis.items():
        location, q, scale = ma.decompose()
        total = 0.0
        rotation = Vector((0, 0, 0, 0))
        position = Vector((0, 0, 0))
        for ti, other, _ in window:
            if abs(ti - t) > width:
                continue
            loc, qi, _ = other[name].decompose()
            if q.dot(qi) < 0:
                qi.negate()
            # Bilateral temporal weights suppress noise but preserve distinct
            # fast poses. Future samples remove the causal-filter phase delay.
            weight = math.exp(
                -0.5 * ((ti - t) / (0.5 * width)) ** 2
                - 0.5 * (angle(q, qi) / 0.12) ** 2
                - 0.5 * ((loc - location).length / 0.025) ** 2
            )
            rotation += Vector(tuple(qi)) * weight
            position += loc * weight
            total += weight
        result[name] = Matrix.LocRotScale(
            position / total, Quaternion(rotation).normalized(), scale
        )
    return result


def reduce_block(rows, solver, angular_error, position_error):
    """Yield during a shared-frame RDP reduction, with FK position error checks."""
    if not rows:
        return []
    keep = {0, len(rows) - 1}
    for i in range(1, len(rows) - 1):
        if rows[i][2] != rows[i - 1][2] or rows[i][2] != rows[i + 1][2]:
            keep.update((i - 1, i, i + 1))
        for name in solver.snapshot["mapping"].values():
            before = rows[i - 1][1][name].translation
            now = rows[i][1][name].translation
            after = rows[i + 1][1][name].translation
            if name == solver.raw.root_target and any(
                (now[j] - before[j]) * (after[j] - now[j]) < 0
                and max(abs(now[j] - before[j]), abs(after[j] - now[j])) > 1e-5
                for j in range(3)
            ):
                keep.add(i)
            qa = rows[i - 1][1][name].to_quaternion()
            qb = rows[i][1][name].to_quaternion()
            qc = rows[i + 1][1][name].to_quaternion()
            if qa.dot(qb) < 0:
                qa.negate()
            if qc.dot(qb) < 0:
                qc.negate()
            if any(
                (qb[j] - qa[j]) * (qc[j] - qb[j]) < 0
                and max(abs(qb[j] - qa[j]), abs(qc[j] - qb[j])) > 1e-4
                for j in range(4)
            ):
                keep.add(i)
        yield
    worlds = []
    for _, basis, _ in rows:
        worlds.append(solver.world_matrices(basis))
        yield
    anchors = sorted(keep)
    stack = list(zip(anchors, anchors[1:]))
    while stack:
        a, b = stack.pop()
        worst = 1.0
        split = None
        for i in range(a + 1, b):
            f = (rows[i][0] - rows[a][0]) / (rows[b][0] - rows[a][0])
            estimated = blend_basis(rows[a][1], rows[b][1], f)
            world = solver.world_matrices(estimated)
            error = max(
                max(
                    angle(estimated[n].to_quaternion(), rows[i][1][n].to_quaternion())
                    / angular_error,
                    (world[n].translation - worlds[i][n].translation).length / position_error,
                    (
                        (world[n] @ Vector((0, solver.rig.pose.bones[n].length, 0)))
                        - (worlds[i][n] @ Vector((0, solver.rig.pose.bones[n].length, 0)))
                    ).length
                    / position_error,
                )
                for n in solver.snapshot["mapping"].values()
            )
            if error > worst:
                worst = error
                split = i
            yield
        if split is not None:
            keep.add(split)
            stack.extend(((a, split), (split, b)))
    return [rows[i] for i in sorted(keep)]


class RefinementJob:
    def __init__(
        self, rig, action, capture_directory, angular_error=math.radians(0.25), position_error=0.005
    ):
        self.rig = rig
        self.original = action
        self.writer = None
        self.progress = "Verifying source"
        self.done = False
        self.angular_error = angular_error
        self.position_error = position_error
        if not action or action.get("abm_state") != "READY_IN_SCENE":
            raise ProtocolError("Select a completed verified take")
        self.take = uid(action.get("abm_take_id"))
        self.directory = resolve_source_path(action, rig, capture_directory)
        if not self.directory or not self.directory.exists():
            raise ProtocolError("Capture source directory not found; locate source before refining")
        self.snapshot = json.loads(action["abm_processing"])
        self.source = None
        self.iterator = self.run()

    def cancel(self):
        self.iterator.close()

    def run(self):
        success = False
        self.source = ReadOnlySource(
            self.directory,
            take_id=self.take,
            expected_hash=self.original.get("abm_source_hash"),
        )
        try:
            yield from self.source.verify_iter()
            manifest = self.source.manifest
            snapshot = copy.deepcopy(self.snapshot)
            # Temporal refinement replaces causal smoothing for the completed Action.
            settings = dict(snapshot.get("processing", {}), smoothing=False)
            snapshot["processing"] = configuration(settings)
            raw_snapshot = copy.deepcopy(snapshot)
            raw_snapshot["processing"]["foot_lock"] = False
            source_solver = MotionSolver(self.rig, raw_snapshot)
            contact_solver = MotionSolver(self.rig, snapshot)
            self.writer = ActionWriter(
                self.rig,
                snapshot,
                self.take,
                self.original.name + " refined",
                self.original["abm_start_frame"],
                self.original["abm_fps_numerator"],
                self.original["abm_fps_denominator"],
            )
            self.writer.start(manifest["t0"], manifest["t_stop"])
            self.writer.action["abm_refinement"] = json.dumps(
                dict(
                    version=1,
                    window_seconds=0.06,
                    angular_error=self.angular_error,
                    position_error=self.position_error,
                    original_action=self.original.name,
                )
            )
            self.writer.action["abm_source_path"] = str(self.directory)
            window = deque()
            next_center = 0
            previous = None
            last_good = None
            block = []
            frame_index = 0
            retained = 0
            fps = self.writer.fps
            first = manifest["t0"]
            stop = manifest["t_stop"]

            def emit(t, basis, pose, flags, reliability):
                nonlocal previous, frame_index, block, retained
                dt = t - previous[0] if previous else 1 / 60
                if dt > 0.25:
                    contact_solver.reset()
                if snapshot["processing"]["foot_lock"] and "tracking_gap" not in flags:
                    basis = contact_solver.correct_feet(basis, pose, max(dt, 1e-6), reliability)
                else:
                    contact_solver.contacts.clear()
                    contact_solver.previous_feet.clear()
                    contact_solver.last_contact_states.clear()
                labels = (tuple(sorted(contact_solver.last_contact_states.items())), tuple(flags))
                current = (t, basis, labels)
                if previous:
                    while (
                        first + frame_index / fps <= t + 1e-9
                        and first + frame_index / fps < stop - 1e-9
                    ):
                        sample_time = first + frame_index / fps
                        if sample_time < previous[0] - 1e-9:
                            raise ProtocolError("Missing refinement boundary sample")
                        if t - previous[0] > 0.25:
                            raise ProtocolError("Source gap too long to refine automatically")
                        f = (sample_time - previous[0]) / max(t - previous[0], 1e-9)
                        row = (frame_index, blend_basis(previous[1], basis, f), labels)
                        block.append(row)
                        frame_index += 1
                        if flags:
                            self.writer.gaps.append(
                                (
                                    frame_index - 1,
                                    "refined_short_gap"
                                    if "tracking_gap" in flags
                                    else "joint_recovery",
                                )
                            )
                            joints = [(name, "recovered") for name in flags]
                            intervals = self.writer.quality_intervals
                            if (
                                intervals
                                and intervals[-1]["joints"] == joints
                                and intervals[-1]["end"] == frame_index - 2
                            ):
                                intervals[-1]["end"] = frame_index - 1
                            else:
                                intervals.append(
                                    dict(start=frame_index - 1, end=frame_index - 1, joints=joints)
                                )
                        if len(block) >= 120:
                            selected = yield from reduce_block(
                                block, contact_solver, self.angular_error, self.position_error
                            )
                            for index, value, _ in selected:
                                self.writer.write_basis(value, self.writer.start_frame + index)
                                retained += 1
                                yield
                            block = [block[-1]]
                            self.writer.flush()
                        yield
                previous = current

            for payload in self.source.records():
                kind, pose = decode(payload)
                if kind != Kind.POSE:
                    yield
                    continue
                self.progress = f"Refining {max(0.0, pose.timestamp - first):.1f} seconds"
                if source_solver.accepts(pose):
                    basis = source_solver.solve(pose)
                    last_good = (pose.timestamp, basis)
                    flags = tuple(source_solver.quality_flags)
                elif last_good and pose.timestamp - last_good[0] <= 0.25:
                    basis = source_solver.hold(pose.timestamp)
                    flags = ("tracking_gap",)
                else:
                    raise ProtocolError("Source tracking gap exceeds refinement hold limit")
                if window and pose.timestamp - window[-1][0] > 0.25:
                    raise ProtocolError("Source gap exceeds refinement limit")
                window.append(
                    (pose.timestamp, basis, pose, flags, dict(source_solver.joint_reliability))
                )
                # A short lookahead supplies future evidence; no full-take pose cache.
                while next_center < len(window) and pose.timestamp - window[next_center][0] >= 0.06:
                    center = list(window)
                    t, _, p, flags, reliability = center[next_center]
                    smooth = smooth_window([(a, b, c) for a, b, c, _, _ in center], next_center)
                    yield from emit(t, smooth, p, flags, reliability)
                    next_center += 1
                    while (
                        0 < next_center < len(window)
                        and window[next_center][0] - window[0][0] > 0.06
                    ):
                        window.popleft()
                        next_center -= 1
                yield
            while next_center < len(window):
                center = list(window)
                t, _, p, flags, reliability = center[next_center]
                yield from emit(
                    t,
                    smooth_window([(a, b, c) for a, b, c, _, _ in center], next_center),
                    p,
                    flags,
                    reliability,
                )
                next_center += 1
                yield
            if block:
                selected = yield from reduce_block(
                    block, contact_solver, self.angular_error, self.position_error
                )
                for index, value, _ in selected:
                    self.writer.write_basis(value, self.writer.start_frame + index)
                    retained += 1
                    yield
            self.writer.frames = frame_index
            yield from self.writer.finalize_iter(manifest["source_hash"])
            self.writer.action["abm_rejected_spikes"] = source_solver.recovery.rejected
            self.writer.action["abm_retained_frames"] = retained
            self.writer.action["abm_refined"] = True
            name = self.original.name
            self.original.user_remap(self.writer.action)
            __import__("bpy").data.actions.remove(self.original)
            self.writer.action.name = name
            self.progress = f"Refined {frame_index} frames; {retained} key poses"
            self.done = True
            success = True
        finally:
            if not success and self.writer:
                self.writer.restore(remove=True)
            if self.source:
                self.source.close()
