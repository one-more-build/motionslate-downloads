"""Service management, exclusivity locks, credential validation, and readiness publication.

Enforces:
- One managed recorder per macOS user (ServiceLock).
- One recorder per canonical capture root (RootLock).
- Transactional startup: listeners reserved before mutable state/coordinator is opened.
- Safe token handling: rejects insecure permissions and symlinks; handles creation races.
- Secret-free readiness descriptor publication (readiness.json).
- Live status snapshotting.
"""

from __future__ import annotations
import asyncio
import contextlib
from dataclasses import asdict, dataclass
import fcntl
import json
import os
from pathlib import Path
import secrets
import ssl
import stat
import time
from typing import Callable
import uuid

from motionslate_recorder.bridge import Recorder
from motionslate_recorder.security import (
    PairingPayload,
    create_server_ssl_context,
    load_or_create_certificate,
    save_pairing_file,
)

STARTUP_DEADLINE: float = 20.0
OWNERLESS_IDLE_GRACE: float = 60.0
OWNERLESS_PROGRESS_THRESHOLD: float = 120.0


class LifecycleSupervisor:
    """Supervises managed recorder lifecycle according to §3.3.

    Shutdown policies owned by managed.py:
    1. Startup deadline: from start() to readiness publication.
    2. Ownerless idle grace (60s): If no controller is claimed and recorder is idle,
       shut down cleanly after the grace period.
    3. Ownerless progress threshold (120s): If a take or archival is active without an
       owner and no progress occurs for 120s, record a local interruption via Coordinator
       and shut down.
    4. Stop when idle: When requested, wait for ongoing takes/archival to complete, then shut down.
    """

    def __init__(
        self,
        recorder: Recorder,
        clock: Callable[[], float] = time.monotonic,
        ownerless_idle_grace: float = OWNERLESS_IDLE_GRACE,
        ownerless_progress_threshold: float = OWNERLESS_PROGRESS_THRESHOLD,
    ):
        self.recorder = recorder
        self.clock = clock
        self.ownerless_idle_grace = ownerless_idle_grace
        self.ownerless_progress_threshold = ownerless_progress_threshold
        self.ownerless_idle_started_at: float | None = (
            self.clock() if self.recorder.is_idle() else None
        )

    def check_policy(self) -> str | None:
        """Check lifecycle state and return a shutdown action code, or None if continuing."""
        if self.recorder.closed:
            return None

        # 1. Stop when idle requested
        if self.recorder.stop_when_idle_requested and self.recorder.is_idle():
            return "STOP_WHEN_IDLE"

        # 2. Check owner status
        has_owner = (
            self.recorder.active_controller_id is not None
            and self.recorder.active_manager_peer is not None
        )

        now = self.clock()

        if has_owner:
            self.ownerless_idle_started_at = None
            return None

        # Ownerless state
        if self.recorder.is_idle():
            if self.ownerless_idle_started_at is None:
                self.ownerless_idle_started_at = now
            elif now - self.ownerless_idle_started_at >= self.ownerless_idle_grace:
                return "OWNERLESS_IDLE_TIMEOUT"
        else:
            # Active take or archival in progress without owner
            self.ownerless_idle_started_at = None
            if now - self.recorder.last_progress_time >= self.ownerless_progress_threshold:
                self.recorder.interrupt_locally("Ownerless take abandoned without progress")
                return "OWNERLESS_PROGRESS_TIMEOUT"

        return None


class ProcessConflictError(RuntimeError):
    """Raised when another MotionSlate recorder service is already running for this user."""


class RootConflictError(RuntimeError):
    """Raised when the requested capture root is already locked by another process."""


class InsecureTokenError(ValueError):
    """Raised when the pairing token file has insecure permissions or invalid format."""


def get_default_service_dir() -> Path:
    """Return the default Application Support directory for MotionSlate service state."""
    return Path.home() / "Library" / "Application Support" / "MotionSlate"


class FileLock:
    """Non-blocking advisory file lock held for the lifetime of the process/resource."""

    def __init__(self, lock_path: Path, conflict_exc_cls: type[Exception], conflict_msg: str):
        self.lock_path = Path(lock_path)
        self.conflict_exc_cls = conflict_exc_cls
        self.conflict_msg = conflict_msg
        self.fd: int | None = None

    def acquire(self) -> None:
        if self.fd is not None:
            return
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(self.lock_path, os.O_RDWR | os.O_CREAT, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (BlockingIOError, OSError) as exc:
            os.close(fd)
            raise self.conflict_exc_cls(self.conflict_msg) from exc

        # Record diagnostic PID into the lock file
        try:
            os.ftruncate(fd, 0)
            os.lseek(fd, 0, os.SEEK_SET)
            os.write(fd, f"{os.getpid()}\n".encode("utf-8"))
        except OSError:
            pass

        self.fd = fd

    def release(self) -> None:
        if self.fd is None:
            return
        fd = self.fd
        self.fd = None
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        except OSError:
            pass
        finally:
            os.close(fd)

    def __enter__(self) -> FileLock:
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.release()


def create_service_lock(service_dir: Path | None = None) -> FileLock:
    """Create a non-blocking lock for the user-wide MotionSlate service."""
    base = service_dir or get_default_service_dir()
    return FileLock(
        base / "service.lock",
        ProcessConflictError,
        f"Another MotionSlate recorder service is already running (locked at {base / 'service.lock'}).",
    )


def create_root_lock(capture_root: Path | str) -> FileLock:
    """Create a non-blocking lock on the canonical capture root directory."""
    canonical = Path(capture_root).expanduser().resolve()
    return FileLock(
        canonical / ".lock",
        RootConflictError,
        f"Capture root '{canonical}' is already locked by another process.",
    )


def load_or_create_token_file(token_path: Path | str, token_name: str = "token") -> str:
    """Load an existing token file or create a new one securely.

    Enforces:
    - Token file must not be a symlink.
    - Permissions must be secure (no group/other read or write on POSIX, e.g. 0o600).
    - Concurrent creation races (FileExistsError) fall back cleanly to reading the created token.
    """
    token_path = Path(token_path).expanduser()

    if token_path.is_symlink():
        raise InsecureTokenError(f"{token_name.capitalize()} at {token_path} must not be a symlink")

    if token_path.exists():
        st = token_path.stat()
        # On POSIX, ensure group and other have no permissions (st_mode & 0o077 == 0)
        if hasattr(os, "getuid") and (st.st_mode & 0o077 != 0):
            raise InsecureTokenError(
                f"Insecure permissions on {token_name} file: {oct(stat.S_IMODE(st.st_mode))}. "
                "Expected 0600 (user-only)."
            )
        token = token_path.read_text(encoding="utf-8").strip()
        if not token:
            raise InsecureTokenError(f"{token_name.capitalize()} file at {token_path} is empty")
        return token

    # Create new token file atomically with 0o600
    token_path.parent.mkdir(parents=True, exist_ok=True)
    new_token = secrets.token_urlsafe(24)

    try:
        fd = os.open(
            token_path,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL,
            0o600,
        )
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(new_token + "\n")
        return new_token
    except FileExistsError:
        # Concurrent creation race: another process just created it
        if token_path.is_symlink():
            raise InsecureTokenError(
                f"{token_name.capitalize()} at {token_path} must not be a symlink"
            )
        st = token_path.stat()
        if hasattr(os, "getuid") and (st.st_mode & 0o077 != 0):
            raise InsecureTokenError(
                f"Insecure permissions on {token_name} file: {oct(stat.S_IMODE(st.st_mode))}. "
                "Expected 0600."
            )
        token = token_path.read_text(encoding="utf-8").strip()
        if not token:
            raise InsecureTokenError(f"{token_name.capitalize()} file at {token_path} is empty")
        return token


def load_or_create_pairing_token(capture_root: Path | str) -> str:
    """Load or create the phone pairing token in <capture_root>/pairing-token.txt."""
    canonical_root = Path(capture_root).expanduser().resolve()
    return load_or_create_token_file(
        canonical_root / "pairing-token.txt", token_name="pairing token"
    )


def load_or_create_management_token(service_dir: Path | str) -> str:
    """Load or create the management token in <service_dir>/management-token.txt."""
    canonical_service_dir = Path(service_dir).expanduser().resolve()
    return load_or_create_token_file(
        canonical_service_dir / "management-token.txt", token_name="management token"
    )


def load_or_create_token(root: Path | str) -> str:
    """Backward-compatible alias for load_or_create_pairing_token."""
    return load_or_create_pairing_token(root)


@dataclass(frozen=True)
class ReadinessDescriptor:
    schema: str
    instance_id: str
    payload_hash: str | None
    management_version: str
    capture_root: str
    phone_port: int
    blender_port: int
    pid: int
    fingerprint: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def publish_readiness(service_dir: Path, descriptor: ReadinessDescriptor) -> Path:
    """Write the secret-free readiness descriptor atomically via tempfile + os.replace."""
    service_dir.mkdir(parents=True, exist_ok=True)
    target = service_dir / "readiness.json"
    temp_target = service_dir / f".readiness.{uuid.uuid4().hex}.tmp"

    data = json.dumps(descriptor.to_dict(), indent=2).encode("utf-8") + b"\n"
    temp_target.write_bytes(data)
    os.replace(temp_target, target)
    return target


def remove_readiness(service_dir: Path) -> None:
    """Unlink the readiness descriptor upon clean shutdown."""
    target = service_dir / "readiness.json"
    try:
        target.unlink()
    except FileNotFoundError:
        pass


class ManagedService:
    """Orchestrates transactional startup, exclusivity, and lifecycle of the recorder.

    Lifecycle contract:
    1. Acquire user service lock.
    2. Acquire capture root lock on canonical path.
    3. Validate and load or create pairing token.
    4. Start Recorder (which reserves both TCP listeners before opening coordinator state).
    5. Publish secret-free readiness descriptor.
    6. On error at any step, unwind all acquired resources in reverse order.
    """

    def __init__(
        self,
        captures: Path | str,
        host: str = "0.0.0.0",
        phone_port: int = 9000,
        blender_port: int = 9001,
        service_dir: Path | None = None,
        payload_hash: str | None = None,
        clock: Callable[[], float] = time.monotonic,
        startup_deadline: float = STARTUP_DEADLINE,
        ownerless_idle_grace: float = OWNERLESS_IDLE_GRACE,
        ownerless_progress_threshold: float = OWNERLESS_PROGRESS_THRESHOLD,
    ):
        self.canonical_root = Path(captures).expanduser().resolve()
        self.host = host
        self.phone_port = phone_port
        self.blender_port = blender_port
        self.service_dir = (
            Path(service_dir).expanduser().resolve() if service_dir else get_default_service_dir()
        )
        self.payload_hash = payload_hash
        self.instance_id = str(uuid.uuid4())
        self.clock = clock
        self.startup_deadline = startup_deadline
        self.ownerless_idle_grace = ownerless_idle_grace
        self.ownerless_progress_threshold = ownerless_progress_threshold

        self.service_lock: FileLock | None = None
        self.root_lock: FileLock | None = None
        self.recorder: Recorder | None = None
        self.readiness_path: Path | None = None
        self.token: str | None = None
        self.management_token: str | None = None
        self.cert_path: Path | None = None
        self.key_path: Path | None = None
        self.fingerprint: str | None = None
        self.ssl_context: ssl.SSLContext | None = None
        self.pairing_payload: str | None = None
        self.supervisor: LifecycleSupervisor | None = None
        self._supervision_task: asyncio.Task | None = None
        self.stopped = asyncio.Event()
        self.closed = False

    async def _supervision_loop(self) -> None:
        try:
            while not self.closed:
                action = self.supervisor.check_policy() if self.supervisor else None
                if action:
                    await self.close()
                    break
                await asyncio.sleep(0.5)
        except asyncio.CancelledError:
            pass

    async def step_supervision(self) -> str | None:
        """Step supervision policy check once (used for deterministic testing)."""
        if not self.supervisor:
            return None
        action = self.supervisor.check_policy()
        if action:
            await self.close()
        return action

    async def start(self) -> ManagedService:
        start_time = self.clock()
        # Step 1: User-service lock
        service_lock = create_service_lock(self.service_dir)
        service_lock.acquire()
        self.service_lock = service_lock

        try:
            # Step 2: Canonical capture-root lock
            root_lock = create_root_lock(self.canonical_root)
            root_lock.acquire()
            self.root_lock = root_lock

            # Step 3: Validate and load / create pairing token & management token
            self.token = load_or_create_pairing_token(self.canonical_root)
            self.management_token = load_or_create_management_token(self.service_dir)

            # Step 3b: Load or create TLS certificate and SSL context
            cert_dir = self.service_dir / "security"
            self.cert_path, self.key_path, self.fingerprint = load_or_create_certificate(cert_dir)
            self.ssl_context = create_server_ssl_context(self.cert_path, self.key_path)

            # Step 4: Reserve listeners and start Recorder in managed mode
            self.recorder = Recorder(
                self.canonical_root,
                self.token,
                host=self.host,
                phone_port=self.phone_port,
                blender_port=self.blender_port,
                management_token=self.management_token,
                managed=True,
                clock=self.clock,
                ssl_context=self.ssl_context,
            )
            await self.recorder.start()

            # Generate and securely save versioned pairing payload
            self.pairing_payload = PairingPayload.encode(
                endpoint=f"{self.host}:{self.recorder.phone_port}",
                recorder_id=self.instance_id,
                fingerprint=self.fingerprint,
                token=self.token,
            )
            save_pairing_file(self.canonical_root / "pairing.txt", self.pairing_payload)

            if self.clock() - start_time > self.startup_deadline:
                raise TimeoutError(f"Startup exceeded deadline of {self.startup_deadline}s")

            # Step 5: Publish secret-free readiness descriptor
            descriptor = ReadinessDescriptor(
                schema="motionslate-readiness-v1",
                instance_id=self.instance_id,
                payload_hash=self.payload_hash,
                management_version="managed-recorder-v1",
                capture_root=str(self.canonical_root),
                phone_port=self.recorder.phone_port,
                blender_port=self.recorder.blender_port,
                pid=os.getpid(),
                fingerprint=self.fingerprint,
            )
            self.readiness_path = publish_readiness(self.service_dir, descriptor)

            # Step 6: Initialize supervisor and start supervision task
            self.supervisor = LifecycleSupervisor(
                self.recorder,
                clock=self.clock,
                ownerless_idle_grace=self.ownerless_idle_grace,
                ownerless_progress_threshold=self.ownerless_progress_threshold,
            )
            self._supervision_task = asyncio.create_task(self._supervision_loop())
            return self

        except Exception:
            # Unwind in reverse order
            if self._supervision_task:
                self._supervision_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._supervision_task
                self._supervision_task = None
            if self.readiness_path:
                remove_readiness(self.service_dir)
                self.readiness_path = None
            if self.recorder:
                await self.recorder.close()
                self.recorder = None
            if self.root_lock:
                self.root_lock.release()
                self.root_lock = None
            if self.service_lock:
                self.service_lock.release()
                self.service_lock = None
            raise

    async def close(self) -> None:
        if self.closed:
            return
        self.closed = True

        # 0. Cancel supervision task
        if self._supervision_task:
            self._supervision_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._supervision_task
            self._supervision_task = None

        # 1. Remove readiness descriptor
        if self.readiness_path:
            remove_readiness(self.service_dir)
            self.readiness_path = None

        # 2. Close recorder
        if self.recorder:
            await self.recorder.close()
            self.recorder = None

        # 3. Release root lock
        if self.root_lock:
            self.root_lock.release()
            self.root_lock = None

        # 4. Release service lock
        if self.service_lock:
            self.service_lock.release()
            self.service_lock = None

        self.stopped.set()

    def status_snapshot(self) -> dict:
        """Return a live operational status snapshot of the managed service."""
        base = self.recorder.status_snapshot() if self.recorder else {}
        return {
            **base,
            "instance_id": self.instance_id,
            "service_dir": str(self.service_dir),
            "payload_hash": self.payload_hash,
            "management_version": "managed-recorder-v1",
            "fingerprint": self.fingerprint,
            "ownerless_idle_started_at": (
                self.supervisor.ownerless_idle_started_at if self.supervisor else None
            ),
        }
