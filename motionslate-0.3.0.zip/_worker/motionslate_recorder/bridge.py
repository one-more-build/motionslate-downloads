"""Independent local recorder. No bpy imports and no received code execution."""

from __future__ import annotations
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import contextlib
import hmac
import json
import os
from pathlib import Path
import signal
import time
import uuid

from motionslate.protocol import (
    Framer,
    Kind,
    ProtocolError,
    Schema,
    ZERO,
    control,
    decode,
    frame,
    uid,
)
from motionslate.service_protocol import (
    MANAGEMENT_OPERATIONS,
    MANAGEMENT_PROTOCOL,
    MANAGEMENT_ROLE,
    build_management_response,
    validate_management_hello,
    validate_management_request,
)
from motionslate.journal import TakeStore
from motionslate.control import Coordinator
from motionslate.telemetry import validate_metrics


class Peer:
    def __init__(self, writer, role):
        self.writer = writer
        self.role = role
        self.lock = asyncio.Lock()
        self.session_id = None
        self.preview_credit = asyncio.Event()
        self.preview_credit.set()
        self.preview_key = None

    async def send(self, payload):
        async with self.lock:
            self.writer.write(frame(payload))
            await asyncio.wait_for(self.writer.drain(), 2)


class Recorder:
    def __init__(
        self,
        root,
        token,
        host="0.0.0.0",
        phone_port=9000,
        blender_port=9001,
        management_token=None,
        managed=False,
        clock=time.monotonic,
        ssl_context=None,
    ):
        self.root = Path(root).expanduser().resolve()
        self.token = token
        self.management_token = management_token
        self.managed = managed
        self.clock = clock
        self.ssl_context = ssl_context
        self.last_progress_time = self.clock()
        self.stopped = asyncio.Event()
        self.host, self.phone_port, self.blender_port = host, phone_port, blender_port
        self.pool = None
        self.coordinator = None
        self.stores = {}
        self.schemas = {}
        self.schema_payloads = {}
        self.peers = {}
        self.active_controller_id = None
        self.active_manager_peer = None
        self.manager_peers = set()
        self.stop_when_idle_requested = False
        self.latest = None
        self.latest_received = None
        self.servers = []
        self.connection_limit = asyncio.Semaphore(8)
        self.closed = False
        self.client_tasks = set()
        self.archive_queue = asyncio.Queue(maxsize=256)
        self.archive_bytes = 0
        self.archive_error = None
        self.archive_task = None
        self.preview_tasks = set()
        self.metrics = None
        self.metrics_received = 0.0

    async def archive_poses(self):
        while True:
            peer, body, payload = await self.archive_queue.get()
            try:
                if self.archive_error:
                    continue

                def ingest():
                    store = self.store(body.take_id)
                    store.append(self.schema_payloads[body.schema_id], sync=False)
                    store.append(payload)
                    return store.status() if body.sequence % 15 == 0 else None

                status = await self.disk(ingest)
                self.last_progress_time = self.clock()
                if status and not peer.writer.is_closing():
                    with contextlib.suppress(OSError, ConnectionError, asyncio.TimeoutError):
                        await peer.send(control(Kind.STATUS, status))
            except (ProtocolError, OSError, ConnectionError, asyncio.TimeoutError) as exc:
                self.archive_error = str(exc)
                await self.send_role(
                    "phone", control(Kind.STATUS, dict(error=str(exc), accepted=False))
                )
                await self.send_role(
                    "blender", control(Kind.STATUS, dict(error=str(exc), accepted=False))
                )
            finally:
                self.archive_bytes -= len(payload)
                self.archive_queue.task_done()

    async def preview_stream(self, peer):
        schema_id = None
        sent_key = None
        last_send = 0.0
        try:
            while not self.closed and self.peers.get("preview") is peer:
                await asyncio.wait_for(peer.preview_credit.wait(), 3)
                await asyncio.sleep(max(0, 1 / 60 - (time.monotonic() - last_send)))
                latest = self.latest
                now = time.monotonic()
                age = now - self.latest_received if self.latest_received is not None else None
                key = (latest[0].session_id, latest[0].sequence) if latest else None
                fresh = age is not None and age <= 0.5
                if (key == sent_key or not fresh) and now - last_send < 0.5:
                    await asyncio.sleep(0.01)
                    continue
                packets = []
                if fresh and key != sent_key:
                    pose, payload = latest
                    if pose.schema_id != schema_id:
                        packets.append(self.schema_payloads[pose.schema_id])
                        schema_id = pose.schema_id
                    packets.append(payload)
                    sent_key = key
                peer.preview_key = key
                peer.preview_credit.clear()
                packets.append(
                    control(
                        Kind.STATUS,
                        dict(
                            kind="PREVIEW",
                            age_seconds=age,
                            sent_monotonic=now,
                            session_id=key[0] if key else None,
                            sequence=key[1] if key else None,
                            capture_metrics=self.metrics
                            if now - self.metrics_received < 2
                            else None,
                        ),
                    )
                )
                async with peer.lock:
                    peer.writer.write(b"".join(frame(p) for p in packets))
                    await asyncio.wait_for(peer.writer.drain(), 2)
                last_send = time.monotonic()
        except (OSError, ConnectionError, asyncio.TimeoutError):
            peer.writer.close()

    async def disk(self, fn, *args):
        try:
            return await asyncio.get_running_loop().run_in_executor(self.pool, fn, *args)
        except OSError as exc:
            raise ProtocolError(
                f"Recorder storage error: {exc}. Keep the phone journal; resolve storage and restart the recorder."
            ) from exc

    def store(self, take_id):
        take_id = uid(take_id)
        if take_id not in self.stores:
            self.stores[take_id] = TakeStore(self.root, take_id)
        return self.stores[take_id]

    async def start(self):
        phone_server = await asyncio.start_server(
            lambda r, w: self.client(r, w, "phone"),
            self.host,
            self.phone_port,
            limit=65536,
            ssl=self.ssl_context,
        )
        try:
            blender_server = await asyncio.start_server(
                lambda r, w: self.client(r, w, "blender"),
                "127.0.0.1",
                self.blender_port,
                limit=65536,
            )
        except Exception:
            phone_server.close()
            await phone_server.wait_closed()
            raise

        self.servers = [phone_server, blender_server]
        self.phone_port = phone_server.sockets[0].getsockname()[1]
        self.blender_port = blender_server.sockets[0].getsockname()[1]

        try:
            self.root.mkdir(parents=True, exist_ok=True)
            self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="journal")
            self.coordinator = Coordinator(self.root)
            self.archive_task = asyncio.create_task(self.archive_poses())
        except Exception:
            for server in self.servers:
                server.close()
            for server in self.servers:
                await server.wait_closed()
            self.servers.clear()
            if self.pool:
                self.pool.shutdown(wait=True)
                self.pool = None
            raise

        return self

    async def close(self):
        if self.closed:
            return
        self.closed = True
        for server in self.servers:
            server.close()
        for server in self.servers:
            await server.wait_closed()
        self.servers.clear()
        for peer in list(self.peers.values()):
            peer.writer.close()
        for task in self.preview_tasks:
            task.cancel()
        await asyncio.gather(*self.preview_tasks, return_exceptions=True)
        if self.client_tasks:
            done, pending = await asyncio.wait(list(self.client_tasks), timeout=2)
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
        await self.archive_queue.join()
        if self.archive_task:
            self.archive_task.cancel()
            await asyncio.gather(self.archive_task, return_exceptions=True)

        def close_stores():
            for store in self.stores.values():
                store.close()

        if self.pool:
            await self.disk(close_stores)
            self.pool.shutdown(wait=True)
            self.pool = None
        self.stopped.set()

    def interrupt_locally(self, reason: str = "Abandoned or interrupted locally") -> bool:
        if self.coordinator:
            return self.coordinator.interrupt_locally(reason)
        return False

    def is_idle(self) -> bool:
        coord_active = self.coordinator.state.get("active") if self.coordinator else None
        in_take = coord_active is not None and coord_active.get("phase") not in {
            "SOURCE_DURABLE",
            "CANCELLED",
            "INTERRUPTED",
        }
        return not in_take and self.archive_queue.empty() and self.archive_bytes == 0

    def status_snapshot(self) -> dict:
        now = self.clock()
        coord_state = self.coordinator.state if self.coordinator else None
        return {
            "pid": os.getpid(),
            "capture_root": str(self.root),
            "phone_port": self.phone_port,
            "blender_port": self.blender_port,
            "closed": self.closed,
            "active_take": coord_state.get("active") if coord_state else None,
            "phone_connected": "phone" in self.peers,
            "blender_connected": "blender" in self.peers,
            "preview_connected": "preview" in self.peers,
            "archive_queue_records": self.archive_queue.qsize(),
            "archive_queue_bytes": self.archive_bytes,
            "capture_metrics": self.metrics if now - self.metrics_received < 2 else None,
            "managed": self.managed,
            "claimed": self.active_controller_id is not None
            and self.active_manager_peer is not None,
            "controller_id": self.active_controller_id,
            "idle": self.is_idle(),
            "last_progress_time": self.last_progress_time,
        }

    async def client(self, reader, writer, listener_role):
        task = asyncio.current_task()
        self.client_tasks.add(task)
        peer = Peer(writer, listener_role)
        parser = Framer()
        authorized = False
        role = listener_role
        try:
            async with self.connection_limit:
                while not self.closed:
                    data = await asyncio.wait_for(reader.read(65536), 10 if not authorized else 60)
                    if not data:
                        parser.eof()
                        break
                    for payload in parser.feed(data):
                        kind, body = decode(payload)
                        if not authorized:
                            if kind != Kind.HELLO:
                                raise ProtocolError("Expected pairing handshake")
                            if listener_role == "phone":
                                if body.get("role") != "phone":
                                    raise ProtocolError(
                                        "Only phone role is permitted on phone endpoint"
                                    )
                                role = "phone"
                            else:
                                req_role = body.get("role")
                                if req_role == "phone":
                                    raise ProtocolError(
                                        "Phone role is not permitted on loopback endpoint"
                                    )
                                if req_role == MANAGEMENT_ROLE:
                                    role = MANAGEMENT_ROLE
                                elif req_role == "preview":
                                    role = "preview"
                                elif req_role == "blender":
                                    role = "blender"
                                else:
                                    raise ProtocolError(
                                        f"Unknown role '{req_role}' on loopback endpoint"
                                    )
                            peer.role = role

                            if role == MANAGEMENT_ROLE:
                                if not self.management_token:
                                    raise ProtocolError("Management endpoint is not configured")
                                if not isinstance(
                                    body.get("token"), str
                                ) or not hmac.compare_digest(body["token"], self.management_token):
                                    raise ProtocolError("Management pairing failed")
                                validate_management_hello(body)
                                self.manager_peers.add(peer)
                                authorized = True
                                await peer.send(
                                    control(
                                        Kind.STATUS,
                                        dict(
                                            hello=True,
                                            role=role,
                                            management_protocol=MANAGEMENT_PROTOCOL,
                                            protocol=2,
                                        ),
                                    )
                                )
                                continue

                            if role in {"blender", "preview"}:
                                if not isinstance(
                                    body.get("token"), str
                                ) or not hmac.compare_digest(body["token"], self.token):
                                    raise ProtocolError("Pairing failed")
                                if body.get("protocol") != 2 or "journal-v1" not in body.get(
                                    "features", []
                                ):
                                    raise ProtocolError("Required protocol features unavailable")
                                uid(body.get("connection_id"))

                                if self.managed:
                                    controller_id = body.get("controller_id")
                                    if not controller_id:
                                        raise ProtocolError(
                                            "Controller ID required in managed mode"
                                        )
                                    controller_id = uid(controller_id)
                                    if (
                                        self.active_controller_id is None
                                        or controller_id != self.active_controller_id
                                    ):
                                        raise ProtocolError("Invalid or stale controller ID")
                                    old = self.peers.get(role)
                                    if old and old is not peer:
                                        old.writer.close()
                                else:
                                    old = self.peers.get(role)
                                    if old and old is not peer:
                                        old.writer.close()

                                self.peers[role] = peer
                                authorized = True
                                await peer.send(
                                    control(
                                        Kind.STATUS,
                                        dict(
                                            hello=True,
                                            role=role,
                                            transport="PLAINTEXT_TRUSTED_LAN",
                                            protocol=2,
                                            preview_stream=True,
                                            controller_id=self.active_controller_id
                                            if self.managed
                                            else None,
                                        ),
                                    )
                                )
                                if role == "preview":
                                    preview_task = asyncio.create_task(self.preview_stream(peer))
                                    self.preview_tasks.add(preview_task)
                                    preview_task.add_done_callback(self.preview_tasks.discard)
                                continue

                            if role == "phone":
                                if not isinstance(
                                    body.get("token"), str
                                ) or not hmac.compare_digest(body["token"], self.token):
                                    raise ProtocolError("Pairing failed")
                                if body.get("protocol") != 2 or "journal-v1" not in body.get(
                                    "features", []
                                ):
                                    raise ProtocolError("Required protocol features unavailable")
                                uid(body.get("connection_id"))
                                peer.session_id = uid(body.get("session_id"))
                                old = self.peers.get(role)
                                if old and old is not peer:
                                    old.writer.close()
                                self.peers[role] = peer
                                authorized = True
                                await peer.send(
                                    control(
                                        Kind.STATUS,
                                        dict(
                                            hello=True,
                                            role=role,
                                            transport="TLS"
                                            if self.ssl_context is not None
                                            else "PLAINTEXT_TRUSTED_LAN",
                                            protocol=2,
                                            preview_stream=True,
                                        ),
                                    )
                                )
                                for command in await self.disk(self.coordinator.pending_for_phone):
                                    await peer.send(control(Kind.COMMAND, command))
                                continue
                        await self.message(peer, kind, body, payload)
        except (ProtocolError, ValueError, KeyError, TypeError) as exc:
            with contextlib.suppress(Exception):
                await peer.send(control(Kind.STATUS, dict(error=str(exc), accepted=False)))
        except (asyncio.TimeoutError, ConnectionError, OSError):
            pass
        finally:
            self.client_tasks.discard(task)
            if peer in self.manager_peers:
                self.manager_peers.discard(peer)
            if self.active_manager_peer is peer:
                self.active_manager_peer = None
                if self.is_idle():
                    self.active_controller_id = None
            if self.peers.get(role) is peer:
                self.peers.pop(role, None)
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()
            if self.stop_when_idle_requested and self.is_idle():
                asyncio.create_task(self.close())

    async def handle_management(self, peer, body):
        req = validate_management_request(body)
        request_id = req["request_id"]
        op = req["operation"]

        if op == "status":
            snapshot = self.status_snapshot()
            resp = build_management_response("status", request_id, accepted=True, **snapshot)
            await peer.send(control(Kind.STATUS, resp))
            return

        if op == "claim":
            if self.active_manager_peer is not None and self.active_manager_peer is not peer:
                resp = build_management_response(
                    "claim",
                    request_id,
                    accepted=False,
                    error="Recorder already claimed by another controller",
                )
                await peer.send(control(Kind.STATUS, resp))
                return

            req_controller_id = req.get("controller_id")
            if (
                not self.is_idle()
                and self.active_controller_id is not None
                and req_controller_id != self.active_controller_id
            ):
                resp = build_management_response(
                    "claim",
                    request_id,
                    accepted=False,
                    error="Take in progress; cannot claim recorder during an active take",
                )
                await peer.send(control(Kind.STATUS, resp))
                return

            if self.active_manager_peer is peer and self.active_controller_id is not None:
                resp = build_management_response(
                    "claim",
                    request_id,
                    accepted=True,
                    controller_id=self.active_controller_id,
                )
                await peer.send(control(Kind.STATUS, resp))
                return

            if req_controller_id and req_controller_id == self.active_controller_id:
                self.active_manager_peer = peer
                resp = build_management_response(
                    "claim",
                    request_id,
                    accepted=True,
                    controller_id=self.active_controller_id,
                )
                await peer.send(control(Kind.STATUS, resp))
                return

            self.active_controller_id = str(uuid.uuid4())
            self.active_manager_peer = peer
            resp = build_management_response(
                "claim",
                request_id,
                accepted=True,
                controller_id=self.active_controller_id,
            )
            await peer.send(control(Kind.STATUS, resp))
            return

        if op == "release":
            if self.active_manager_peer is not peer:
                resp = build_management_response(
                    "release",
                    request_id,
                    accepted=False,
                    error="Not owner of current claim",
                )
                await peer.send(control(Kind.STATUS, resp))
                return

            self.active_controller_id = None
            self.active_manager_peer = None
            for r in ("blender", "preview"):
                p = self.peers.pop(r, None)
                if p:
                    p.writer.close()

            resp = build_management_response(
                "release",
                request_id,
                accepted=True,
                released=True,
            )
            await peer.send(control(Kind.STATUS, resp))
            return

        if op == "stop-when-idle":
            idle = self.is_idle()
            if idle:
                resp = build_management_response(
                    "stop-when-idle",
                    request_id,
                    accepted=True,
                    stopping=True,
                )
                await peer.send(control(Kind.STATUS, resp))
                asyncio.create_task(self.close())
            else:
                self.stop_when_idle_requested = True
                resp = build_management_response(
                    "stop-when-idle",
                    request_id,
                    accepted=True,
                    stopping=False,
                )
                await peer.send(control(Kind.STATUS, resp))
            return

        raise ProtocolError(f"Unsupported management operation '{op}'")

    async def send_role(self, role, payload):
        peer = self.peers.get(role)
        if not peer:
            return False
        try:
            await peer.send(payload)
            return True
        except (OSError, ConnectionError, asyncio.TimeoutError):
            peer.writer.close()
            return False

    async def message(self, peer, kind, body, payload):
        if peer.role == MANAGEMENT_ROLE:
            if kind not in {Kind.COMMAND, Kind.QUERY}:
                raise ProtocolError("Manager role accepts only command or query messages")
            await self.handle_management(peer, body)
            return

        if peer.role == "phone" and isinstance(body, dict):
            if (
                body.get("operation") in MANAGEMENT_OPERATIONS
                or body.get("command") in MANAGEMENT_OPERATIONS
            ):
                raise ProtocolError("Management operations forbidden on phone endpoint")
        if peer.role == "phone":
            self.last_progress_time = self.clock()
        if peer.role == "preview":
            if kind != Kind.QUERY:
                raise ProtocolError("Preview accepts acknowledgments only")
            key = (
                (body.get("session_id"), body.get("sequence"))
                if body.get("session_id") is not None
                else None
            )
            if kind != Kind.QUERY or body.get("kind") != "PREVIEW_ACK" or key != peer.preview_key:
                raise ProtocolError("Invalid preview acknowledgment")
            peer.preview_credit.set()
            return
        if peer.role == "phone" and kind in {Kind.EVENT, Kind.QUERY}:
            await self.archive_queue.join()
            if self.archive_error:
                raise ProtocolError(self.archive_error)
        if kind == Kind.SCHEMA and peer.role == "phone":
            schema = Schema.from_body(body)
            old = self.schema_payloads.get(schema.schema_id)
            if old and old != payload:
                raise ProtocolError("Schema identity changed")
            self.schemas[schema.schema_id] = schema
            self.schema_payloads[schema.schema_id] = payload
            await peer.send(
                control(Kind.STATUS, dict(schema_id=schema.schema_id, schema_ready=True))
            )
            return
        if kind == Kind.POSE and peer.role == "phone":
            if body.session_id != peer.session_id:
                raise ProtocolError("Pose session differs from HELLO")
            if body.schema_id not in self.schemas:
                raise ProtocolError("Unannounced schema")
            body.validate(self.schemas[body.schema_id])
            if self.archive_error:
                raise ProtocolError(self.archive_error)
            if body.take_id != ZERO:
                if self.archive_bytes + len(payload) > 2 * 1024 * 1024 or self.archive_queue.full():
                    raise ProtocolError(
                        "Recorder archive queue full; retain phone journal and recover"
                    )
                self.archive_bytes += len(payload)
                self.archive_queue.put_nowait((peer, body, payload))
            # Recovered poses are older in the same capture clock; never preview them.
            if (
                self.latest is None
                or self.latest[0].session_id != body.session_id
                or body.sequence > self.latest[0].sequence
            ):
                self.latest = (body, payload)
                self.latest_received = time.monotonic()
            return
        if kind == Kind.EVENT and peer.role == "phone":
            if body.get("event") in {
                "CALIBRATION_STARTED",
                "CALIBRATION_READY",
                "CALIBRATION_FAILED",
                "COUNTDOWN_TICK",
            }:
                await self.send_role("blender", payload)
                return

            def source_event():
                store = self.store(body.get("take_id"))
                store.append(payload)
                self.coordinator.source_event(body)
                return store.status()

            status = await self.disk(source_event)
            await peer.send(control(Kind.STATUS, status))
            await self.send_role("blender", payload)
            return
        if kind == Kind.COMMAND:
            try:
                result, target = await self.disk(self.coordinator.command, body, peer.role)
            except ProtocolError as exc:
                await peer.send(
                    control(
                        Kind.STATUS,
                        dict(request_id=body.get("request_id"), error=str(exc), accepted=False),
                    )
                )
                return
            delivered = await self.send_role(target, payload) if target else False
            result = dict(result, delivered=delivered)
            await peer.send(control(Kind.STATUS, result))
            return
        if kind == Kind.STATUS:
            if peer.role == "phone" and body.get("kind") == "CAPTURE_METRICS":
                metrics = validate_metrics(body)
                if metrics["session_id"] != peer.session_id:
                    raise ProtocolError("Metrics session differs from HELLO")
                self.metrics = metrics
                self.metrics_received = time.monotonic()
                return
            # Typed forwarding only; Blender saved status never changes source durability.
            if peer.role == "blender" and body.get("state") in {
                "CALIBRATED",
                "CALIBRATION_FAILED",
                "RECENTERED",
                "READY_IN_SCENE",
                "SCENE_SAVED",
                "ERROR",
            }:
                await self.send_role("phone", payload)
                return
            if peer.role == "phone" and "request_id" in body:
                if body.get("accepted") is False:
                    await self.disk(
                        self.coordinator.rejected,
                        body["request_id"],
                        body.get("error", "Phone rejected preparation"),
                    )
                await self.send_role("blender", payload)
                return
            raise ProtocolError("Unsupported status update")
        if kind == Kind.QUERY:
            await self.query(peer, body)
            return
        raise ProtocolError("Message not permitted for this endpoint")

    async def query(self, peer, body):
        request_id = uid(body.get("request_id"))
        kind = body.get("kind")
        if kind == "LATEST_POSE":
            if self.latest:
                pose, payload = self.latest
                await peer.send(self.schema_payloads[pose.schema_id])
                await peer.send(payload)
            await peer.send(
                control(
                    Kind.STATUS,
                    dict(
                        request_id=request_id,
                        kind=kind,
                        available=self.latest is not None,
                        age_seconds=time.monotonic() - self.latest_received
                        if self.latest_received
                        else None,
                    ),
                )
            )
        elif kind == "SYSTEM_STATUS":
            state = await self.disk(lambda: json.loads(json.dumps(self.coordinator.state)))
            await peer.send(
                control(
                    Kind.STATUS,
                    dict(
                        request_id=request_id,
                        kind=kind,
                        active=state["active"],
                        phone_connected="phone" in self.peers,
                        blender_connected="blender" in self.peers,
                        capture_metrics=self.metrics
                        if time.monotonic() - self.metrics_received < 2
                        else None,
                        archive_queue_records=self.archive_queue.qsize(),
                        archive_queue_bytes=self.archive_bytes,
                    ),
                )
            )
        elif kind == "LIST_TAKES":

            def list_takes():
                result = []
                for path in self.root.iterdir():
                    if not path.is_dir():
                        continue
                    if (path / "source.partial").exists():
                        result.append(self.store(path.name).status())
                    elif (path / "source.motion").exists() and (path / "manifest.json").exists():
                        try:
                            from motionslate.journal import ReadOnlySource

                            with ReadOnlySource(path) as ro:
                                ro.verify()
                                m = ro.manifest
                                result.append(
                                    dict(
                                        take_id=ro.take_id,
                                        received_ranges=m.get("sample_ranges", []),
                                        durable_ranges=m.get("sample_ranges", []),
                                        missing_ranges=[],
                                        cursor=m.get("record_count", 0),
                                        revision=m.get("record_count", 0),
                                        recovered_ranges=[],
                                        start=dict(t0=m.get("t0")),
                                        end=dict(
                                            t_stop=m.get("t_stop"),
                                            first_sequence=m.get("sample_ranges", [[0, 0]])[0][0],
                                            last_sequence=m.get("sample_ranges", [[0, 0]])[-1][1],
                                            reason=m.get("stop_reason", "COMPLETED"),
                                        ),
                                        source_durable=True,
                                        source_hash=ro.source_hash,
                                        state="SOURCE_DURABLE",
                                    )
                                )
                        except Exception:
                            pass
                return result

            await peer.send(
                control(
                    Kind.STATUS,
                    dict(request_id=request_id, kind=kind, takes=await self.disk(list_takes)),
                )
            )
        elif kind in {
            "TAKE_STATUS",
            "SAMPLES_AFTER_CURSOR",
            "SAMPLES_SOURCE_ORDER",
            "FINALIZE_SOURCE",
        }:
            take_id = uid(body.get("take_id"))

            def operate():
                if (
                    not (self.root / take_id / "source.partial").exists()
                    and (self.root / take_id / "source.motion").exists()
                    and (self.root / take_id / "manifest.json").exists()
                ):
                    from motionslate.journal import ReadOnlySource

                    with ReadOnlySource(self.root / take_id) as ro:
                        ro.verify()
                        if kind == "TAKE_STATUS":
                            m = ro.manifest
                            return dict(
                                take_id=ro.take_id,
                                received_ranges=m.get("sample_ranges", []),
                                durable_ranges=m.get("sample_ranges", []),
                                missing_ranges=[],
                                cursor=m.get("record_count", 0),
                                revision=m.get("record_count", 0),
                                recovered_ranges=[],
                                start=dict(t0=m.get("t0")),
                                end=dict(
                                    t_stop=m.get("t_stop"),
                                    first_sequence=m.get("sample_ranges", [[0, 0]])[0][0],
                                    last_sequence=m.get("sample_ranges", [[0, 0]])[-1][1],
                                    reason=m.get("stop_reason", "COMPLETED"),
                                ),
                                source_durable=True,
                                source_hash=ro.source_hash,
                                state="SOURCE_DURABLE",
                            )
                        if kind == "SAMPLES_SOURCE_ORDER":
                            records = list(ro.records())
                            cursor = body.get("cursor", 0)
                            limit = body.get("limit", 128)
                            end = min(cursor + limit, len(records))
                            return (records[cursor:end], end, end == len(records))
                        if kind == "SAMPLES_AFTER_CURSOR":
                            raise ProtocolError("Archived take only supports source-order replay")

                store = self.store(take_id)
                if kind == "TAKE_STATUS":
                    return store.status()
                if kind == "SAMPLES_AFTER_CURSOR":
                    return store.history(body.get("cursor", 0), body.get("limit", 128))
                if kind == "SAMPLES_SOURCE_ORDER":
                    return store.source_history(body.get("cursor", 0), body.get("limit", 128))
                if peer.role != "phone":
                    raise ProtocolError("Only source may attest final integrity")
                digest = body.get("source_hash")
                if not isinstance(digest, str) or len(digest) != 64:
                    raise ProtocolError("Expected canonical source hash")
                store.finalize(digest)
                self.coordinator.finalized(take_id)
                return store.status()

            try:
                result = await self.disk(operate)
            except ProtocolError as exc:
                await peer.send(
                    control(
                        Kind.STATUS,
                        dict(
                            request_id=request_id,
                            kind=kind,
                            take_id=take_id,
                            error=str(exc),
                            accepted=False,
                        ),
                    )
                )
                return
            if kind in {"SAMPLES_AFTER_CURSOR", "SAMPLES_SOURCE_ORDER"}:
                payloads, cursor = result[:2]
                for payload in payloads:
                    await peer.send(payload)
                await peer.send(
                    control(
                        Kind.EVENT,
                        dict(
                            event="HISTORY_END",
                            request_id=request_id,
                            take_id=take_id,
                            cursor=cursor,
                            done=result[2] if kind == "SAMPLES_SOURCE_ORDER" else False,
                        ),
                    )
                )
            else:
                await peer.send(
                    control(Kind.STATUS, dict(result, request_id=request_id, kind=kind))
                )
                if kind == "FINALIZE_SOURCE":
                    await self.send_role("blender", control(Kind.STATUS, result))
        else:
            raise ProtocolError("Unknown query")


def load_token(root):
    from motionslate_recorder.managed import load_or_create_token

    return load_or_create_token(root)


async def run(args):
    from motionslate_recorder.managed import ManagedService, load_or_create_token
    from motionslate_recorder.security import (
        PairingPayload,
        create_server_ssl_context,
        load_or_create_certificate,
        save_pairing_file,
    )

    if getattr(args, "unmanaged", False):
        token = load_or_create_token(args.captures)
        cert_dir = Path(args.captures).expanduser().resolve() / ".security"
        cert_path, key_path, fingerprint = load_or_create_certificate(cert_dir)
        ssl_context = create_server_ssl_context(cert_path, key_path)
        recorder = Recorder(
            root=args.captures,
            token=token,
            host=args.host,
            phone_port=args.phone_port,
            blender_port=args.blender_port,
            managed=False,
            ssl_context=ssl_context,
        )
        await recorder.start()
        pairing_payload = PairingPayload.encode(
            endpoint=f"{args.host}:{recorder.phone_port}",
            recorder_id=str(uuid.uuid4()),
            fingerprint=fingerprint,
            token=token,
        )
        save_pairing_file(recorder.root / "pairing.txt", pairing_payload)
        print(
            f"Unmanaged developer mode (TLS). Phone: {args.host}:{recorder.phone_port}; Blender: 127.0.0.1:{recorder.blender_port}",
            flush=True,
        )
        print(f"Pairing code: {pairing_payload}", flush=True)
        print(f"Pairing file: {recorder.root / 'pairing.txt'}", flush=True)
        stop = asyncio.Event()
        for sig in (signal.SIGINT, signal.SIGTERM):
            with contextlib.suppress(NotImplementedError):
                asyncio.get_running_loop().add_signal_handler(sig, stop.set)
        try:
            wait_sig = asyncio.create_task(stop.wait())
            wait_stopped = asyncio.create_task(recorder.stopped.wait())
            done, pending = await asyncio.wait(
                [wait_sig, wait_stopped], return_when=asyncio.FIRST_COMPLETED
            )
            for t in pending:
                t.cancel()
        finally:
            await recorder.close()
        return

    service = ManagedService(
        captures=args.captures,
        host=args.host,
        phone_port=args.phone_port,
        blender_port=args.blender_port,
        service_dir=getattr(args, "service_dir", None),
    )
    await service.start()
    print(
        f"Secure mode (TLS). Phone: {args.host}:{service.recorder.phone_port}; Blender: 127.0.0.1:{service.recorder.blender_port}",
        flush=True,
    )
    if service.pairing_payload:
        print(f"Pairing code: {service.pairing_payload}", flush=True)
    print(f"Pairing file: {service.canonical_root / 'pairing.txt'}", flush=True)
    stop = asyncio.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        with contextlib.suppress(NotImplementedError):
            asyncio.get_running_loop().add_signal_handler(sig, stop.set)
    try:
        wait_sig = asyncio.create_task(stop.wait())
        wait_stopped = asyncio.create_task(service.stopped.wait())
        done, pending = await asyncio.wait(
            [wait_sig, wait_stopped], return_when=asyncio.FIRST_COMPLETED
        )
        for t in pending:
            t.cancel()
    finally:
        await service.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--captures", default="~/Movies/MotionSlate")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--phone-port", type=int, default=9000)
    parser.add_argument("--blender-port", type=int, default=9001)
    parser.add_argument(
        "--service-dir", default=None, help="Directory for service lock and readiness descriptor"
    )
    parser.add_argument(
        "--unmanaged",
        action="store_true",
        help="Run in explicit unmanaged developer mode without manager role enforcement",
    )
    asyncio.run(run(parser.parse_args()))


if __name__ == "__main__":
    main()
