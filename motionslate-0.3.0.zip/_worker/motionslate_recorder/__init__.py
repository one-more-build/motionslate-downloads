"""Desktop capture recorder."""
