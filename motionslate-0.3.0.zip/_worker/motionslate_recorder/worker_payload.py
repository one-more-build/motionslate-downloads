"""Standard-library-only payload validator and atomic staging engine for the MotionSlate worker.

Executed both inside Blender (package-relatively) and in the worker process.
Guarantees deterministic hash verification, concurrency serialization, and tamper detection.
"""

from __future__ import annotations
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import time

CORE_MODULES = {
    "control.py",
    "journal.py",
    "preview.py",
    "protocol.py",
    "service_protocol.py",
    "synthetic.py",
    "telemetry.py",
}

DISALLOWED_NAMES = {"__pycache__", ".DS_Store", ".git"}


def get_default_workers_base_dir() -> Path:
    return Path.home() / "Library" / "Application Support" / "MotionSlate" / "workers"


@contextmanager
def file_lock(lock_path: Path, timeout: float = 30.0):
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a") as handle:
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise TimeoutError(f"Timed out acquiring lock on {lock_path}") from None
                time.sleep(0.05)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def collect_payload_files(package_dir: Path) -> dict[str, Path]:
    """Collect all core and worker files from an assembled or installed package directory."""
    files: dict[str, Path] = {}

    # 1. Portable core modules at top-level
    for name in CORE_MODULES:
        p = package_dir / name
        if p.is_file():
            files[name] = p

    # 2. _worker directory
    worker_dir = package_dir / "_worker"
    if worker_dir.is_dir():
        for p in sorted(worker_dir.rglob("*")):
            if not p.is_file():
                continue
            if any(part in DISALLOWED_NAMES or part.endswith(".pyc") for part in p.parts):
                continue
            rel = p.relative_to(package_dir).as_posix()
            files[rel] = p

    return files


def compute_payload_hash(package_dir: Path) -> str:
    """Compute deterministic SHA-256 hash across all payload files and their contents."""
    files = collect_payload_files(package_dir)
    if not files:
        raise ValueError(f"No payload files found in {package_dir}")

    hasher = hashlib.sha256()
    hasher.update(b"MOTIONS_SLATE_WORKER_PAYLOAD_v1\n")
    for rel_path in sorted(files.keys()):
        hasher.update(rel_path.encode("utf-8") + b"\n")
        hasher.update(files[rel_path].read_bytes())
    return hasher.hexdigest()


def verify_staged_payload(staged_dir: Path, expected_hash: str | None = None) -> bool:
    """Verify that a staged directory is intact, matches its manifest, and has no extra files."""
    manifest_path = staged_dir / "payload_manifest.json"
    if not manifest_path.is_file():
        return False

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception:
        return False

    payload_hash = manifest.get("payload_hash")
    if not payload_hash or not isinstance(payload_hash, str):
        return False
    if expected_hash and payload_hash != expected_hash:
        return False

    manifest_files: dict[str, str] = manifest.get("files", {})
    if not manifest_files:
        return False

    # Check that all manifest files exist with matching SHA-256
    for rel_path, expected_sha in manifest_files.items():
        file_path = staged_dir / rel_path
        if not file_path.is_file():
            return False
        try:
            actual_sha = hashlib.sha256(file_path.read_bytes()).hexdigest()
            if actual_sha != expected_sha:
                return False
        except Exception:
            return False

    # Check for unlisted files (tamper detection)
    for p in staged_dir.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(staged_dir).as_posix()
        if rel == "payload_manifest.json":
            continue
        if any(part in DISALLOWED_NAMES or part.endswith(".pyc") for part in p.parts):
            continue
        if rel not in manifest_files:
            return False

    return True


def stage_worker(package_dir: Path, workers_base_dir: Path | None = None) -> Path:
    """Atomically stage the worker payload to workers/<payload-hash>/motionslate."""
    payload_hash = compute_payload_hash(package_dir)
    base_dir = workers_base_dir or get_default_workers_base_dir()
    target_dir = base_dir / payload_hash / "motionslate"

    # Fast path: already staged and verified
    if verify_staged_payload(target_dir, payload_hash):
        return target_dir

    lock_path = base_dir / f"{payload_hash}.lock"
    with file_lock(lock_path):
        # Re-check under lock
        if verify_staged_payload(target_dir, payload_hash):
            return target_dir

        if target_dir.exists():
            shutil.rmtree(target_dir)

        # Stage atomically via temporary directory on same filesystem
        base_dir.mkdir(parents=True, exist_ok=True)
        tmp_dir = Path(tempfile.mkdtemp(prefix=f"{payload_hash}.tmp.", dir=base_dir))
        try:
            files = collect_payload_files(package_dir)
            manifest_files: dict[str, str] = {}

            for rel_path, src_path in files.items():
                dest_path = tmp_dir / rel_path
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                content = src_path.read_bytes()
                dest_path.write_bytes(content)
                manifest_files[rel_path] = hashlib.sha256(content).hexdigest()

            # Write manifest
            manifest = {
                "schema_version": "1.0.0",
                "payload_hash": payload_hash,
                "files": manifest_files,
            }
            manifest_file = tmp_dir / "payload_manifest.json"
            manifest_file.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

            # Fsync all files
            for p in tmp_dir.rglob("*"):
                if p.is_file():
                    with p.open("rb") as f:
                        os.fsync(f.fileno())

            # Commit to target
            target_parent = target_dir.parent
            target_parent.mkdir(parents=True, exist_ok=True)
            os.replace(tmp_dir, target_dir)

            # Fsync directory
            fd = os.open(str(target_parent), os.O_RDONLY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)

        finally:
            if tmp_dir.exists():
                shutil.rmtree(tmp_dir, ignore_errors=True)

    return target_dir


def prune_unused_workers(
    base_dir: Path | None = None, active_hashes: set[str] | None = None
) -> list[Path]:
    """Remove staged worker directories that are not in active_hashes."""
    root = base_dir or get_default_workers_base_dir()
    if not root.is_dir():
        return []

    active = active_hashes or set()
    pruned = []
    for item in root.iterdir():
        if item.is_dir() and len(item.name) == 64 and item.name not in active:
            # Check for directory lock before pruning
            lock_path = root / f"{item.name}.lock"
            try:
                with file_lock(lock_path, timeout=1.0):
                    shutil.rmtree(item)
                    pruned.append(item)
            except (TimeoutError, OSError):
                pass
    return pruned
