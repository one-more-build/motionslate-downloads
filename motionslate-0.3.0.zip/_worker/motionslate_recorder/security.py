"""Local TLS certificate lifecycle, certificate pinning, and versioned pairing payloads.

Enforces:
- Self-signed X.509 certificate generation with 365-day validity and SANs for local interfaces.
- Secure file permissions: 0o600 for private key, 0o644 for certificate.
- Symlink rejection on all security assets.
- Modern TLS 1.2+ server context creation.
- Versioned pairing payload encoding and decoding (ms1:<base64url> and raw JSON).
"""

from __future__ import annotations
import base64
import datetime
import ipaddress
import json
import os
from pathlib import Path
import ssl
import stat
import uuid

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa


class InsecureSecurityFileError(ValueError):
    """Raised when security assets have insecure permissions or are symlinks."""


def load_or_create_certificate(
    cert_dir: Path | str,
    common_name: str = "MotionSlate Recorder",
    now: datetime.datetime | None = None,
) -> tuple[Path, Path, str]:
    """Load an existing certificate or generate a new RSA self-signed X.509 certificate.

    Returns (cert_path, key_path, fingerprint_hex) where fingerprint_hex is formatted as
    'sha256:<64 hex chars>'.
    """
    cert_dir = Path(cert_dir).expanduser().resolve()
    cert_path = cert_dir / "server.crt"
    key_path = cert_dir / "server.key"

    if cert_path.is_symlink():
        raise InsecureSecurityFileError(f"Certificate at {cert_path} must not be a symlink")
    if key_path.is_symlink():
        raise InsecureSecurityFileError(f"Private key at {key_path} must not be a symlink")

    current_time = now or datetime.datetime.now(datetime.timezone.utc)

    if key_path.exists():
        st = key_path.stat()
        if hasattr(os, "getuid") and (st.st_mode & 0o077 != 0):
            raise InsecureSecurityFileError(
                f"Insecure permissions on private key file: {oct(stat.S_IMODE(st.st_mode))}. "
                "Expected 0600 (user-only)."
            )

    if cert_path.exists() and key_path.exists():
        try:
            cert_bytes = cert_path.read_bytes()
            cert = x509.load_pem_x509_certificate(cert_bytes)
            not_after = (
                cert.not_valid_after_utc
                if hasattr(cert, "not_valid_after_utc")
                else cert.not_valid_after.replace(tzinfo=datetime.timezone.utc)
            )
            # Ensure certificate has at least 24 hours of remaining validity
            if not_after > current_time + datetime.timedelta(hours=24):
                fp = f"sha256:{cert.fingerprint(hashes.SHA256()).hex().lower()}"
                return cert_path, key_path, fp
        except Exception:
            # Corrupted or unparseable cert: regenerate
            pass

    # Generate new RSA 2048-bit key and self-signed certificate
    cert_dir.mkdir(parents=True, exist_ok=True)
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    subject = issuer = x509.Name(
        [
            x509.NameAttribute(x509.oid.NameOID.COMMON_NAME, common_name),
        ]
    )

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(current_time - datetime.timedelta(minutes=5))
        .not_valid_after(current_time + datetime.timedelta(days=365))
        .add_extension(
            x509.SubjectAlternativeName(
                [
                    x509.DNSName("localhost"),
                    x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
                    x509.IPAddress(ipaddress.IPv4Address("0.0.0.0")),
                    x509.IPAddress(ipaddress.IPv6Address("::1")),
                ]
            ),
            critical=False,
        )
        .sign(key, hashes.SHA256())
    )

    key_bytes = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    cert_bytes = cert.public_bytes(serialization.Encoding.PEM)

    # Write key atomically with 0o600
    tmp_key = cert_dir / f".server.key.{uuid.uuid4().hex}.tmp"
    fd_key = os.open(tmp_key, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        os.write(fd_key, key_bytes)
    finally:
        os.close(fd_key)
    os.replace(tmp_key, key_path)

    # Write cert atomically with 0o644
    tmp_cert = cert_dir / f".server.crt.{uuid.uuid4().hex}.tmp"
    fd_cert = os.open(tmp_cert, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    try:
        os.write(fd_cert, cert_bytes)
    finally:
        os.close(fd_cert)
    os.replace(tmp_cert, cert_path)

    fp = f"sha256:{cert.fingerprint(hashes.SHA256()).hex().lower()}"
    return cert_path, key_path, fp


def create_server_ssl_context(cert_path: Path | str, key_path: Path | str) -> ssl.SSLContext:
    """Create a modern TLS server SSLContext configured with the specified cert and key."""
    cert_path = Path(cert_path).expanduser().resolve()
    key_path = Path(key_path).expanduser().resolve()

    if cert_path.is_symlink() or key_path.is_symlink():
        raise InsecureSecurityFileError("Certificate and key files must not be symlinks")

    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(certfile=str(cert_path), keyfile=str(key_path))
    return ctx


class PairingPayload:
    """Versioned pairing payload encoding endpoint, recorder identity, fingerprint, and token."""

    @staticmethod
    def encode(endpoint: str, recorder_id: str, fingerprint: str, token: str) -> str:
        """Encode pairing parameters into a versioned compact string 'ms1:<base64url>'."""
        endpoint = endpoint.strip()
        if ":" not in endpoint:
            raise ValueError(f"Endpoint must be in host:port format: {endpoint}")
        host, port_str = endpoint.rsplit(":", 1)
        port = int(port_str)
        if not (1 <= port <= 65535):
            raise ValueError(f"Port must be between 1 and 65535: {port}")

        rec_uuid = str(uuid.UUID(str(recorder_id)))

        fp = fingerprint.strip().lower()
        if fp.startswith("sha256:"):
            fp_hex = fp[7:]
        else:
            fp_hex = fp
        if len(fp_hex) != 64 or not all(c in "0123456789abcdef" for c in fp_hex):
            raise ValueError(f"Invalid SHA-256 fingerprint: {fingerprint}")

        token = token.strip()
        if not token:
            raise ValueError("Token must not be empty")

        data = {
            "endpoint": f"{host}:{port}",
            "fingerprint": f"sha256:{fp_hex}",
            "recorder_id": rec_uuid,
            "token": token,
            "version": 1,
        }

        compact_json = json.dumps(data, separators=(",", ":"), sort_keys=True).encode("utf-8")
        b64 = base64.urlsafe_b64encode(compact_json).decode("ascii").rstrip("=")
        return f"ms1:{b64}"

    @staticmethod
    def decode(payload_str: str) -> dict:
        """Decode a pairing payload string ('ms1:<base64url>' or JSON) into a validated dict."""
        payload_str = payload_str.strip()
        if payload_str.startswith("ms1:"):
            b64 = payload_str[4:]
            b64 += "=" * (-len(b64) % 4)
            try:
                raw_bytes = base64.urlsafe_b64decode(b64.encode("ascii"))
                data = json.loads(raw_bytes.decode("utf-8"))
            except Exception as exc:
                raise ValueError(f"Failed to decode base64url payload: {exc}") from exc
        elif payload_str.startswith("{"):
            try:
                data = json.loads(payload_str)
            except Exception as exc:
                raise ValueError(f"Failed to parse JSON payload: {exc}") from exc
        else:
            raise ValueError(
                "Invalid pairing payload format: must start with 'ms1:' or be a JSON object"
            )

        if not isinstance(data, dict):
            raise ValueError("Pairing payload must be an object")

        if data.get("version") != 1:
            raise ValueError(f"Unsupported pairing payload version: {data.get('version')}")

        endpoint = str(data.get("endpoint", "")).strip()
        if ":" not in endpoint:
            raise ValueError(f"Endpoint must be in host:port format: {endpoint}")
        host, port_str = endpoint.rsplit(":", 1)
        if not host:
            raise ValueError("Endpoint host must not be empty")
        try:
            port = int(port_str)
            if not (1 <= port <= 65535):
                raise ValueError()
        except Exception:
            raise ValueError(f"Endpoint port must be between 1 and 65535: {port_str}")

        try:
            rec_uuid = str(uuid.UUID(str(data.get("recorder_id"))))
        except Exception as exc:
            raise ValueError(f"Invalid recorder UUID: {data.get('recorder_id')}") from exc

        fp = str(data.get("fingerprint", "")).strip().lower()
        if fp.startswith("sha256:"):
            fp_hex = fp[7:]
        else:
            fp_hex = fp
        if len(fp_hex) != 64 or not all(c in "0123456789abcdef" for c in fp_hex):
            raise ValueError(f"Invalid SHA-256 fingerprint: {data.get('fingerprint')}")

        token = str(data.get("token", "")).strip()
        if not token:
            raise ValueError("Pairing token must not be empty")

        return {
            "version": 1,
            "endpoint": f"{host}:{port}",
            "recorder_id": rec_uuid,
            "fingerprint": f"sha256:{fp_hex}",
            "token": token,
        }


def save_pairing_file(pairing_path: Path | str, payload: str) -> Path:
    """Save the versioned pairing payload string securely to a file (0o600)."""
    target = Path(pairing_path).expanduser().resolve()
    if target.is_symlink():
        raise InsecureSecurityFileError(f"Pairing file at {target} must not be a symlink")
    target.parent.mkdir(parents=True, exist_ok=True)

    tmp = target.parent / f".pairing.{uuid.uuid4().hex}.tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        os.write(fd, (payload.strip() + "\n").encode("utf-8"))
    finally:
        os.close(fd)
    os.replace(tmp, target)
    return target
