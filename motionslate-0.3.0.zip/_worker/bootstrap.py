"""Bootstrap entrypoint for the supervised MotionSlate recorder child process.

Executed exclusively by Blender's bundled Python in an isolated process.
Never imported inside Blender, and asserts that bpy is never loaded.
"""

from __future__ import annotations
import importlib.util
from pathlib import Path
import sys

# 1. Strict isolation check: assert bpy is NOT present
if "bpy" in sys.modules:
    raise RuntimeError("bpy was loaded in the worker process; worker must remain isolated")

# 2. Configure import paths so motionslate.* and motionslate_recorder.* are importable
# Expected staged layout:
#   <staged_dir>/motionslate/
#     ├─ control.py, journal.py, protocol.py (motionslate core)
#     └─ _worker/
#         ├─ bootstrap.py
#         ├─ motionslate_recorder/
#         └─ deps/ (vendored wheels)
_worker_dir = Path(__file__).resolve().parent
_package_dir = _worker_dir.parent
_staged_parent = _package_dir.parent

# Allow 'import motionslate.*' via the parent of the motionslate package directory
if str(_staged_parent) not in sys.path:
    sys.path.insert(0, str(_staged_parent))

# Allow 'import motionslate_recorder.*' via _worker directory
if str(_worker_dir) not in sys.path:
    sys.path.insert(0, str(_worker_dir))

# Allow vendored dependencies (e.g. cryptography) in _worker/deps
_deps_dir = _worker_dir / "deps"
if _deps_dir.exists() and str(_deps_dir) not in sys.path:
    sys.path.insert(0, str(_deps_dir))

# In development and test environments, locate workspace virtualenv site-packages
# if pinned dependencies like cryptography are not vendored into _worker/deps.
if importlib.util.find_spec("cryptography") is None:
    for base in [
        Path.cwd(),
        Path(__file__).resolve().parents[4],
        _package_dir.parent.parent.parent,
    ]:
        venv_lib = base / ".venv" / "lib"
        if venv_lib.is_dir():
            for sp in venv_lib.glob("python3.*/site-packages"):
                if (sp / "cryptography").is_dir() and str(sp) not in sys.path:
                    sys.path.append(str(sp))
                    break


def main():
    """Delegate to the recorder bridge main function or perform self-verification."""
    if "--verify-payload" in sys.argv:
        from motionslate_recorder.worker_payload import verify_staged_payload

        if verify_staged_payload(_package_dir):
            print("PAYLOAD_VERIFIED_OK")
            sys.exit(0)
        else:
            print("PAYLOAD_VERIFICATION_FAILED", file=sys.stderr)
            sys.exit(1)

    from motionslate_recorder.bridge import main as bridge_main

    bridge_main()


if __name__ == "__main__":
    main()
